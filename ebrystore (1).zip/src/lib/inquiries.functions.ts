import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type Ctx = { supabase: any; userId: string };

const FIELDS = "id, product_id, user_id, subject, status, last_message_at, created_at";

const STAFF_ROLES = ["admin", "super_admin", "support"] as const;

async function notifyStaff(title: string, message: string, inquiryId: string) {
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: roles } = await supabaseAdmin.from("user_roles").select("user_id").in("role", STAFF_ROLES);
    const ids = Array.from(new Set((roles ?? []).map((r: any) => r.user_id)));
    if (!ids.length) return;
    await supabaseAdmin.from("notifications").insert(
      ids.map((id) => ({
        recipient_id: id,
        type: "product_inquiry",
        title,
        message,
        related_type: "product_inquiry",
        related_id: inquiryId,
      })),
    );
  } catch {
    /* notifikasi opsional */
  }
}

export const createProductInquiry = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z
      .object({
        productId: z.string().uuid().optional(),
        subject: z.string().trim().min(3).max(160),
        body: z.string().trim().min(3).max(2000),
      })
      .parse(data),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as Ctx;
    const { data: row, error } = await supabase
      .from("product_inquiries")
      .insert({ user_id: userId, product_id: data.productId ?? null, subject: data.subject })
      .select("id")
      .maybeSingle();
    if (error || !row) return { ok: false as const, error: "Pertanyaan gagal dikirim. Coba lagi." };

    const { error: msgError } = await supabase.from("product_inquiry_messages").insert({
      inquiry_id: row.id,
      sender_id: userId,
      sender_role: "customer",
      body: data.body,
    });
    if (msgError) return { ok: false as const, error: "Pesan gagal dikirim. Coba lagi." };

    await notifyStaff("Pertanyaan produk baru", data.subject, row.id as string);
    return { ok: true as const, id: row.id as string };
  });

export const listMyInquiries = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context as Ctx;
    const { data, error } = await supabase
      .from("product_inquiries")
      .select(FIELDS)
      .eq("user_id", userId)
      .order("last_message_at", { ascending: false })
      .limit(50);
    if (error) return { items: [], error: "Daftar chat tidak dapat dimuat." as const };
    return { items: data ?? [], error: null };
  });

export const listAllInquiries = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ status: z.string().max(20).optional() }).parse(data ?? {}))
  .handler(async ({ data, context }) => {
    const { supabase } = context as Ctx;
    let query = supabase.from("product_inquiries").select(FIELDS).order("last_message_at", { ascending: false }).limit(100);
    if (data.status && data.status !== "all") query = query.eq("status", data.status);
    const { data: rows, error } = await query;
    if (error) return { items: [], error: "Daftar chat tidak dapat dimuat." as const };

    const userIds = Array.from(new Set((rows ?? []).map((r: any) => r.user_id)));
    const nameById = new Map<string, string>();
    if (userIds.length) {
      const { data: profiles } = await supabase.from("profiles").select("id, full_name, email").in("id", userIds);
      for (const p of profiles ?? []) nameById.set(p.id, p.full_name || p.email || "Pelanggan");
    }
    return {
      items: (rows ?? []).map((r: any) => ({ ...r, customer_name: nameById.get(r.user_id) ?? "Pelanggan" })),
      error: null,
    };
  });

export const getInquiry = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as Ctx;
    const { data: inquiry } = await supabase.from("product_inquiries").select(FIELDS).eq("id", data.id).maybeSingle();
    if (!inquiry) return { inquiry: null, messages: [], product: null, isOwner: false, customerName: null };

    const [{ data: messages }, { data: product }, { data: profile }] = await Promise.all([
      supabase
        .from("product_inquiry_messages")
        .select("id, sender_id, sender_role, body, is_system, created_at")
        .eq("inquiry_id", data.id)
        .order("created_at", { ascending: true })
        .limit(300),
      inquiry.product_id
        ? supabase.from("digital_products").select("id, name, slug, thumbnail_url").eq("id", inquiry.product_id).maybeSingle()
        : Promise.resolve({ data: null }),
      supabase.from("profiles").select("full_name, email").eq("id", inquiry.user_id).maybeSingle(),
    ]);

    return {
      inquiry,
      messages: messages ?? [],
      product: product ?? null,
      isOwner: inquiry.user_id === userId,
      customerName: profile?.full_name || profile?.email || "Pelanggan",
    };
  });

export const sendInquiryMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z.object({ inquiryId: z.string().uuid(), body: z.string().trim().min(1).max(2000) }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context as Ctx;
    const { data: inquiry } = await supabase
      .from("product_inquiries")
      .select("id, user_id, subject, status")
      .eq("id", data.inquiryId)
      .maybeSingle();
    if (!inquiry) return { ok: false as const, error: "Percakapan tidak ditemukan." };
    if (inquiry.status === "closed") return { ok: false as const, error: "Percakapan sudah ditutup." };

    const isOwner = inquiry.user_id === userId;
    const { error } = await supabase.from("product_inquiry_messages").insert({
      inquiry_id: data.inquiryId,
      sender_id: userId,
      sender_role: isOwner ? "customer" : "staff",
      body: data.body,
    });
    if (error) return { ok: false as const, error: "Pesan gagal dikirim. Coba lagi." };

    if (isOwner) {
      await notifyStaff("Pesan baru di chat produk", inquiry.subject, inquiry.id as string);
    } else {
      await supabase.from("notifications").insert({
        recipient_id: inquiry.user_id,
        type: "product_inquiry",
        title: "Balasan tim Ebrystore",
        message: `Ada balasan untuk pertanyaan "${inquiry.subject}".`,
        related_type: "product_inquiry",
        related_id: inquiry.id,
      });
    }
    return { ok: true as const };
  });

export const setInquiryStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) =>
    z.object({ inquiryId: z.string().uuid(), status: z.enum(["open", "answered", "closed"]) }).parse(data),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context as Ctx;
    const { error } = await supabase
      .from("product_inquiries")
      .update({ status: data.status })
      .eq("id", data.inquiryId);
    if (error) return { ok: false as const, error: "Status gagal diperbarui." };
    return { ok: true as const };
  });
