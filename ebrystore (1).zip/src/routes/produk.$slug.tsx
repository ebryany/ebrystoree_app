import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { CheckCircle2, ChevronRight, Clock3, Download, FileText, PackageCheck, ShieldCheck, ShoppingBag, Sparkles } from "lucide-react";

import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { Button } from "@/components/ui/button";
import { StickyActionBar } from "@/components/ebry/cards";
import { ProductReviewPanel } from "@/components/product/review-panel";
import { ProductInquiryButton } from "@/components/product/inquiry-dialog";
import { getProductDetail } from "@/lib/orders.functions";
import { effectivePrice, formatRupiah } from "@/lib/format";

const detailQuery = (slug: string) =>
  queryOptions({
    queryKey: ["product-detail", slug],
    queryFn: () => getProductDetail({ data: { slug } }),
  });

export const Route = createFileRoute("/produk/$slug")({
  loader: async ({ context, params }) => {
    const result = await context.queryClient.ensureQueryData(detailQuery(params.slug));
    if (!result.product) throw notFound();
    return result;
  },
  head: ({ loaderData }) => {
    if (!loaderData?.product) {
      return {
        meta: [
          { title: "Produk tidak ditemukan — Ebrystore" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const p = loaderData.product;
    const desc = (p.short_description ?? "Produk digital Ebrystore siap unduh.").slice(0, 155);
    return {
      meta: [
        { title: `${p.name} — Produk Digital Ebrystore`.slice(0, 60) },
        { name: "description", content: desc },
        { property: "og:title", content: `${p.name} — Ebrystore` },
        { property: "og:description", content: desc },
        { property: "og:type", content: "product" },
        { name: "twitter:card", content: "summary_large_image" },
        ...(p.thumbnail_url?.startsWith("https://")
          ? [
              { property: "og:image", content: p.thumbnail_url },
              { name: "twitter:image", content: p.thumbnail_url },
            ]
          : []),
      ],
    };
  },
  notFoundComponent: ProdukTidakDitemukan,
  component: DetailProduk,
});

function ProdukTidakDitemukan() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-3xl flex-1 px-4 py-20 text-center">
        <h1 className="text-2xl font-bold">Produk tidak ditemukan</h1>
        <p className="mt-2 text-sm text-muted-foreground">Produk mungkin sudah tidak diterbitkan.</p>
        <Button asChild className="mt-6">
          <Link to="/produk">Kembali ke katalog</Link>
        </Button>
      </main>
      <SiteFooter />
    </div>
  );
}

function DetailProduk() {
  const { slug } = Route.useParams();
  const { data } = useSuspenseQuery(detailQuery(slug));
  const p = data.product;
  if (!p) return null;
  const price = effectivePrice(Number(p.price), p.discount_price === null ? null : Number(p.discount_price));
  const discounted = price < Number(p.price);
  const downloadLimit = p.download_limit ?? 5;
  const uniqueStock = (p as { delivery_mode?: string }).delivery_mode === "unique";
  const stock = Number((p as { available_stock?: number }).available_stock ?? 0);
  const soldOut = uniqueStock && stock < 1;
  const validityDays = p.validity_days ?? 365;

  const highlights = [
    { icon: Download, label: `${downloadLimit}x unduh`, hint: "Kuota unduhan per pembelian" },
    { icon: Clock3, label: `${validityDays} hari akses`, hint: "Masa berlaku tautan unduhan" },
    { icon: ShieldCheck, label: "Rilis otomatis", hint: "Aktif setelah pembayaran diverifikasi" },
  ];

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 pb-10 pt-5 sm:pt-8">
        <nav aria-label="Breadcrumb" className="flex min-w-0 items-center gap-1.5 text-xs text-muted-foreground">
          <Link to="/produk" className="hover:text-foreground">
            Produk digital
          </Link>
          <ChevronRight className="size-3 shrink-0" aria-hidden="true" />
          <span className="truncate text-foreground">{p.name}</span>
        </nav>

        <section className="mt-4 border-y border-border bg-card sm:border sm:p-5 lg:grid lg:grid-cols-[minmax(0,0.92fr)_minmax(0,1.08fr)] lg:gap-8">
          <div className="min-w-0 py-4 sm:py-0">
            {p.thumbnail_url ? (
              <img
                src={p.thumbnail_url}
                alt={`Pratinjau produk ${p.name}`}
                loading="eager"
                fetchPriority="high"
                decoding="async"
                className="aspect-[4/3] w-full border border-border bg-surface object-contain"
              />
            ) : (
              <div
                className="grid aspect-[4/3] w-full place-items-center border border-border bg-secondary"
                aria-hidden="true"
              >
                <FileText className="size-10 text-muted-foreground" />
              </div>
            )}
          </div>

          <div className="min-w-0 border-t border-border py-5 sm:pt-5 lg:border-l lg:border-t-0 lg:py-1 lg:pl-8">
            <p className="inline-flex items-center gap-1.5 bg-secondary px-2.5 py-1 text-[11px] font-semibold text-secondary-foreground">
              <PackageCheck className="size-3.5" aria-hidden="true" /> Produk digital terverifikasi
            </p>
            <h1 className="mt-3 text-2xl font-bold leading-tight sm:text-3xl">{p.name}</h1>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              {p.short_description ?? "Berkas digital siap unduh setelah pembayaran diverifikasi."}
            </p>

            <div className="mt-4 flex items-center gap-4 border-y border-border py-3 text-sm">
              <span className="font-semibold text-accent">{p.sold_count ?? 0} terjual</span>
              <span className="h-4 w-px bg-border" aria-hidden="true" />
              <span className="inline-flex items-center gap-1.5 text-muted-foreground">
                <ShieldCheck className="size-4 text-accent" aria-hidden="true" /> Akses aman &amp; personal
              </span>
            </div>

            <div className="mt-5 bg-surface px-4 py-4">
              {discounted ? (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span className="line-through">{formatRupiah(Number(p.price))}</span>
                  <span className="bg-warning/20 px-2 py-0.5 text-xs font-semibold text-warning-foreground">
                    Hemat {Math.round((1 - price / Number(p.price)) * 100)}%
                  </span>
                </div>
              ) : null}
              <p className="mt-1 text-3xl font-bold text-primary">{formatRupiah(price)}</p>
            </div>

            <dl className="mt-5 grid grid-cols-[110px_minmax(0,1fr)] gap-x-4 gap-y-4 text-sm">
              <dt className="text-muted-foreground">Pengiriman</dt>
              <dd className="font-medium">Otomatis setelah pembayaran terverifikasi</dd>
              <dt className="text-muted-foreground">Kuota unduh</dt>
              <dd className="font-medium">{downloadLimit} kali</dd>
              <dt className="text-muted-foreground">Masa berlaku</dt>
              <dd className="font-medium">{validityDays} hari</dd>
              {uniqueStock ? (
                <>
                  <dt className="text-muted-foreground">Ketersediaan</dt>
                  <dd className={soldOut ? "font-semibold text-destructive" : "font-medium"}>
                    {soldOut ? "Stok habis" : `Tersedia ${stock}`}
                  </dd>
                </>
              ) : null}
            </dl>

            <p className="mt-5 flex items-start gap-2 border-t border-border pt-4 text-xs leading-relaxed text-muted-foreground">
              <CheckCircle2 className="mt-0.5 size-3.5 shrink-0 text-accent" aria-hidden="true" />
              Pembayaran aman melalui QRIS. Pesanan diproses setelah pembayaran terkonfirmasi.
            </p>
            <ProductInquiryButton productId={p.id} productName={p.name} className="mt-4 w-full lg:hidden" />
            <div className="mt-5 hidden grid-cols-2 gap-3 lg:grid">
              <ProductInquiryButton productId={p.id} productName={p.name} className="w-full" />
              {soldOut ? (
                <Button disabled className="w-full">Stok habis</Button>
              ) : (
                <Button asChild className="w-full">
                  <Link to="/checkout/produk/$slug" params={{ slug }}>
                    <ShoppingBag className="size-4" aria-hidden="true" /> Beli sekarang
                  </Link>
                </Button>
              )}
            </div>
          </div>
        </section>

        <section className="mt-4 border border-border bg-card" aria-labelledby="spesifikasi-produk">
          <h2 id="spesifikasi-produk" className="border-b border-border bg-surface px-5 py-4 text-base font-semibold">
            Spesifikasi produk
          </h2>
          <dl className="grid gap-x-8 gap-y-4 px-5 py-5 text-sm sm:grid-cols-2">
            {highlights.map((item) => (
              <div key={item.label} className="grid grid-cols-[24px_minmax(0,1fr)] gap-3">
                <item.icon className="mt-0.5 size-4 text-accent" aria-hidden="true" />
                <div>
                  <dt className="font-semibold">{item.label}</dt>
                  <dd className="mt-0.5 text-muted-foreground">{item.hint}</dd>
                </div>
              </div>
            ))}
            {p.version ? (
              <div className="grid grid-cols-[24px_minmax(0,1fr)] gap-3">
                <Sparkles className="mt-0.5 size-4 text-accent" aria-hidden="true" />
                <div><dt className="font-semibold">Versi produk</dt><dd className="mt-0.5 text-muted-foreground">{p.version}</dd></div>
              </div>
            ) : null}
          </dl>
        </section>

        <section className="mt-4 border border-border bg-card" aria-labelledby="deskripsi-produk">
          <h2 id="deskripsi-produk" className="border-b border-border bg-surface px-5 py-4 text-base font-semibold">
            Deskripsi produk
          </h2>
          <div className="space-y-7 px-5 py-6">
            <div>
              <h3 className="text-sm font-semibold">Tentang produk ini</h3>
              <p className="mt-2 max-w-4xl whitespace-pre-line text-sm leading-7 text-muted-foreground">
                {p.description ?? p.short_description ?? "Produk digital siap digunakan setelah pembayaran terverifikasi."}
              </p>
            </div>
            {p.usage_notes ? (
              <div>
                <h3 className="text-sm font-semibold">Cara pakai</h3>
                <p className="mt-2 max-w-4xl whitespace-pre-line text-sm leading-7 text-muted-foreground">{p.usage_notes}</p>
              </div>
            ) : null}
            <div>
              <h3 className="text-sm font-semibold">Proses pembelian</h3>
              <ol className="mt-4 grid gap-4 sm:grid-cols-4">
                {[
                  "Periksa detail lalu beli produk.",
                  "Selesaikan pembayaran QRIS.",
                  "Sistem memverifikasi pembayaran.",
                  "Produk tersedia di Produk saya.",
                ].map((step, i) => (
                  <li key={step} className="flex gap-3 border-t border-border pt-3 text-sm text-muted-foreground">
                    <span className="font-mono text-xs font-bold text-accent">0{i + 1}</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </section>

        <ProductReviewPanel productId={p.id} />

        <StickyActionBar className="lg:hidden">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs text-muted-foreground">{p.name}</p>
              <p className="text-base font-bold">{formatRupiah(price)}</p>
            </div>
            {soldOut ? (
              <Button disabled className="min-h-11 shrink-0">
                Stok habis
              </Button>
            ) : (
              <Button asChild className="min-h-11 shrink-0">
                <Link to="/checkout/produk/$slug" params={{ slug }}>
                  Beli sekarang
                </Link>
              </Button>
            )}
          </div>
        </StickyActionBar>
      </main>
      <SiteFooter />
    </div>
  );
}
