import { createFileRoute, Link, stripSearchParams, useNavigate } from "@tanstack/react-router";
import {
  infiniteQueryOptions,
  queryOptions,
  useSuspenseInfiniteQuery,
  useSuspenseQuery,
} from "@tanstack/react-query";
import { useEffect, useRef } from "react";

import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  EmptyState,
  ErrorState,
  HeroSkeleton,
  ProductGridSkeleton,
} from "@/components/catalog-states";
import { CatalogFilters } from "@/components/catalog-filters";
import { listCatalogCategories, listProducts } from "@/lib/catalog.functions";
import { effectivePrice, formatRupiah } from "@/lib/format";
import { ArrowRight, Download, ImageIcon, PackageCheck, ShieldCheck, Sparkles } from "lucide-react";

const PAGE_SIZE = 9;

const productsQuery = (filters: { q: string; category: string }) =>
  infiniteQueryOptions({
    queryKey: ["products", "infinite", PAGE_SIZE, filters.q, filters.category],
    queryFn: ({ pageParam }) =>
      listProducts({
        data: {
          page: pageParam,
          pageSize: PAGE_SIZE,
          q: filters.q || undefined,
          category: filters.category || undefined,
        },
      }),
    initialPageParam: 0,
    getNextPageParam: (lastPage) => lastPage.nextPage,
  });

const categoriesQuery = queryOptions({
  queryKey: ["categories", "product"],
  queryFn: () => listCatalogCategories({ data: { kind: "product" } }),
  staleTime: 5 * 60_000,
});

export const Route = createFileRoute("/produk/")({
  validateSearch: (search: { q?: unknown; kategori?: unknown }): { q?: string; kategori?: string } => ({
    q: typeof search.q === "string" ? search.q.slice(0, 80) : "",
    kategori: typeof search.kategori === "string" ? search.kategori.slice(0, 80) : "",
  }),
  search: { middlewares: [stripSearchParams({ q: "", kategori: "" })] },
  loaderDeps: ({ search }) => ({ q: search.q ?? "", category: search.kategori ?? "" }),
  head: () => ({
    meta: [
      { title: "Produk Digital — Ebrystore" },
      {
        name: "description",
        content:
          "Katalog produk digital Ebrystore: file, template, dan lisensi yang langsung dapat diunduh setelah pembayaran terverifikasi.",
      },
      { property: "og:title", content: "Produk Digital — Ebrystore" },
      {
        property: "og:description",
        content: "Jelajahi produk digital Ebrystore dengan akses unduhan otomatis setelah pembayaran.",
      },
    ],
  }),
  loader: async ({ context, deps }) => {
    await Promise.all([
      context.queryClient.ensureInfiniteQueryData(productsQuery(deps)),
      context.queryClient.ensureQueryData(categoriesQuery),
    ]);
  },
  pendingMs: 200,
  pendingComponent: () => (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:py-12">
        <HeroSkeleton />
        <div className="mt-8">
          <ProductGridSkeleton />
        </div>
      </main>
      <SiteFooter />
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-12">
        <ErrorState message={error.message || "Gagal memuat katalog produk."} />
      </main>
      <SiteFooter />
    </div>
  ),
  component: HalamanProduk,
});

function HalamanProduk() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/produk/" });
  const filters = { q: search.q ?? "", category: search.kategori ?? "" };
  const { data, hasNextPage, isFetchingNextPage, fetchNextPage } =
    useSuspenseInfiniteQuery(productsQuery(filters));
  const { data: categories } = useSuspenseQuery(categoriesQuery);
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  const firstPage = data.pages[0];
  const items = data.pages.flatMap((page) => page.items);
  const total = firstPage.total;
  const isFiltered = Boolean(filters.q || filters.category);

  useEffect(() => {
    const node = sentinelRef.current;
    if (!node || !hasNextPage) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting && !isFetchingNextPage) void fetchNextPage();
      },
      { rootMargin: "300px 0px" },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="w-full flex-1 bg-secondary/25">
        <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
        <section className="border-b border-border pb-7 sm:pb-8">
          <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
            <div className="max-w-2xl">
              <span className="inline-flex items-center gap-2 text-xs font-bold uppercase text-primary">
                <Sparkles className="size-4" aria-hidden="true" /> Etalase digital
              </span>
              <h1 className="mt-2 text-2xl font-bold sm:text-4xl">Katalog produk digital</h1>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground sm:text-base">
                Temukan produk yang kamu butuhkan dan dapatkan akses otomatis setelah pembayaran terverifikasi.
              </p>
            </div>
            <div className="flex gap-5 border-l-2 border-primary pl-4 text-xs text-muted-foreground sm:text-sm">
              <span className="inline-flex items-center gap-2"><Download className="size-4 text-primary" aria-hidden="true" /> 5x unduhan</span>
              <span className="inline-flex items-center gap-2"><ShieldCheck className="size-4 text-primary" aria-hidden="true" /> 365 hari</span>
            </div>
          </div>
        </section>

        <div className="mt-6 max-w-xl">
          <CatalogFilters
            q={search.q ?? ""}
            category={search.kategori ?? ""}
            categories={categories.items}
            placeholder="Cari produk digital…"
            onChange={(next) =>
              void navigate({
                search: (prev: { q?: string; kategori?: string }) => ({
                  q: next.q ?? prev.q ?? "",
                  kategori: next.category ?? prev.kategori ?? "",
                }),
                replace: true,
              })
            }
          />
        </div>

        <div className="mt-7">
          {firstPage.error ? (
            <ErrorState message={firstPage.error} />
          ) : items.length === 0 && isFiltered ? (
            <EmptyState
              title="Tidak ada produk yang cocok"
              description="Coba ubah kata kunci pencarian atau pilih kategori lain."
              hints={[
                "Gunakan kata kunci yang lebih singkat, misalnya nama template atau topiknya.",
                "Filter kategori bisa dimatikan dengan menekan tombol Semua.",
              ]}
              action={
                <Button onClick={() => void navigate({ search: { q: "", kategori: "" }, replace: true })}>
                  Reset filter
                </Button>
              }
              secondaryAction={
                <Button asChild variant="outline">
                  <Link to="/layanan">Lihat bantuan tugas</Link>
                </Button>
              }
            />
          ) : items.length === 0 ? (
            <EmptyState
              title="Belum ada produk yang tayang"
              description="Katalog produk digital sedang disiapkan tim Ebrystore. Produk baru akan langsung tampil di halaman ini begitu dipublikasikan."
              hints={[
                "Setiap produk berisi file digital yang bisa diunduh maksimal 5 kali selama 365 hari.",
                "Akses unduhan terbit otomatis setelah pembayaran kamu terverifikasi.",
                "Butuh pengerjaan tugas, bukan file jadi? Lihat paket pendampingan akademik.",
              ]}
              action={
                <Button asChild>
                  <Link to="/layanan">Lihat bantuan tugas</Link>
                </Button>
              }
              secondaryAction={
                <Button asChild variant="outline">
                  <Link to="/bantuan">Pusat bantuan</Link>
                </Button>
              }
            />
          ) : (
            <>
              <div className="mb-4 flex items-center justify-between gap-4">
                <div>
                  <h2 className="text-lg font-bold">Pilihan untuk kamu</h2>
                  <p className="mt-0.5 text-xs text-muted-foreground" aria-live="polite">
                    Menampilkan {items.length} dari {total} produk
                  </p>
                </div>
                {isFiltered ? <Badge variant="secondary">Hasil filter</Badge> : null}
              </div>
              <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4 xl:grid-cols-5">
              {items.map((item) => {
                const price = effectivePrice(Number(item.price), item.discount_price === null ? null : Number(item.discount_price));
                const discounted = price < Number(item.price);
                const discountPct = discounted
                  ? Math.round((1 - price / Number(item.price)) * 100)
                  : 0;
                return (
                  <li
                    key={item.id}
                    className="group relative flex min-w-0 flex-col overflow-hidden rounded-lg border border-border bg-card shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/30 hover:shadow-lifted"
                  >
                    <div className="relative overflow-hidden">
                      {item.thumbnail_url ? (
                        <img
                          src={item.thumbnail_url}
                          alt={`Pratinjau produk ${item.name}`}
                          loading="lazy" decoding="async"
                          className="aspect-square w-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                      ) : (
                        <div
                          className="flex aspect-square w-full items-center justify-center bg-secondary"
                          aria-hidden="true"
                        >
                          <ImageIcon className="size-8 text-muted-foreground/50" />
                        </div>
                      )}
                      {discounted ? (
                        <Badge className="absolute left-2 top-2 shadow-card">Hemat {discountPct}%</Badge>
                      ) : null}
                      <span className="absolute bottom-2 left-2 inline-flex items-center gap-1 rounded-full bg-background/90 px-2 py-1 text-[10px] font-semibold text-foreground backdrop-blur-sm">
                        <PackageCheck className="size-3 text-primary" aria-hidden="true" /> Otomatis
                      </span>
                    </div>
                    <div className="flex min-w-0 flex-1 flex-col p-3 sm:p-4">
                      <h3 className="line-clamp-2 text-sm font-semibold leading-snug sm:text-base">{item.name}</h3>
                      <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-muted-foreground sm:text-sm">
                        {item.short_description ?? "Produk digital siap unduh."}
                      </p>
                      <div className="mt-auto flex flex-col gap-1 pt-4">
                        {discounted ? (
                          <span className="text-[10px] text-muted-foreground line-through sm:text-xs">
                            {formatRupiah(Number(item.price))}
                          </span>
                        ) : null}
                        <span className="truncate text-base font-bold text-primary sm:text-lg">{formatRupiah(price)}</span>
                      </div>
                      <Button asChild size="sm" variant="secondary" className="mt-3 min-h-9 w-full text-xs group-hover:bg-primary group-hover:text-primary-foreground">
                        <Link to="/produk/$slug" params={{ slug: item.slug }}>
                          Detail
                          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                        </Link>
                      </Button>
                    </div>
                  </li>
                );
              })}
              </ul>
              {isFetchingNextPage ? (
                <div className="mt-5">
                  <ProductGridSkeleton count={3} />
                </div>
              ) : null}
              <div ref={sentinelRef} aria-hidden="true" className="h-px" />
              {hasNextPage ? (
                <div className="mt-6 flex justify-center">
                  <Button
                    variant="outline"
                    className="min-h-11"
                    onClick={() => void fetchNextPage()}
                    disabled={isFetchingNextPage}
                  >
                    {isFetchingNextPage ? "Memuat…" : "Muat lebih banyak"}
                  </Button>
                </div>
              ) : (
                <p className="mt-6 text-center text-sm text-muted-foreground">
                  Semua produk sudah ditampilkan.
                </p>
              )}
            </>
          )}
        </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}