import { Component, Suspense, type ReactNode } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import {
  ArrowRight,
  BadgePercent,
  BookOpen,
  Bot,
  ChevronRight,
  ClipboardList,
  Download,
  FileText,
  GraduationCap,
  Headphones,
  LifeBuoy,
  PackageCheck,
  Receipt,
  Sparkles,
  Zap,
} from "lucide-react";

import marketplaceBanner from "@/assets/home-marketplace-banner.jpg";
import { PageShell } from "@/components/page-shell";
import { MarketplaceProductCard, MarketplaceServiceCard } from "@/components/home/catalog-cards";
import {
  CardsSkeleton,
  SectionEmpty,
  SectionError,
  SectionHeading,
} from "@/components/home/section-states";
import { Button } from "@/components/ui/button";
import { getStorefrontSummary, listProducts, listServices } from "@/lib/catalog.functions";

const summaryQuery = queryOptions({
  queryKey: ["storefront-summary"],
  queryFn: () => getStorefrontSummary(),
});

const productsQuery = queryOptions({
  queryKey: ["storefront-products"],
  queryFn: () => listProducts({ data: {} }),
});

const servicesQuery = queryOptions({
  queryKey: ["storefront-services"],
  queryFn: () => listServices({ data: {} }),
});

/** OD-HOME-02: statistik hero hanya tampil jika katalog sudah cukup terisi. */
function statsAreMeaningful(productCount: number, serviceCount: number) {
  return productCount + serviceCount >= 5 || (productCount >= 3 && serviceCount >= 2);
}

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Ebrystore — Layanan Jasa Produk Digital" },
      {
        name: "description",
        content:
          "Ebrystore: beli produk digital siap unduh dan pesan bantuan tugas kuliah dengan progres terpantau. Pembayaran QRIS atau transfer terverifikasi.",
      },
      {
        name: "keywords",
        content:
          "ebrystore, ebrystore produk digital, jasa produk digital, bantuan tugas kuliah, joki tugas, template akademik, e-book digital",
      },
      { property: "og:title", content: "Ebrystore — Layanan Jasa Produk Digital" },
      {
        property: "og:description",
        content:
          "Ebrystore: beli produk digital siap unduh dan pesan bantuan tugas kuliah dengan progres terpantau. Pembayaran QRIS atau transfer terverifikasi.",
      },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://ebrystore.my.id/" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Ebrystore — Layanan Jasa Produk Digital" },
      {
        name: "twitter:description",
        content:
          "Ebrystore: produk digital siap unduh dan bantuan tugas kuliah dengan progres terpantau.",
      },
    ],
    links: [{ rel: "canonical", href: "https://ebrystore.my.id/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: "Ebrystore",
          url: "https://ebrystore.my.id/",
          inLanguage: "id-ID",
          description:
            "Ebrystore menyediakan produk digital siap unduh dan layanan bantuan tugas kuliah dengan progres terpantau.",
          potentialAction: {
            "@type": "SearchAction",
            target: "https://ebrystore.my.id/produk?q={search_term_string}",
            "query-input": "required name=search_term_string",
          },
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "Ebrystore",
          url: "https://ebrystore.my.id/",
          description:
            "Ebrystore adalah platform produk digital dan layanan pendampingan tugas kuliah.",
        }),
      },
    ],
  }),
  loader: async ({ context }) => {
    await Promise.all([
      context.queryClient.ensureQueryData(summaryQuery),
      context.queryClient.ensureQueryData(productsQuery),
      context.queryClient.ensureQueryData(servicesQuery),
    ]);
  },
  component: Beranda,
  errorComponent: () => (
    <PageShell>
      <p className="py-24 text-center text-sm text-muted-foreground">
        Halaman gagal dimuat. Silakan muat ulang.
      </p>
    </PageShell>
  ),
});

function Beranda() {
  return (
    <PageShell>
      <div className="bg-surface pb-12">
        <MarketplaceHero />
        <ShortcutSection />
        <SectionSuspense fallback={<CardsSkeleton count={6} />} queryKey={productsQuery.queryKey}>
          <ProductsSection />
        </SectionSuspense>
        <SectionSuspense fallback={<CardsSkeleton count={4} />} queryKey={servicesQuery.queryKey}>
          <ServicesSection />
        </SectionSuspense>
        <SectionSuspense fallback={<CardsSkeleton count={10} />} queryKey={productsQuery.queryKey}>
          <RecommendationsSection />
        </SectionSuspense>
      </div>
      <MarketplaceInfo />
    </PageShell>
  );
}


function MarketplaceHero() {
  return (
    <section className="mx-auto w-full max-w-7xl px-4 pt-4 lg:pt-6">
      <div className="grid gap-1 md:grid-cols-[2fr_1fr]">
        <div className="relative min-h-64 overflow-hidden bg-primary text-primary-foreground sm:min-h-80 lg:min-h-96">
          <img src={marketplaceBanner} alt="Produk digital dan layanan Ebrystore" width={1600} height={650} className="absolute inset-0 size-full object-cover" fetchPriority="high" />
          <div className="relative flex min-h-64 max-w-2xl flex-col justify-center p-6 sm:min-h-80 sm:p-10 lg:min-h-96 lg:p-12">
            <span className="mb-3 flex w-fit items-center gap-1.5 bg-card/10 px-2 py-1 text-[11px] font-semibold backdrop-blur-sm lg:text-xs">
              <Zap className="size-3.5 text-warning" aria-hidden="true" /> Pilihan digital terpercaya
            </span>
            <h1 className="text-2xl font-bold leading-tight sm:text-4xl lg:text-5xl">Belanja produk digital, bereskan tugas lebih cepat.</h1>
            <p className="mt-3 max-w-md text-sm leading-relaxed text-primary-foreground/80 lg:text-base">Pembayaran QRIS, pengiriman otomatis, dan progres layanan tercatat dalam satu akun.</p>
            <Button asChild className="mt-5 w-fit bg-card text-primary hover:bg-card/90">
              <Link to="/produk">Belanja sekarang <ArrowRight className="size-4" /></Link>
            </Button>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-1 md:grid-cols-1">
          <Link to="/layanan" className="flex min-h-28 items-end bg-accent p-4 text-accent-foreground transition-opacity hover:opacity-90 sm:p-5 lg:min-h-40 lg:p-6">
            <span><GraduationCap className="mb-2 size-6 lg:size-7" aria-hidden="true" /><strong className="block text-base lg:text-lg">Bantuan tugas</strong><span className="text-xs opacity-80 lg:text-sm">Pilih paket sesuai kebutuhan</span></span>
          </Link>
          <Link to="/dashboard" className="flex min-h-28 items-end bg-warning p-4 text-warning-foreground transition-opacity hover:opacity-90 sm:p-5 lg:min-h-40 lg:p-6">
            <span><PackageCheck className="mb-2 size-6 lg:size-7" aria-hidden="true" /><strong className="block text-base lg:text-lg">Pantau pesanan</strong><span className="text-xs opacity-80 lg:text-sm">Status selalu tercatat</span></span>
          </Link>
        </div>
      </div>
    </section>
  );
}

const quickActions = [
  {
    to: "/produk" as const,
    icon: Download,
    title: "Produk digital",
    desc: "File siap unduh",
  },
  { to: "/produk" as const, icon: Bot, title: "AI Premium", desc: "Akun & akses AI" },
  { to: "/produk" as const, icon: FileText, title: "Template", desc: "Dokumen siap pakai" },
  {
    to: "/layanan" as const,
    icon: ClipboardList,
    title: "Bantuan tugas",
    desc: "Pendampingan akademik",
  },
  {
    to: "/dashboard" as const,
    icon: Receipt,
    title: "Lacak pesanan",
    desc: "Status & invoice",
  },
  {
    to: "/bantuan" as const,
    icon: LifeBuoy,
    title: "Pusat bantuan",
    desc: "FAQ & kontak",
  },
  { to: "/artikel" as const, icon: BookOpen, title: "Artikel", desc: "Panduan pilihan" },
  { to: "/bantuan" as const, icon: Headphones, title: "Hubungi kami", desc: "Bantuan pelanggan" },
];

/** Panel quick-action bergaya aplikasi perbankan, mengambang di atas hero. */
function ShortcutSection() {
  return (
    <section aria-label="Kategori Ebrystore" className="mx-auto w-full max-w-7xl px-4 pt-4 lg:pt-6">
      <div className="border border-border bg-card">
        <div className="border-b border-border px-4 py-3 lg:px-6 lg:py-4"><h2 className="text-sm font-semibold uppercase text-muted-foreground lg:text-base">Kategori</h2></div>
        <div className="grid grid-cols-4 divide-x divide-y divide-border sm:grid-cols-8 sm:divide-y-0">
        {quickActions.map((action) => (
          <Link
            key={action.title}
            to={action.to}
            className="group flex min-w-0 flex-col items-center gap-2 bg-card px-2 py-4 text-center transition-colors hover:bg-surface focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring sm:py-5 lg:py-6"
          >
            <span className="grid size-10 place-items-center rounded-full bg-surface-selected text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground sm:size-12 lg:size-14">
              <action.icon className="size-5" aria-hidden="true" strokeWidth={1.75} />
            </span>
            <span className="min-w-0">
              <span className="block text-[11px] font-semibold leading-tight sm:text-xs lg:text-sm">{action.title}</span>
              <span className="mt-0.5 hidden text-[10px] text-muted-foreground sm:block lg:text-xs">{action.desc}</span>
            </span>
          </Link>
        ))}
      </div>
      </div>
    </section>
  );
}

function ProductsSection() {
  const query = useSuspenseQuery(productsQuery);
  const items = query.data?.items?.slice(0, 6) ?? [];
  const failed = query.isError || Boolean(query.data?.error);

  return (
    <section className="mx-auto w-full max-w-7xl px-4 pt-4 lg:pt-6">
      <MarketplaceHeading icon={BadgePercent} title="Penawaran produk digital" to="/produk" />
      <div>
        {failed ? (
          <SectionError
            message="Katalog produk sedang tidak dapat dimuat."
            onRetry={() => query.refetch()}
          />
        ) : items.length === 0 ? (
          <SectionEmpty
            title="Belum banyak produk tersedia."
            description="Kami sedang menyiapkan pilihan baru. Lihat kembali dalam waktu dekat."
          />
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6">
            {items.map((item) => (
              <MarketplaceProductCard key={item.id} item={item} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function ServicesSection() {
  const query = useSuspenseQuery(servicesQuery);
  const items = query.data?.items?.slice(0, 6) ?? [];
  const failed = query.isError || Boolean(query.data?.error);

  return (
    <section className="mx-auto w-full max-w-7xl px-4 pt-4 lg:pt-6">
      <MarketplaceHeading icon={Sparkles} title="Layanan pilihan" to="/layanan" />
      <div>
        {failed ? (
          <SectionError
            message="Katalog layanan sedang tidak dapat dimuat."
            onRetry={() => query.refetch()}
          />
        ) : items.length === 0 ? (
          <SectionEmpty
            title="Layanan baru sedang disiapkan."
            description="Layanan yang sudah aktif akan tampil di bagian ini."
          />
        ) : (
          <div className="grid gap-px bg-border sm:grid-cols-2 lg:grid-cols-4">
            {items.map((item) => (
              <MarketplaceServiceCard key={item.id} item={item} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function RecommendationsSection() {
  const query = useSuspenseQuery(productsQuery);
  const items = query.data?.items ?? [];
  if (query.isError || query.data?.error || items.length === 0) return null;
  return (
    <section className="mx-auto w-full max-w-7xl px-4 pt-4 lg:pt-6">
      <div className="border-b-2 border-primary bg-card px-4 py-4 text-center lg:px-6">
        <h2 className="text-sm font-bold uppercase text-primary lg:text-base">Rekomendasi untukmu</h2>
      </div>
      <div className="grid grid-cols-2 gap-2 pt-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 lg:gap-3 lg:pt-3">
        {items.map((item) => <MarketplaceProductCard key={`recommended-${item.id}`} item={item} />)}
      </div>
      <div className="flex justify-center pt-5 lg:pt-6"><Button asChild variant="outline" className="lg:px-8 lg:py-6 lg:text-base"><Link to="/produk">Lihat lainnya</Link></Button></div>
    </section>
  );
}

function MarketplaceHeading({ icon: Icon, title, to }: { icon: typeof Sparkles; title: string; to: "/produk" | "/layanan" }) {
  return (
    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center border border-b-0 border-border bg-card px-4 py-3 lg:px-6 lg:py-4">
      <h2 className="flex min-w-0 items-center gap-2 text-sm font-bold uppercase text-primary lg:text-base"><Icon className="size-4 shrink-0 lg:size-5" aria-hidden="true" />{title}</h2>
      <Link to={to} className="flex shrink-0 items-center gap-1 text-xs font-semibold text-primary lg:text-sm">Lihat semua <ChevronRight className="size-4" /></Link>
    </div>
  );
}

function MarketplaceInfo() {
  return (
    <section className="border-t border-border bg-card">
      <div className="mx-auto w-full max-w-7xl px-4 py-12 lg:py-16">
        <h2 className="text-base font-bold lg:text-lg">Ebrystore — Produk Digital dan Bantuan Tugas Online</h2>
        <div className="mt-4 grid gap-6 text-xs leading-relaxed text-muted-foreground md:grid-cols-3 lg:gap-10 lg:text-sm">
          <div><h3 className="font-semibold text-foreground">Belanja produk digital lebih mudah</h3><p className="mt-2">Temukan akun premium, panduan, dan file siap pakai. Produk tersedia melalui akun setelah pembayaran berhasil diverifikasi.</p></div>
          <div><h3 className="font-semibold text-foreground">Layanan dengan progres transparan</h3><p className="mt-2">Pilih paket sesuai kebutuhan, pantau progres pengerjaan, periksa hasil, dan ajukan revisi dari halaman pesanan.</p></div>
          <div><h3 className="font-semibold text-foreground">Pembayaran dan akses terlindungi</h3><p className="mt-2">Harga dihitung oleh sistem, pembayaran mendukung QRIS, dan riwayat transaksi tersimpan rapi pada akunmu.</p></div>
        </div>
        <div className="mt-8 flex flex-wrap gap-x-5 gap-y-2 border-t border-border pt-5 text-xs font-semibold text-primary">
          <Link to="/bantuan">Pusat Bantuan</Link><Link to="/syarat-ketentuan">Syarat & Ketentuan</Link><Link to="/kebijakan-privasi">Privasi</Link><Link to="/kebijakan-refund">Kebijakan Refund</Link>
        </div>
      </div>
    </section>
  );
}

type ErrorBoundaryProps = { children: ReactNode; onReset: () => void };
type ErrorBoundaryState = { hasError: boolean };

class SectionErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(_error: unknown): ErrorBoundaryState {
    return { hasError: true };
  }

  override render() {
    if (this.state.hasError) {
      return (
        <SectionError
          message="Bagian ini gagal dimuat."
          onRetry={() => {
            this.props.onReset();
            this.setState({ hasError: false });
          }}
        />
      );
    }
    return this.props.children;
  }
}

function SectionSuspense({
  children,
  fallback,
  queryKey,
}: {
  children: ReactNode;
  fallback: ReactNode;
  queryKey: unknown[];
}) {
  const queryClient = useQueryClient();
  return (
    <Suspense fallback={fallback}>
      <SectionErrorBoundary onReset={() => queryClient.resetQueries({ queryKey })}>
        {children}
      </SectionErrorBoundary>
    </Suspense>
  );
}
