import { createFileRoute, Link, stripSearchParams, useNavigate } from "@tanstack/react-router";
import {
  infiniteQueryOptions,
  queryOptions,
  useSuspenseInfiniteQuery,
  useSuspenseQuery,
} from "@tanstack/react-query";
import { useEffect, useRef } from "react";

import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  EmptyState,
  ErrorState,
  HeroSkeleton,
  ServiceGridSkeleton,
} from "@/components/catalog-states";
import { CatalogFilters } from "@/components/catalog-filters";
import { listCatalogCategories, listServices } from "@/lib/catalog.functions";
import { formatRupiah } from "@/lib/format";
import {
  ArrowRight,
  CalendarClock,
  CheckCircle2,
  ClipboardCheck,
  Layers3,
  RefreshCw,
  Sparkles,
} from "lucide-react";

const PAGE_SIZE = 6;

const servicesQuery = (filters: { q: string; category: string }) =>
  infiniteQueryOptions({
    queryKey: ["services", "infinite", PAGE_SIZE, filters.q, filters.category],
    queryFn: ({ pageParam }) =>
      listServices({
        data: {
          page: pageParam,
          pageSize: PAGE_SIZE,
          q: filters.q || undefined,
          category: filters.category || undefined,
        },
      }),
    initialPageParam: 0,
    getNextPageParam: (lastPage) => lastPage.nextPage,
  });

const categoriesQuery = queryOptions({
  queryKey: ["categories", "service"],
  queryFn: () => listCatalogCategories({ data: { kind: "service" } }),
  staleTime: 5 * 60_000,
});

export const Route = createFileRoute("/layanan/")({
  validateSearch: (search: { q?: unknown; kategori?: unknown }): { q?: string; kategori?: string } => ({
    q: typeof search.q === "string" ? search.q.slice(0, 80) : "",
    kategori: typeof search.kategori === "string" ? search.kategori.slice(0, 80) : "",
  }),
  search: { middlewares: [stripSearchParams({ q: "", kategori: "" })] },
  loaderDeps: ({ search }) => ({ q: search.q ?? "", category: search.kategori ?? "" }),
  head: () => ({
    meta: [
      { title: "Jasa Digital & Bantuan Project — Ebrystore" },
      {
        name: "description",
        content:
          "Temukan jasa digital, bantuan project, dan jasa tugas Ebrystore dengan pilihan paket, estimasi, revisi, dan progres yang jelas.",
      },
      { property: "og:title", content: "Jasa Digital & Bantuan Project — Ebrystore" },
      {
        property: "og:description",
        content: "Pilih jasa digital dan bantuan project dengan harga, estimasi waktu, serta revisi yang transparan.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: async ({ context, deps }) => {
    await Promise.all([
      context.queryClient.ensureInfiniteQueryData(servicesQuery(deps)),
      context.queryClient.ensureQueryData(categoriesQuery),
    ]);
  },
  pendingMs: 200,
  pendingComponent: () => (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:py-12">
        <HeroSkeleton />
        <div className="mt-8">
          <ServiceGridSkeleton />
        </div>
      </main>
      <SiteFooter />
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-12">
        <ErrorState message={error.message || "Gagal memuat katalog jasa digital."} />
      </main>
      <SiteFooter />
    </div>
  ),
  component: HalamanLayanan,
});

function HalamanLayanan() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/layanan/" });
  const filters = { q: search.q ?? "", category: search.kategori ?? "" };
  const { data, hasNextPage, isFetchingNextPage, fetchNextPage } =
    useSuspenseInfiniteQuery(servicesQuery(filters));
  const { data: categories } = useSuspenseQuery(categoriesQuery);
  const sentinelRef = useRef<HTMLDivElement | null>(null);

  const firstPage = data.pages[0];
  const items = data.pages.flatMap((page) => page.items);
  const total = firstPage.total;
  const isFiltered = Boolean(filters.q || filters.category);

  useEffect(() => {
    const node = sentinelRef.current;
    if (!node || !hasNextPage) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting && !isFetchingNextPage) void fetchNextPage();
      },
      { rootMargin: "300px 0px" },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="w-full flex-1 bg-secondary/25">
        <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
        <section className="relative overflow-hidden border-b border-border pb-7 sm:pb-8">
          <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end">
            <div className="max-w-3xl">
              <span className="inline-flex items-center gap-2 text-xs font-bold uppercase text-primary">
                <Sparkles className="size-4" aria-hidden="true" /> Solusi sesuai kebutuhanmu
              </span>
              <h1 className="mt-2 text-2xl font-bold sm:text-4xl">Jasa digital &amp; bantuan project</h1>
              <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
                Pilih bantuan untuk tugas, project, atau kebutuhan digital lainnya. Harga, waktu pengerjaan,
                dan jatah revisi terlihat jelas sebelum kamu memesan.
              </p>
            </div>
            <div className="grid grid-cols-3 divide-x divide-border rounded-lg border border-border bg-card shadow-card">
              <div className="flex min-w-0 flex-col items-center gap-1 px-3 py-3 text-center sm:min-w-28">
                <CalendarClock className="size-4 text-primary" aria-hidden="true" />
                <span className="text-[10px] font-semibold text-muted-foreground sm:text-xs">Estimasi jelas</span>
              </div>
              <div className="flex min-w-0 flex-col items-center gap-1 px-3 py-3 text-center sm:min-w-28">
                <ClipboardCheck className="size-4 text-primary" aria-hidden="true" />
                <span className="text-[10px] font-semibold text-muted-foreground sm:text-xs">Progres tercatat</span>
              </div>
              <div className="flex min-w-0 flex-col items-center gap-1 px-3 py-3 text-center sm:min-w-28">
                <RefreshCw className="size-4 text-primary" aria-hidden="true" />
                <span className="text-[10px] font-semibold text-muted-foreground sm:text-xs">Revisi tersedia</span>
              </div>
            </div>
          </div>
        </section>

        <div className="mt-6 max-w-xl">
          <CatalogFilters
            q={search.q ?? ""}
            category={search.kategori ?? ""}
            categories={categories.items}
            placeholder="Cari jasa atau jenis project…"
            onChange={(next) =>
              void navigate({
                search: (prev: { q?: string; kategori?: string }) => ({
                  q: next.q ?? prev.q ?? "",
                  kategori: next.category ?? prev.kategori ?? "",
                }),
                replace: true,
              })
            }
          />
        </div>

        <div className="mt-7">
          {firstPage.error ? (
            <ErrorState message={firstPage.error} />
          ) : items.length === 0 && isFiltered ? (
            <EmptyState
              title="Tidak ada layanan yang cocok"
              description="Coba kata kunci lain atau pilih kategori jasa yang berbeda."
              hints={[
                "Gunakan kata kunci singkat sesuai kebutuhan project kamu.",
                "Tekan tombol Semua untuk menampilkan seluruh jasa.",
              ]}
              action={
                <Button onClick={() => void navigate({ search: { q: "", kategori: "" }, replace: true })}>
                  Reset filter
                </Button>
              }
              secondaryAction={
                <Button asChild variant="outline">
                  <Link to="/produk">Lihat produk digital</Link>
                </Button>
              }
            />
          ) : items.length === 0 ? (
            <EmptyState
              title="Belum ada jasa yang tayang"
              description="Katalog jasa digital sedang disiapkan. Begitu dipublikasikan, pilihan paket, estimasi pengerjaan, dan jumlah revisinya akan tampil di sini."
              hints={[
                "Setiap paket menampilkan harga, estimasi hari pengerjaan, dan jumlah revisi gratis.",
                "Progres pesanan bisa dipantau dari mulai dikerjakan hingga hasil dikirim.",
                "Sementara menunggu, kamu bisa melihat katalog produk digital yang siap unduh.",
              ]}
              action={
                <Button asChild>
                  <Link to="/produk">Lihat produk digital</Link>
                </Button>
              }
              secondaryAction={
                <Button asChild variant="outline">
                  <Link to="/bantuan">Pusat bantuan</Link>
                </Button>
              }
            />
          ) : (
            <>
              <div className="mb-4 flex items-end justify-between gap-4">
                <div>
                  <h2 className="text-lg font-bold">Pilih jasa yang kamu butuhkan</h2>
                  <p className="mt-0.5 text-xs text-muted-foreground" aria-live="polite">
                    Menampilkan {items.length} dari {total} jasa
                  </p>
                </div>
                {isFiltered ? <Badge variant="secondary">Hasil filter</Badge> : null}
              </div>
              <ul className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {items.map((service) => {
                const packages = (service.service_packages ?? []).filter((p) => p.is_active !== false);
                const sortedPackages = [...packages].sort((a, b) => Number(a.price) - Number(b.price));
                const cheapestPackage = sortedPackages[0] ?? null;
                const cheapest = cheapestPackage ? Number(cheapestPackage.price) : null;
                return (
                  <li
                    key={service.id}
                    className="group relative flex min-w-0 flex-col overflow-hidden rounded-lg border border-border bg-card shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/30 hover:shadow-lifted"
                  >
                    <div className="flex items-start gap-3 border-b border-border/70 p-4">
                      <span className="grid size-11 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                        <Layers3 className="size-5" aria-hidden="true" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <h2 className="text-base font-semibold leading-snug sm:text-lg">
                          <Link
                            to="/layanan/$slug"
                            params={{ slug: service.slug }}
                            className="after:absolute after:inset-0 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          >
                            {service.name}
                          </Link>
                        </h2>
                        <p className="mt-1.5 line-clamp-2 text-sm leading-relaxed text-muted-foreground">
                          {service.short_description ?? "Bantuan project dengan alur pengerjaan yang jelas."}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-1 flex-col p-4">
                    <div className="flex items-end justify-between gap-3 rounded-lg bg-secondary/70 px-3.5 py-3">
                      {cheapest !== null ? (
                        <div>
                          <p className="text-[11px] font-medium text-muted-foreground">Mulai dari</p>
                          <p className="mt-0.5 text-xl font-bold text-primary">{formatRupiah(cheapest)}</p>
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground">Paket belum tersedia.</p>
                      )}
                      <Badge variant="outline" className="shrink-0 bg-card">{packages.length} paket</Badge>
                    </div>

                    {cheapestPackage ? (
                      <div className="mt-4">
                        <p className="text-xs font-semibold text-foreground">{cheapestPackage.name}</p>
                        <div className="mt-2 flex flex-wrap gap-2 text-[11px] font-medium text-muted-foreground">
                          <span className="inline-flex items-center gap-1.5 rounded-full border border-border px-2.5 py-1.5">
                            <CalendarClock className="size-3.5 text-primary" aria-hidden="true" />
                            {cheapestPackage.estimated_days ?? "-"} hari
                          </span>
                          <span className="inline-flex items-center gap-1.5 rounded-full border border-border px-2.5 py-1.5">
                            <RefreshCw className="size-3.5 text-primary" aria-hidden="true" />
                            {cheapestPackage.free_revisions ?? 0} revisi
                          </span>
                        </div>
                      </div>
                    ) : (
                      <p className="mt-4 inline-flex items-center gap-2 text-xs text-muted-foreground">
                        <CheckCircle2 className="size-4 text-primary" aria-hidden="true" /> Detail paket segera tersedia
                      </p>
                    )}

                    <Button asChild size="sm" variant="secondary" className="relative z-10 mt-auto min-h-10 w-full translate-y-0 pt-0 group-hover:bg-primary group-hover:text-primary-foreground">
                      <Link to="/layanan/$slug" params={{ slug: service.slug }}>
                        Lihat detail &amp; paket
                        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                      </Link>
                    </Button>
                    </div>
                  </li>
                );
              })}
              </ul>
              {isFetchingNextPage ? (
                <div className="mt-5">
                  <ServiceGridSkeleton count={2} />
                </div>
              ) : null}
              <div ref={sentinelRef} aria-hidden="true" className="h-px" />
              {hasNextPage ? (
                <div className="mt-6 flex justify-center">
                  <Button
                    variant="outline"
                    className="min-h-11"
                    onClick={() => void fetchNextPage()}
                    disabled={isFetchingNextPage}
                  >
                    {isFetchingNextPage ? "Memuat…" : "Muat lebih banyak"}
                  </Button>
                </div>
              ) : (
                <p className="mt-6 text-center text-sm text-muted-foreground">
                  Semua jasa sudah ditampilkan.
                </p>
              )}
            </>
          )}
        </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}