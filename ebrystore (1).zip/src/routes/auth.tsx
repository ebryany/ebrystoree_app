import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Eye, EyeOff, LockKeyhole, ShieldCheck } from "lucide-react";
import { toast } from "sonner";

import { SiteHeader } from "@/components/site-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useSession } from "@/hooks/use-session";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): { next?: string; mode?: "masuk" | "daftar" } => {
    const next = typeof s['next'] === "string" ? s['next'] : "";
    const mode = s['mode'] === "daftar" ? "daftar" : undefined;
    return { ...(next.startsWith("/") && !next.startsWith("//") ? { next } : {}), ...(mode ? { mode } : {}) };
  },
  head: () => ({
    meta: [
      { title: "Masuk atau Daftar — Ebrystore" },
      {
        name: "description",
        content:
          "Masuk ke akun Ebrystore untuk memantau pesanan, mengunduh produk digital, dan mengikuti progres bantuan tugas.",
      },
      { property: "og:title", content: "Masuk atau Daftar — Ebrystore" },
      {
        property: "og:description",
        content: "Akses pesanan dan produk digital Ebrystore lewat akun kamu.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: HalamanAuth,
});

function HalamanAuth() {
  const navigate = useNavigate();
  const { next, mode: initialMode } = Route.useSearch();
  const { user, loading } = useSession();
  const [mode, setMode] = useState<"masuk" | "daftar">(initialMode ?? "masuk");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [busy, setBusy] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const goNext = () => {
    if (next) {
      window.location.href = next;
      return;
    }
    navigate({ to: "/dashboard", replace: true });
  };

  useEffect(() => {
    if (!loading && user) {
      if (next) window.location.href = next;
      else navigate({ to: "/dashboard", replace: true });
    }
  }, [loading, user, navigate, next]);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    try {
      if (mode === "masuk") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("Berhasil masuk.");
        goNext();
      } else {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: `${window.location.origin}${next || "/dashboard"}`,
            data: { full_name: fullName },
          },
        });
        if (error) throw error;
        if (data.session) {
          toast.success("Akun dibuat. Mengarahkan ke dashboard…");
          goNext();
        } else {
          toast.success("Akun dibuat. Cek email untuk konfirmasi, lalu kamu akan masuk ke dashboard.");
          setMode("masuk");
        }
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : "Terjadi kesalahan.";
      toast.error(
        message.includes("Invalid login credentials")
          ? "Email atau kata sandi salah."
          : message.includes("already registered")
            ? "Email ini sudah terdaftar. Silakan masuk."
            : message,
      );
    } finally {
      setBusy(false);
    }
  }

  async function handleGoogle() {
    setBusy(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: `${window.location.origin}/auth${next ? `?next=${encodeURIComponent(next)}` : ""}`,
    });
    if (result.error) {
      setBusy(false);
      toast.error("Gagal masuk dengan Google. Coba lagi.");
      return;
    }
    if (result.redirected) return;
    goNext();
  }

  return (
    <div className="relative flex min-h-screen flex-col overflow-hidden bg-auth-gradient text-primary-foreground">
      <div className="auth-grid pointer-events-none absolute inset-0 opacity-40" aria-hidden="true" />
      <SiteHeader variant="dark" />
      <main className="relative z-10 mx-auto flex w-full max-w-md flex-1 flex-col px-4 pb-10 pt-8 sm:justify-center sm:pt-6">
        <div className="rounded-2xl border border-border bg-card p-5 text-card-foreground shadow-lifted sm:p-7">
          <div className="grid grid-cols-2 rounded-xl bg-muted p-1" aria-label="Pilih masuk atau daftar">
            <Button type="button" variant="ghost" className={mode === "masuk" ? "bg-card text-foreground shadow-sm hover:bg-card" : "text-muted-foreground"} onClick={() => setMode("masuk")}>Masuk</Button>
            <Button type="button" variant="ghost" className={mode === "daftar" ? "bg-card text-foreground shadow-sm hover:bg-card" : "text-muted-foreground"} onClick={() => setMode("daftar")}>Daftar</Button>
          </div>

          <div className="mt-6">
            <h1 className="text-2xl font-bold">{mode === "masuk" ? "Selamat datang kembali" : "Buat akun baru"}</h1>
            <p className="mt-1.5 text-sm leading-6 text-muted-foreground">
              {mode === "masuk" ? "Masuk untuk melanjutkan ke pesanan dan produk digitalmu." : "Satu akun untuk memesan, membayar, dan memantau progres."}
            </p>
          </div>

          <Button variant="outline" className="mt-6 h-12 w-full rounded-xl bg-card" onClick={handleGoogle} disabled={busy}>
            <span className="flex size-6 items-center justify-center rounded-full border border-border text-xs font-bold">G</span>
            Lanjutkan dengan Google
          </Button>

          <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground">
            <span className="h-px flex-1 bg-border" />atau gunakan email<span className="h-px flex-1 bg-border" />
          </div>

          <form className="space-y-4" onSubmit={handleSubmit}>
            {mode === "daftar" ? (
              <div className="space-y-2">
                <Label htmlFor="nama">Nama lengkap</Label>
                <Input
                  id="nama"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  autoComplete="name"
                  placeholder="Nama kamu"
                  className="h-12 rounded-xl bg-card"
                  required
                />
              </div>
            ) : null}
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                placeholder="nama@email.com"
                className="h-12 rounded-xl bg-card"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Kata sandi</Label>
              <div className="relative">
                <LockKeyhole className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                <Input id="password" type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={mode === "masuk" ? "current-password" : "new-password"} minLength={8} placeholder="Minimal 8 karakter" className="h-12 rounded-xl bg-card pl-10 pr-11" required />
                <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 size-10 -translate-y-1/2 text-muted-foreground" aria-label={showPassword ? "Sembunyikan kata sandi" : "Tampilkan kata sandi"} onClick={() => setShowPassword((value) => !value)}>
                  {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </Button>
              </div>
            </div>
            <Button type="submit" className="h-12 w-full rounded-xl bg-accent-gradient font-bold text-accent-foreground shadow-lg hover:opacity-90" disabled={busy}>
              {busy ? "Memproses…" : mode === "masuk" ? "Masuk ke akun" : "Buat akun"}
              {!busy ? <ArrowRight className="size-4" aria-hidden="true" /> : null}
            </Button>
          </form>
          <p className="mt-5 text-center text-xs leading-5 text-muted-foreground">
            Dengan melanjutkan, kamu menyetujui <Link to="/syarat-ketentuan" className="font-semibold text-foreground hover:text-primary">syarat & ketentuan</Link> serta <Link to="/kebijakan-privasi" className="font-semibold text-foreground hover:text-primary">kebijakan privasi</Link>.
          </p>
        </div>

        <p className="mt-5 flex items-center justify-center gap-1.5 text-center text-xs text-primary-foreground/55">
          <ShieldCheck className="size-3.5 text-accent" aria-hidden="true" />
          Transaksi terverifikasi dan tercatat rapi di akunmu.
        </p>
      </main>
    </div>
  );
}