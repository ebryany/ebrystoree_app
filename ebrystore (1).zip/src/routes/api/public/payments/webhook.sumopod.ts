import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const bodySchema = z.object({
  event_type: z.string().min(1).max(60),
  data: z.object({
    payment_id: z.string().min(1).max(120),
    order_id: z.string().min(1).max(160),
    amount: z.number(),
    status: z.string().max(40).optional().nullable(),
    payment_method: z.string().max(40).optional().nullable(),
    completed_at: z.string().max(60).optional().nullable(),
  }),
});

const envelopeSchema = z.object({
  event_type: z.string().min(1).max(60),
});

export const Route = createFileRoute("/api/public/payments/webhook/sumopod")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const sumopod = await import("@/lib/sumopod.server");
        const cfg = sumopod.sumopodConfig();
        if (!cfg) return new Response("not configured", { status: 503 });

        const raw = await request.text();
        if (!(await sumopod.verifyWebhook(raw, request.headers))) {
          return new Response("invalid signature", { status: 401 });
        }

        let payload: unknown;
        try {
          payload = JSON.parse(raw);
        } catch {
          return new Response("invalid payload", { status: 400 });
        }

        const envelope = envelopeSchema.safeParse(payload);
        if (!envelope.success) {
          return new Response("invalid payload", { status: 400 });
        }

        // Tombol "Save & Test" SumoPod mengirim envelope uji tanpa data pembayaran.
        // Setelah autentikasi webhook lolos, cukup balas sukses dan jangan menyentuh transaksi.
        if (envelope.data.event_type === "payment.test") {
          return new Response("ok", { status: 200 });
        }

        const result = bodySchema.safeParse(payload);
        if (!result.success) {
          return new Response("invalid payload", { status: 400 });
        }
        const parsed: z.infer<typeof bodySchema> = result.data;

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { data: byProvider } = await supabaseAdmin
          .from("payments")
          .select("id, status, expected_amount, payment_number")
          .eq("external_transaction_id", parsed.data.payment_id)
          .maybeSingle();

        // Fallback: cocokkan lewat nomor pembayaran (order_id provider bisa bersufiks).
        const paymentNumber = parsed.data.order_id.split("-").slice(0, 3).join("-");
        const { data: byNumber } = byProvider
          ? { data: null }
          : await supabaseAdmin
              .from("payments")
              .select("id, status, expected_amount, payment_number")
              .eq("payment_number", paymentNumber)
              .maybeSingle();

        const payment = byProvider ?? byNumber;

        const eventId = `${parsed.data.payment_id}:${parsed.event_type}`;

        async function logEvent(status: string, error?: string) {
          await supabaseAdmin.from("payment_events").insert({
            provider: "sumopod",
            external_event_id: eventId,
            payment_id: payment?.id ?? null,
            event_type: parsed.event_type,
            signature_valid: true,
            processing_status: status,
            processed_at: new Date().toISOString(),
            error: error ?? null,
          });
        }

        if (parsed.event_type !== "payment.completed") {
          await logEvent("skipped", `event ${parsed.event_type}`);
          return new Response("ok");
        }
        if (!payment) {
          await logEvent("failed", "payment not found");
          return new Response("ok");
        }
        if (payment.status === "paid") {
          await logEvent("skipped", "already settled");
          return new Response("ok");
        }
        if (Number(parsed.data.amount) !== Number(payment.expected_amount)) {
          await logEvent("failed", "amount mismatch");
          return new Response("ok");
        }

        // Validasi ulang ke API provider bila tersedia; jika endpoint status tidak ada,
        // gunakan status dari payload webhook yang sudah terverifikasi tanda tangannya.
        const detail = await sumopod.getPaymentStatus(cfg, parsed.data.payment_id);
        const effectiveStatus = (detail?.status ?? parsed.data.status ?? "").toLowerCase();
        const ok = ["completed", "paid", "success", "settled"].includes(effectiveStatus);
        if (!ok) {
          await logEvent("failed", "unverified status");
          return new Response("ok");
        }

        const settled = await sumopod.settleSumopodPayment(
          payment.id,
          parsed.data.payment_id,
          Number(payment.expected_amount),
        );
        await logEvent(settled.ok ? "processed" : "failed", settled.ok ? undefined : settled.error);

        if (settled.ok) {
          // Beritahu pemilik toko lewat Telegram bila pesanan jasa baru saja lunas.
          try {
            const { dispatchServiceOrderAlerts } = await import("@/lib/telegram.server");
            await dispatchServiceOrderAlerts();
          } catch (err) {
            console.error("[telegram] dispatch gagal:", err);
          }
        }
        return new Response("ok");
      },
    },
  },
});
