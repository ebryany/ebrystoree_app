import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Download } from "lucide-react";
import { toast } from "sonner";

import {
  AdminError,
  AdminLoading,
  AdminPageHeader,
  EmptyRow,
  ForbiddenState,
  Pager,
  useCan,
} from "@/components/admin/admin-ui";
import { StatusBadge, formatDateTime } from "@/components/admin/tx-ui";
import { useRealtimeRefresh } from "@/hooks/use-realtime-refresh";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { listOrders } from "@/lib/admin-transaction.functions";
import { ORDER_STATUS_LABEL, ORDER_TYPE_LABEL, PAYMENT_STATUS_LABEL } from "@/lib/transaction-labels";
import { formatRupiah } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/admin/orders/")({
  head: () => ({
    meta: [
      { title: "Daftar Order — Admin Ebrystore" },
      { name: "description", content: "Kelola seluruh order produk digital dan pesanan akademik Ebrystore." },
      { property: "og:title", content: "Daftar Order — Admin Ebrystore" },
      { property: "og:description", content: "Pencarian, filter, dan tindak lanjut order Ebrystore." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminOrders,
});

const PAGE_SIZE = 15;

function AdminOrders() {
  const canView = useCan("orders.view");
  const canExport = useCan("reports.export");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [type, setType] = useState("all");
  const [paymentStatus, setPaymentStatus] = useState("all");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [sort, setSort] = useState<"newest" | "oldest" | "amount_desc" | "amount_asc">("newest");
  const [page, setPage] = useState(1);

  const fetchOrders = useServerFn(listOrders);
  const { data, isPending, error } = useQuery({
    queryKey: ["admin-orders", search, status, type, paymentStatus, from, to, sort, page],
    queryFn: () => fetchOrders({ data: { search, status, type, paymentStatus, from, to, sort, page } }),
  });

  useRealtimeRefresh({
    channel: "admin-orders",
    tables: ["orders", "payments", "order_status_histories"],
    keys: [["admin-orders"]],
    enabled: canView,
  });

  if (!canView) return <ForbiddenState permission="orders.view" />;
  if ((data as any)?.forbidden) return <ForbiddenState permission={(data as any).permission} />;

  const items = (data as any)?.items ?? [];

  const exportCsv = () => {
    if (!items.length) return toast.error("Tidak ada data untuk diekspor.");
    const header = ["nomor", "customer", "jenis", "status", "total", "dibuat"];
    const rows = items.map((o: any) => [
      o.order_number,
      o.customer?.email ?? o.user_id,
      ORDER_TYPE_LABEL[o.order_type] ?? o.order_type,
      ORDER_STATUS_LABEL[o.status] ?? o.status,
      o.total,
      o.created_at,
    ]);
    const csv = [header, ...rows].map((r) => r.map((c: unknown) => `"${String(c ?? "")}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `orders-halaman-${page}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("CSV halaman ini diunduh.");
  };

  const reset = (fn: () => void) => {
    fn();
    setPage(1);
  };

  return (
    <div className="space-y-6">
      <AdminPageHeader
        title="Order"
        crumb="Order"
        description="Seluruh order produk digital dan pesanan akademik."
        actions={
          canExport ? (
            <Button variant="outline" size="sm" onClick={exportCsv}>
              <Download className="size-4" aria-hidden="true" /> Ekspor CSV
            </Button>
          ) : null
        }
      />

      <div className="grid gap-3 rounded-xl border border-border bg-card p-4 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <Label htmlFor="order-search">Cari nomor order</Label>
          <Input
            id="order-search"
            value={search}
            placeholder="ORD-…"
            onChange={(e) => reset(() => setSearch(e.target.value))}
          />
        </div>
        <div>
          <Label htmlFor="order-status">Status order</Label>
          <Select value={status} onValueChange={(v) => reset(() => setStatus(v))}>
            <SelectTrigger id="order-status">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua status</SelectItem>
              {Object.entries(ORDER_STATUS_LABEL).map(([k, v]) => (
                <SelectItem key={k} value={k}>
                  {v}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="order-type">Jenis order</Label>
          <Select value={type} onValueChange={(v) => reset(() => setType(v))}>
            <SelectTrigger id="order-type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua jenis</SelectItem>
              <SelectItem value="digital_product">Produk digital</SelectItem>
              <SelectItem value="service">Pesanan Akademik</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="order-payment">Status pembayaran</Label>
          <Select value={paymentStatus} onValueChange={(v) => reset(() => setPaymentStatus(v))}>
            <SelectTrigger id="order-payment">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua pembayaran</SelectItem>
              {Object.entries(PAYMENT_STATUS_LABEL).map(([k, v]) => (
                <SelectItem key={k} value={k}>
                  {v}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="order-from">Dari tanggal</Label>
          <Input id="order-from" type="date" value={from} onChange={(e) => reset(() => setFrom(e.target.value))} />
        </div>
        <div>
          <Label htmlFor="order-to">Sampai tanggal</Label>
          <Input id="order-to" type="date" value={to} onChange={(e) => reset(() => setTo(e.target.value))} />
        </div>
        <div>
          <Label htmlFor="order-sort">Urutkan</Label>
          <Select value={sort} onValueChange={(v) => reset(() => setSort(v as typeof sort))}>
            <SelectTrigger id="order-sort">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Terbaru</SelectItem>
              <SelectItem value="oldest">Terlama</SelectItem>
              <SelectItem value="amount_desc">Nilai tertinggi</SelectItem>
              <SelectItem value="amount_asc">Nilai terendah</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {isPending ? (
        <AdminLoading />
      ) : error || (data as any)?.error ? (
        <AdminError message={(data as any)?.error ?? "Data order tidak dapat dimuat."} />
      ) : !items.length ? (
        <EmptyRow message="Belum ada order yang cocok dengan filter ini." />
      ) : (
        <>
          <div className="overflow-x-auto rounded-xl border border-border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nomor</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Jenis</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Pembayaran</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead>Dibuat</TableHead>
                  <TableHead />
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((o: any) => (
                  <TableRow key={o.id}>
                    <TableCell className="font-mono text-xs">{o.order_number}</TableCell>
                    <TableCell className="max-w-[180px] truncate">
                      {o.customer?.full_name ?? o.customer?.email ?? "-"}
                    </TableCell>
                    <TableCell>{ORDER_TYPE_LABEL[o.order_type] ?? o.order_type}</TableCell>
                    <TableCell>
                      <StatusBadge value={o.status} />
                    </TableCell>
                    <TableCell>{o.payment ? <StatusBadge value={o.payment.status} kind="payment" /> : "-"}</TableCell>
                    <TableCell className="text-right">{formatRupiah(Number(o.total))}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">{formatDateTime(o.created_at)}</TableCell>
                    <TableCell className="text-right">
                      <Button asChild size="sm" variant="outline">
                        <Link to="/admin/orders/$id" params={{ id: o.id }}>
                          Detail
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <Pager page={page} pageSize={PAGE_SIZE} total={(data as any)?.total ?? 0} onChange={setPage} />
        </>
      )}
    </div>
  );
}
