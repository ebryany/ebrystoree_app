import { useState } from "react";
import { Link, Outlet, createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ExternalLink, LogOut, Menu, ShieldAlert, User } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { AccessProvider, AdminLoading } from "@/components/admin/admin-ui";
import { adminNav, ROLE_LABELS } from "@/lib/admin-nav";
import { getMyAccess } from "@/lib/admin.functions";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/admin")({
  component: AdminLayout,
});

function NavList({ permissions, isSuperAdmin, onNavigate }: { permissions: string[]; isSuperAdmin: boolean; onNavigate?: () => void }) {
  const can = (p: string) => isSuperAdmin || permissions.includes(p);

  return (
    <nav aria-label="Navigasi admin" className="space-y-5">
      {adminNav.map((group) => {
        const items = group.items.filter((item) => can(item.permission));
        if (items.length === 0) return null;
        return (
          <div key={group.label}>
            <p className="px-3 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
              {group.label}
            </p>
            <ul className="mt-2 space-y-1">
              {items.map((item) =>
                item.available && item.to ? (
                  <li key={item.label}>
                    <Link
                      to={item.to}
                      activeOptions={{ exact: item.exact ?? false }}
                      onClick={onNavigate}
                      className="flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                      activeProps={{ className: "bg-muted text-foreground" }}
                    >
                      <item.icon className="size-4 shrink-0" aria-hidden="true" />
                      <span className="truncate">{item.label}</span>
                    </Link>
                  </li>
                ) : (
                  <li
                    key={item.label}
                    aria-disabled="true"
                    className="flex cursor-not-allowed items-center gap-2 rounded-md px-3 py-2 text-sm text-muted-foreground/60"
                  >
                    <item.icon className="size-4 shrink-0" aria-hidden="true" />
                    <span className="truncate">{item.label}</span>
                    <Badge variant="outline" className="ml-auto shrink-0 text-[10px]">
                      Belum tersedia
                    </Badge>
                  </li>
                ),
              )}
            </ul>
          </div>
        );
      })}
    </nav>
  );
}

function AdminLayout() {
  const fetchAccess = useServerFn(getMyAccess);
  const [open, setOpen] = useState(false);
  const { data, isPending, error } = useQuery({ queryKey: ["my-access"], queryFn: () => fetchAccess({}) });

  const canEnter = !!data && (data.isSuperAdmin || data.permissions.includes("admin.dashboard.view"));

  if (isPending) {
    return (
      <div className="mx-auto w-full max-w-7xl px-4 py-10">
        <AdminLoading label="Memeriksa izin akses…" />
      </div>
    );
  }

  if (error || !canEnter) {
    return (
      <div className="mx-auto w-full max-w-md px-4 py-16 text-center">
        <div className="rounded-xl border border-border bg-card p-8 shadow-sm">
          <ShieldAlert className="mx-auto size-8 text-muted-foreground" aria-hidden="true" />
          <h1 className="mt-4 text-xl font-bold">Akses ditolak</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Akun Anda tidak memiliki izin <code>admin.dashboard.view</code> untuk membuka dashboard admin.
          </p>
          <Button asChild variant="outline" size="sm" className="mt-5">
            <Link to="/dashboard">Kembali ke akun saya</Link>
          </Button>
        </div>
      </div>
    );
  }

  const roleLabel = data.roles.map((r) => ROLE_LABELS[r] ?? r).join(", ") || "-";

  return (
    <AccessProvider value={data}>
      <div className="flex min-h-screen flex-col bg-muted/20">
        <header className="sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur">
          <div className="mx-auto grid w-full max-w-7xl grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 px-4 py-3">
            <div className="flex items-center gap-2">
              <Sheet open={open} onOpenChange={setOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Buka menu admin">
                    <Menu className="size-5" aria-hidden="true" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-72 overflow-y-auto p-4">
                  <SheetHeader>
                    <SheetTitle>Dashboard Admin</SheetTitle>
                  </SheetHeader>
                  <div className="mt-4">
                    <NavList
                      permissions={data.permissions}
                      isSuperAdmin={data.isSuperAdmin}
                      onNavigate={() => setOpen(false)}
                    />
                  </div>
                </SheetContent>
              </Sheet>
              <Link to="/admin" className="font-bold tracking-tight">
                Ebrystore <span className="text-muted-foreground">Admin</span>
              </Link>
            </div>

            <div className="min-w-0" />

            <div className="flex shrink-0 items-center gap-2">
              <Button asChild variant="ghost" size="sm" className="hidden sm:inline-flex">
                <Link to="/">
                  <ExternalLink className="mr-1 size-4" aria-hidden="true" />
                  Lihat website
                </Link>
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" aria-label="Menu akun admin">
                    <User className="size-4" aria-hidden="true" />
                    <span className="ml-1 hidden max-w-32 truncate sm:inline">{roleLabel}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel className="text-xs font-normal text-muted-foreground">
                    Peran: {roleLabel}
                    <br />
                    {data.permissions.length} izin aktif
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/dashboard">Akun saya</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/">Kembali ke website</Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onSelect={() => {
                      void supabase.auth.signOut();
                    }}
                  >
                    <LogOut className="mr-2 size-4" aria-hidden="true" />
                    Keluar
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        <div className="mx-auto grid w-full max-w-7xl flex-1 gap-8 px-4 py-8 lg:grid-cols-[240px_minmax(0,1fr)]">
          <aside className="hidden lg:block">
            <div className="sticky top-24">
              <NavList permissions={data.permissions} isSuperAdmin={data.isSuperAdmin} />
            </div>
          </aside>
          <main className="min-w-0">
            <Outlet />
          </main>
        </div>
      </div>
    </AccessProvider>
  );
}
