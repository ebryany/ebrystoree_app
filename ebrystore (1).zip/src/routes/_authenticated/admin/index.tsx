import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";

import { AdminError, AdminLoading, AdminPageHeader, ForbiddenState, useAccess } from "@/components/admin/admin-ui";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getAdminOverview } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({
    meta: [
      { title: "Ringkasan Dashboard — Admin Ebrystore" },
      { name: "description", content: "Ringkasan katalog, pengguna, dan aktivitas terbaru dashboard admin Ebrystore." },
      { property: "og:title", content: "Ringkasan Dashboard — Admin Ebrystore" },
      { property: "og:description", content: "Metrik katalog dan akses Ebrystore." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminOverview,
});

function AdminOverview() {
  const access = useAccess();
  const fetchOverview = useServerFn(getAdminOverview);
  const { data, isPending, error } = useQuery({ queryKey: ["admin-overview"], queryFn: () => fetchOverview({}) });

  return (
    <div className="space-y-6">
      <AdminPageHeader
        crumb="Ringkasan"
        title="Ringkasan dashboard"
        description="Metrik yang ditampilkan hanya yang sudah didukung skema saat ini (katalog & akses)."
      />

      {isPending ? (
        <AdminLoading />
      ) : error ? (
        <AdminError />
      ) : data.forbidden ? (
        <ForbiddenState permission={data.permission} />
      ) : (
        <>
          <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <Kpi label="Produk digital" value={data.counts.products} hint={`${data.counts.publishedProducts} terbit`} />
            <Kpi label="Layanan akademik" value={data.counts.services} hint={`${data.counts.publishedServices} terbit`} />
            <Kpi label="Kategori aktif" value={data.counts.categories} />
            <Kpi label="Pengguna terdaftar" value={data.counts.users} hint={`${data.counts.roleAssignments} penetapan peran`} />
          </section>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Aktivitas terbaru (audit log)</CardTitle>
            </CardHeader>
            <CardContent>
              {data.recentAudits.length === 0 ? (
                <p className="text-sm text-muted-foreground">Belum ada aktivitas tercatat.</p>
              ) : (
                <ul className="divide-y divide-border text-sm">
                  {data.recentAudits.map((a: any) => (
                    <li key={a.id} className="flex flex-wrap items-center gap-2 py-2">
                      <Badge variant="secondary">{a.action}</Badge>
                      <span className="text-muted-foreground">{a.entity_type}</span>
                      <span className="ml-auto text-xs text-muted-foreground">
                        {new Date(a.created_at).toLocaleString("id-ID")}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Modul transaksi</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              Order, pembayaran, refund, task, dan laporan pendapatan belum tersedia karena tabel transaksinya belum
              dibangun (Slice 2). Namespace izinnya sudah disiapkan: orders.*, payments.*, refunds.*, tasks.*,
              reports.*.
            </CardContent>
          </Card>

          <p className="text-xs text-muted-foreground">
            Izin aktif akun ini: {access.permissions.length} · {access.isSuperAdmin ? "super admin bypass aktif" : "berbasis peran"}
          </p>
        </>
      )}
    </div>
  );
}

function Kpi({ label, value, hint }: { label: string; value: number; hint?: string }) {
  return (
    <Card>
      <CardContent className="pt-6">
        <p className="text-sm text-muted-foreground">{label}</p>
        <p className="mt-1 text-3xl font-bold tabular-nums">{value}</p>
        {hint ? <p className="mt-1 text-xs text-muted-foreground">{hint}</p> : null}
      </CardContent>
    </Card>
  );
}
