import { useEffect, useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { RotateCcw, Save } from "lucide-react";

import { AdminError, AdminLoading, AdminPageHeader, ForbiddenState, useCan } from "@/components/admin/admin-ui";
import { DetailCard, formatDateTime } from "@/components/admin/tx-ui";
import { ImageUploader } from "@/components/admin/image-uploader";
import { NavEditor } from "@/components/admin/nav-editor";
import { SettingsPreview } from "@/components/admin/settings-preview";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  SETTING_SECTIONS,
  contrastWithWhite,
  validateField,
  type NavItem,
  type SettingField,
} from "@/lib/website-settings";
import { getWebsiteSettings, resetWebsiteSection, saveWebsiteSection } from "@/lib/website-settings.functions";

export const Route = createFileRoute("/_authenticated/admin/settings/website")({
  head: () => ({
    meta: [
      { title: "Pengaturan Website — Admin Ebrystore" },
      {
        name: "description",
        content: "Kelola identitas, branding, navigasi, SEO, storefront, fitur, dan maintenance Ebrystore dari satu halaman.",
      },
      { property: "og:title", content: "Pengaturan Website — Admin Ebrystore" },
      { property: "og:description", content: "Konfigurasi website Ebrystore berbasis data nyata dan tercatat pada audit log." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: WebsiteSettingsPage,
});

function WebsiteSettingsPage() {
  const qc = useQueryClient();
  const canView = useCan("settings.website.view");
  const canReset = useCan("settings.dangerous.update");
  const load = useServerFn(getWebsiteSettings);
  const save = useServerFn(saveWebsiteSection);
  const reset = useServerFn(resetWebsiteSection);

  const [activeId, setActiveId] = useState(SETTING_SECTIONS[0].id);
  const [draft, setDraft] = useState<Record<string, any>>({});

  const { data, isPending, error } = useQuery({
    queryKey: ["website-settings"],
    queryFn: () => load({}),
  });

  const serverValues: Record<string, any> = (data as any)?.values ?? {};

  useEffect(() => {
    if (!data || (data as any).forbidden || (data as any).error) return;
    setDraft({ ...serverValues });
  }, [data]);

  const section = useMemo(() => SETTING_SECTIONS.find((s) => s.id === activeId)!, [activeId]);
  const canEdit = useCan(section.permission);

  const dirtyKeys = section.fields
    .filter((f) => !f.readOnly)
    .filter((f) => JSON.stringify(draft[f.key]) !== JSON.stringify(serverValues[f.key]))
    .map((f) => f.key);

  const fieldErrors = Object.fromEntries(
    section.fields
      .map((f) => {
        if (f.readOnly) return null;
        const result = validateField(f, draft[f.key]);
        return result.ok ? null : ([f.key, result.error] as const);
      })
      .filter(Boolean) as [string, string][],
  );

  const saveMutation = useMutation({
    mutationFn: (payload: { section: string; values: Record<string, unknown> }) => save({ data: payload }),
    onSuccess: (res: any) => {
      if (res?.forbidden) return toast.error(`Izin ${res.permission} dibutuhkan.`);
      if (!res?.ok) return toast.error(res?.error ?? "Pengaturan gagal disimpan.");
      toast.success(res.changed ? `${res.changed} pengaturan disimpan.` : "Tidak ada perubahan.");
      void qc.invalidateQueries({ queryKey: ["website-settings"] });
      void qc.invalidateQueries({ queryKey: ["public-website-settings"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Pengaturan gagal disimpan."),
  });

  const resetMutation = useMutation({
    mutationFn: (payload: { section: string }) => reset({ data: payload }),
    onSuccess: (res: any) => {
      if (res?.forbidden) return toast.error(`Izin ${res.permission} dibutuhkan.`);
      if (!res?.ok) return toast.error(res?.error ?? "Reset gagal dijalankan.");
      toast.success("Pengaturan dikembalikan ke nilai default.");
      void qc.invalidateQueries({ queryKey: ["website-settings"] });
      void qc.invalidateQueries({ queryKey: ["public-website-settings"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Reset gagal dijalankan."),
  });

  if (!canView) return <ForbiddenState permission="settings.website.view" />;
  if (isPending) return <AdminLoading />;
  if ((data as any)?.forbidden) return <ForbiddenState permission={(data as any).permission} />;
  if (error || (data as any)?.error) return <AdminError message={(data as any)?.error ?? "Pengaturan tidak dapat dimuat."} />;

  function setValue(key: string, value: unknown) {
    setDraft((prev) => ({ ...prev, [key]: value }));
  }

  function onSave() {
    const invalid = Object.entries(fieldErrors)[0];
    if (invalid) return toast.error(invalid[1]);
    const confirmField = section.fields.find((f) => f.confirm && dirtyKeys.includes(f.key));
    if (confirmField && !window.confirm(confirmField.confirm)) return;
    saveMutation.mutate({
      section: section.id,
      values: Object.fromEntries(dirtyKeys.map((k) => [k, draft[k]])),
    });
  }

  function onReset() {
    if (!window.confirm(`Kembalikan seluruh pengaturan "${section.label}" ke nilai default?`)) return;
    resetMutation.mutate({ section: section.id });
  }

  const lastChange = (data as any)?.lastChange;

  return (
    <div className="space-y-6">
      <AdminPageHeader
        title="Pengaturan Website"
        crumb="Pengaturan website"
        description="Semua nilai tersimpan di database, divalidasi di server, dan tercatat pada audit log."
      />

      {lastChange ? (
        <p className="text-xs text-muted-foreground">
          Perubahan terakhir {formatDateTime(lastChange.created_at)}
          {(data as any)?.actorName ? ` oleh ${(data as any).actorName}` : ""} · {lastChange.reason ?? lastChange.action}
        </p>
      ) : null}

      <div className="grid gap-6 lg:grid-cols-[220px_minmax(0,1fr)]">
        <nav aria-label="Bagian pengaturan" className="min-w-0 lg:sticky lg:top-20 lg:self-start">
          <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-2 lg:mx-0 lg:flex-col lg:overflow-visible lg:px-0 lg:pb-0">
            {SETTING_SECTIONS.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => setActiveId(s.id)}
                aria-current={s.id === activeId ? "page" : undefined}
                className={`shrink-0 rounded-lg px-3 py-2 text-left text-sm transition-colors lg:w-full ${
                  s.id === activeId
                    ? "bg-primary/10 font-semibold text-primary"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </nav>

        <div className="min-w-0 space-y-6">
          <DetailCard title={section.label} description={section.description}>
            {!canEdit ? (
              <p className="mb-4 rounded-lg border border-dashed border-border p-3 text-sm text-muted-foreground">
                Anda hanya dapat melihat bagian ini. Perubahan memerlukan izin {section.permission}.
              </p>
            ) : null}

            <div className="space-y-5">
              {section.fields.map((field) => (
                <FieldRow
                  key={field.key}
                  field={field}
                  value={draft[field.key]}
                  error={fieldErrors[field.key]}
                  disabled={!canEdit || field.readOnly || saveMutation.isPending}
                  onChange={(v) => setValue(field.key, v)}
                />
              ))}
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-3 border-t border-border pt-4">
              <Button onClick={onSave} disabled={!canEdit || !dirtyKeys.length || saveMutation.isPending}>
                <Save className="mr-1 size-4" />
                {saveMutation.isPending ? "Menyimpan…" : "Simpan perubahan"}
              </Button>
              <Button
                variant="outline"
                onClick={() => setDraft({ ...serverValues })}
                disabled={!dirtyKeys.length || saveMutation.isPending}
              >
                Batalkan perubahan
              </Button>
              {canReset ? (
                <Button variant="ghost" onClick={onReset} disabled={resetMutation.isPending}>
                  <RotateCcw className="mr-1 size-4" /> Reset ke default
                </Button>
              ) : null}
              <span className="text-xs text-muted-foreground">
                {dirtyKeys.length ? `${dirtyKeys.length} perubahan belum disimpan` : "Tidak ada perubahan"}
              </span>
            </div>
          </DetailCard>

          <SettingsPreview values={draft} />
        </div>
      </div>
    </div>
  );
}

function FieldRow({
  field,
  value,
  error,
  disabled,
  onChange,
}: {
  field: SettingField;
  value: any;
  error?: string;
  disabled: boolean;
  onChange: (value: unknown) => void;
}) {
  const id = `field-${field.key}`;
  const describedBy = error ? `${id}-error` : field.help ? `${id}-help` : undefined;

  const label = (
    <div className="min-w-0">
      <Label htmlFor={id}>{field.label}</Label>
      {field.help ? (
        <p id={`${id}-help`} className="text-xs text-muted-foreground">
          {field.help}
        </p>
      ) : null}
    </div>
  );

  if (field.type === "boolean") {
    return (
      <div className="flex items-center justify-between gap-3 rounded-lg border border-border p-3">
        {label}
        <Switch id={id} className="shrink-0" checked={Boolean(value)} disabled={disabled} onCheckedChange={onChange} />
      </div>
    );
  }

  if (field.type === "nav") {
    return (
      <div className="space-y-3">
        {label}
        <NavEditor items={(value ?? []) as NavItem[]} disabled={disabled} onChange={(next) => onChange(next)} />
        {error ? <p className="text-xs text-destructive">{error}</p> : null}
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {label}
      {field.type === "textarea" ? (
        <Textarea
          id={id}
          rows={3}
          value={String(value ?? "")}
          disabled={disabled}
          aria-invalid={Boolean(error)}
          aria-describedby={describedBy}
          onChange={(e) => onChange(e.target.value)}
        />
      ) : field.type === "select" ? (
        <Select value={String(value ?? "")} disabled={disabled} onValueChange={onChange}>
          <SelectTrigger id={id} aria-describedby={describedBy}>
            <SelectValue placeholder="Pilih" />
          </SelectTrigger>
          <SelectContent>
            {(field.options ?? []).map((o) => (
              <SelectItem key={o.value} value={o.value}>
                {o.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      ) : field.type === "list" ? (
        <Input
          id={id}
          value={Array.isArray(value) ? value.join(", ") : String(value ?? "")}
          disabled={disabled}
          aria-invalid={Boolean(error)}
          aria-describedby={describedBy}
          placeholder="pisahkan dengan koma"
          onChange={(e) =>
            onChange(
              e.target.value
                .split(",")
                .map((s) => s.trim())
                .filter(Boolean),
            )
          }
        />
      ) : field.type === "color" ? (
        <div className="flex flex-wrap items-center gap-3">
          <input
            id={id}
            type="color"
            className="h-9 w-14 shrink-0 cursor-pointer rounded border border-border bg-transparent"
            value={/^#[0-9a-fA-F]{6}$/.test(String(value ?? "")) ? String(value) : "#000000"}
            disabled={disabled}
            onChange={(e) => onChange(e.target.value)}
          />
          <Input
            className="w-[140px] max-w-full font-mono"
            value={String(value ?? "")}
            disabled={disabled}
            aria-describedby={describedBy}
            onChange={(e) => onChange(e.target.value)}
          />
          <span className="text-xs text-muted-foreground">
            Kontras teks putih {contrastWithWhite(String(value ?? "#000000")).toFixed(2)}:1
          </span>
        </div>
      ) : field.type === "url" && field.key.includes("logo") ? (
        <ImageUploader
          value={String(value ?? "")}
          onChange={(url) => onChange(url)}
          folder="branding"
          label={field.label}
          hint="JPG, PNG, WEBP, atau AVIF maksimal 3 MB."
        />
      ) : (
        <Input
          id={id}
          value={String(value ?? "")}
          disabled={disabled}
          aria-invalid={Boolean(error)}
          aria-describedby={describedBy}
          onChange={(e) => onChange(e.target.value)}
        />
      )}
      {error ? (
        <p id={`${id}-error`} className="text-xs text-destructive">
          {error}
        </p>
      ) : null}
    </div>
  );
}