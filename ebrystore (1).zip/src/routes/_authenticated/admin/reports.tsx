import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Download } from "lucide-react";
import { toast } from "sonner";

import { AdminError, AdminLoading, AdminPageHeader, EmptyRow, ForbiddenState, useCan } from "@/components/admin/admin-ui";
import { DetailCard } from "@/components/admin/tx-ui";
import { DonutChart, RevenueTrendChart, StatusBarChart } from "@/components/admin/report-charts";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getTransactionReport } from "@/lib/admin-transaction.functions";
import { ORDER_STATUS_LABEL, ORDER_TYPE_LABEL } from "@/lib/transaction-labels";
import { formatRupiah } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/admin/reports")({
  head: () => ({
    meta: [
      { title: "Laporan Transaksi — Admin Ebrystore" },
      { name: "description", content: "Ringkasan order, pembayaran, refund, dan performa operator Ebrystore." },
      { property: "og:title", content: "Laporan Transaksi — Admin Ebrystore" },
      { property: "og:description", content: "Laporan transaksi Ebrystore berbasis data nyata." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminReports,
});

function Kpi({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 text-xl font-bold">{value}</p>
    </div>
  );
}

function AdminReports() {
  const canView = useCan("reports.view");
  const canExport = useCan("reports.export");
  const [days, setDays] = useState("30");

  const fetchReport = useServerFn(getTransactionReport);
  const { data, isPending, error } = useQuery({
    queryKey: ["admin-report", days],
    queryFn: () => fetchReport({ data: { days: Number(days) } }),
  });

  if (!canView) return <ForbiddenState permission="reports.view" />;
  if (isPending) return <AdminLoading />;
  if ((data as any)?.forbidden) return <ForbiddenState permission={(data as any).permission} />;
  if (error) return <AdminError message="Laporan tidak dapat dimuat." />;

  const r = data as any;

  const daily: Array<{ date: string; orders: number; revenue: number }> = r.daily ?? [];
  const typeData = Object.entries(r.byType ?? {}).map(([k, v]: [string, any]) => ({
    name: ORDER_TYPE_LABEL[k] ?? k,
    value: Number(v.revenue ?? 0),
  }));
  const typeOrderData = Object.entries(r.byType ?? {}).map(([k, v]: [string, any]) => ({
    name: ORDER_TYPE_LABEL[k] ?? k,
    value: Number(v.orders ?? 0),
  }));
  const statusData = Object.entries(r.byStatus ?? {}).map(([k, v]: [string, any]) => ({
    name: ORDER_STATUS_LABEL[k] ?? k,
    value: Number(v),
  }));
  const methodData = Object.entries(r.byMethod ?? {}).map(([k, v]: [string, any]) => ({
    name: k,
    value: Number(v),
  }));

  const exportCsv = () => {
    if (!r.daily?.length) return toast.error("Tidak ada data untuk diekspor.");
    const csv = [
      ["tanggal", "order", "pendapatan"],
      ...r.daily.map((d: any) => [d.date, d.orders, d.revenue]),
    ]
      .map((row: unknown[]) => row.join(","))
      .join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `laporan-${days}-hari.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Laporan diunduh.");
  };

  return (
    <div className="space-y-6">
      <AdminPageHeader
        title="Laporan"
        crumb="Laporan"
        description="Seluruh angka dihitung dari data transaksi nyata, tanpa data contoh."
        actions={
          canExport ? (
            <Button variant="outline" size="sm" onClick={exportCsv}>
              <Download className="size-4" aria-hidden="true" /> Ekspor CSV
            </Button>
          ) : null
        }
      />

      <div className="w-full max-w-xs">
        <Label htmlFor="report-range">Periode</Label>
        <Select value={days} onValueChange={setDays}>
          <SelectTrigger id="report-range">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">7 hari terakhir</SelectItem>
            <SelectItem value="30">30 hari terakhir</SelectItem>
            <SelectItem value="90">90 hari terakhir</SelectItem>
            <SelectItem value="180">180 hari terakhir</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Kpi label="Jumlah order" value={r.totalOrders} />
        <Kpi label="Order terbayar" value={r.paidOrders} />
        <Kpi label="Nilai transaksi" value={formatRupiah(r.revenue)} />
        <Kpi label="Pendapatan bersih" value={formatRupiah(r.netRevenue)} />
        <Kpi label="Pembayaran lunas" value={r.paymentPaid} />
        <Kpi label="Menunggu verifikasi" value={r.waitingVerification} />
        <Kpi label="Pembayaran ditolak" value={r.paymentRejected} />
        <Kpi label="Pembayaran kedaluwarsa" value={r.paymentExpired} />
        <Kpi label="Refund diajukan" value={r.refundCount} />
        <Kpi label="Nilai refund" value={formatRupiah(r.refunded)} />
        <Kpi label="Konversi bayar" value={`${r.conversion}%`} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="lg:col-span-2">
          <DetailCard
            title="Tren pendapatan & order"
            description="Area menampilkan nilai transaksi, garis menampilkan jumlah order per hari."
          >
            {!daily.length ? (
              <EmptyRow message="Belum ada transaksi pada periode ini." />
            ) : (
              <RevenueTrendChart daily={daily} />
            )}
          </DetailCard>
        </div>

        <DetailCard title="Komposisi pendapatan per jenis" description="Donut berdasarkan nilai transaksi.">
          {!typeData.length ? (
            <EmptyRow message="Belum ada order pada periode ini." />
          ) : (
            <DonutChart data={typeData} centerLabel="Total pendapatan" currency />
          )}
        </DetailCard>

        <DetailCard title="Proporsi metode pembayaran" description="Donut berdasarkan jumlah pembayaran.">
          {!methodData.length ? (
            <EmptyRow message="Belum ada pembayaran pada periode ini." />
          ) : (
            <DonutChart data={methodData} valueLabel="pembayaran" centerLabel="Total pembayaran" />
          )}
        </DetailCard>

        <DetailCard title="Sebaran order per jenis" description="Donut berdasarkan jumlah order.">
          {!typeOrderData.length ? (
            <EmptyRow message="Belum ada order pada periode ini." />
          ) : (
            <DonutChart data={typeOrderData} valueLabel="order" centerLabel="Total order" />
          )}
        </DetailCard>

        <DetailCard title="Order per status" description="Perbandingan jumlah order tiap status.">
          {!statusData.length ? (
            <EmptyRow message="Belum ada order pada periode ini." />
          ) : (
            <StatusBarChart data={statusData} />
          )}
        </DetailCard>

        <DetailCard title="Order per jenis">
          {!Object.keys(r.byType ?? {}).length ? (
            <EmptyRow message="Belum ada order pada periode ini." />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Jenis</TableHead>
                  <TableHead className="text-right">Order</TableHead>
                  <TableHead className="text-right">Pendapatan</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(r.byType).map(([k, v]: [string, any]) => (
                  <TableRow key={k}>
                    <TableCell>{ORDER_TYPE_LABEL[k] ?? k}</TableCell>
                    <TableCell className="text-right">{v.orders}</TableCell>
                    <TableCell className="text-right">{formatRupiah(v.revenue)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </DetailCard>

        <DetailCard title="Order per status">
          {!Object.keys(r.byStatus ?? {}).length ? (
            <EmptyRow message="Belum ada order pada periode ini." />
          ) : (
            <ul className="space-y-1 text-sm">
              {Object.entries(r.byStatus).map(([k, v]: [string, any]) => (
                <li key={k} className="flex justify-between">
                  <span>{ORDER_STATUS_LABEL[k] ?? k}</span>
                  <span className="font-medium">{v}</span>
                </li>
              ))}
            </ul>
          )}
        </DetailCard>

        <DetailCard title="Metode pembayaran">
          {!Object.keys(r.byMethod ?? {}).length ? (
            <EmptyRow message="Belum ada pembayaran pada periode ini." />
          ) : (
            <ul className="space-y-1 text-sm">
              {Object.entries(r.byMethod).map(([k, v]: [string, any]) => (
                <li key={k} className="flex justify-between">
                  <span>{k}</span>
                  <span className="font-medium">{v}</span>
                </li>
              ))}
            </ul>
          )}
        </DetailCard>

        <DetailCard title="Performa operator" description="Berdasarkan penugasan pada periode terpilih.">
          {!Object.keys(r.operatorPerf ?? {}).length ? (
            <EmptyRow message="Belum ada penugasan operator." />
          ) : (
            <ul className="space-y-1 text-sm">
              {Object.entries(r.operatorPerf).map(([k, v]: [string, any]) => (
                <li key={k} className="flex justify-between gap-3">
                  <span className="truncate font-mono text-xs">{k}</span>
                  <span className="font-medium">
                    {v.completed}/{v.total} selesai
                  </span>
                </li>
              ))}
            </ul>
          )}
        </DetailCard>
      </div>

      <DetailCard title="Transaksi harian">
        {!r.daily?.length ? (
          <EmptyRow message="Belum ada transaksi pada periode ini." />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tanggal</TableHead>
                  <TableHead className="text-right">Order</TableHead>
                  <TableHead className="text-right">Pendapatan</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {r.daily.map((d: any) => (
                  <TableRow key={d.date}>
                    <TableCell>{d.date}</TableCell>
                    <TableCell className="text-right">{d.orders}</TableCell>
                    <TableCell className="text-right">{formatRupiah(d.revenue)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </DetailCard>
    </div>
  );
}
