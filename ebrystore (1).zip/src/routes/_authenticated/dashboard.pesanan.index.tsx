import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { z } from "zod";

import { ArrowRight, FileText, GraduationCap, Package, Receipt, ShoppingBag } from "lucide-react";

import { AdminError, Pager } from "@/components/admin/admin-ui";
import { StatusPill } from "@/components/ebry/status";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { listMyOrders } from "@/lib/orders.functions";
import { formatRupiah } from "@/lib/format";
import { ORDER_STATUS_LABEL, ORDER_TYPE_LABEL, customerAction } from "@/lib/transaction-labels";
import { cn } from "@/lib/utils";

const searchSchema = z.object({ filter: z.string().catch("all") });

export const Route = createFileRoute("/_authenticated/dashboard/pesanan/")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Pesanan Saya — Ebrystore" },
      { name: "description", content: "Daftar pesanan produk digital dan bantuan tugas Anda di Ebrystore." },
      { property: "og:title", content: "Pesanan Saya — Ebrystore" },
      { property: "og:description", content: "Lacak status setiap pesanan Anda." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: PesananSaya,
});

const FILTERS = [
  { key: "all", label: "Semua" },
  { key: "unpaid", label: "Belum dibayar" },
  { key: "active", label: "Aktif" },
  { key: "completed", label: "Selesai" },
  { key: "cancelled", label: "Batal/refund" },
] as const;

const EMPTY_COPY: Record<string, { title: string; description: string }> = {
  all: { title: "Belum ada pesanan", description: "Pesanan produk digital dan bantuan tugas Anda akan tampil di sini." },
  unpaid: { title: "Tidak ada tagihan", description: "Semua pesanan Anda sudah terbayar. Mantap!" },
  active: { title: "Tidak ada pesanan aktif", description: "Saat ada pesanan yang sedang diproses, statusnya muncul di sini." },
  completed: { title: "Belum ada pesanan selesai", description: "Riwayat pesanan yang tuntas akan tersimpan di sini." },
  cancelled: { title: "Tidak ada pembatalan", description: "Pesanan batal atau refund akan tercatat di sini." },
};

function OrderSkeleton() {
  return (
    <ul className="space-y-3" aria-hidden="true">
      {[0, 1, 2].map((i) => (
        <li key={i} className="rounded-2xl border border-border/70 bg-card p-5">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-3 w-52" />
              <Skeleton className="h-3 w-24" />
            </div>
            <div className="space-y-2 text-right">
              <Skeleton className="ml-auto h-6 w-28 rounded-full" />
              <Skeleton className="ml-auto h-4 w-20" />
            </div>
          </div>
          <Skeleton className="mt-4 h-9 w-full rounded-xl" />
        </li>
      ))}
    </ul>
  );
}

function EmptyState({ filter }: { filter: string }) {
  const copy = EMPTY_COPY[filter] ?? EMPTY_COPY.all;
  return (
    <div className="rounded-2xl border border-dashed border-border bg-card/50 px-6 py-12 text-center">
      <span className="mx-auto grid size-14 place-items-center rounded-2xl bg-accent/10 text-accent">
        <Receipt className="size-6" aria-hidden="true" />
      </span>
      <h2 className="mt-4 text-base font-semibold">{copy.title}</h2>
      <p className="mx-auto mt-1 max-w-sm text-sm text-muted-foreground">{copy.description}</p>
      <div className="mt-5 flex flex-wrap justify-center gap-2">
        <Button asChild size="sm">
          <Link to="/produk">Lihat produk digital</Link>
        </Button>
        <Button asChild size="sm" variant="outline">
          <Link to="/layanan">Lihat layanan</Link>
        </Button>
      </div>
    </div>
  );
}

function PesananSaya() {
  const { filter } = Route.useSearch();
  const navigate = useNavigate();
  const [page, setPage] = useState(1);
  const fetchOrders = useServerFn(listMyOrders);

  const { data, isPending, error } = useQuery({
    queryKey: ["my-orders", filter, page],
    queryFn: () => fetchOrders({ data: { filter, page } }),
  });

  return (
    <div className="space-y-6">
      <header className="overflow-hidden rounded-2xl border border-border/70 bg-gradient-to-br from-accent/10 via-card to-card p-5">
        <div className="flex items-start gap-3">
          <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-accent/15 text-accent">
            <ShoppingBag className="size-5" aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <h1 className="text-xl font-bold sm:text-2xl">Pesanan saya</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Semua pesanan beserta status dan tindakan berikutnya.
              {typeof data?.total === "number" ? ` ${data.total} pesanan pada filter ini.` : ""}
            </p>
          </div>
        </div>
      </header>

      <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            type="button"
            aria-pressed={filter === f.key}
            onClick={() => {
              setPage(1);
              navigate({ to: "/dashboard/pesanan", search: { filter: f.key } });
            }}
            className={cn(
              "press-scale shrink-0 rounded-full border px-4 py-2 text-xs font-semibold transition-colors",
              filter === f.key
                ? "border-transparent bg-primary text-primary-foreground shadow-sm"
                : "border-border bg-card text-muted-foreground hover:border-accent/50 hover:text-foreground",
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {isPending ? (
        <OrderSkeleton />
      ) : error ? (
        <AdminError />
      ) : data.error ? (
        <AdminError message={data.error} />
      ) : data.items.length === 0 ? (
        <EmptyState filter={filter} />
      ) : (
        <>
          <ul className="space-y-3">
            {data.items.map((o: any) => {
              const action = customerAction(o.status, o.payments?.[0]?.status ?? null);
              const isService = o.order_type === "service";
              const TypeIcon = isService ? GraduationCap : Package;
              const items = (o.order_items ?? []) as any[];
              const needsPayment = o.status === "awaiting_payment";
              return (
                <li
                  key={o.id}
                  className={cn(
                    "group relative overflow-hidden rounded-2xl border bg-card/70 p-4 shadow-sm backdrop-blur transition-all hover:-translate-y-0.5 hover:border-accent/50 hover:shadow-md sm:p-5",
                    needsPayment ? "border-warning/40" : "border-border/70",
                  )}
                >
                  {needsPayment ? (
                    <span className="absolute inset-y-0 left-0 w-1 bg-warning" aria-hidden="true" />
                  ) : null}
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="flex min-w-0 flex-1 items-start gap-3">
                      <span className="grid size-10 shrink-0 place-items-center rounded-xl bg-accent/10 text-accent">
                        <TypeIcon className="size-5" aria-hidden="true" />
                      </span>
                      <div className="min-w-0">
                        <p className="truncate font-semibold tabular-nums">{o.order_number}</p>
                        <p className="mt-0.5 text-xs font-medium text-muted-foreground">
                          {ORDER_TYPE_LABEL[o.order_type] ?? o.order_type} ·{" "}
                          {new Date(o.created_at).toLocaleDateString("id-ID", {
                            day: "numeric",
                            month: "short",
                            year: "numeric",
                          })}
                        </p>
                        <ul className="mt-2 space-y-1">
                          {items.slice(0, 2).map((i: any, idx: number) => (
                            <li key={idx} className="flex items-start gap-1.5 text-sm text-foreground/90">
                              <FileText className="mt-0.5 size-3.5 shrink-0 text-muted-foreground" aria-hidden="true" />
                              <span className="line-clamp-1">
                                {i.name_snapshot}
                                {i.quantity > 1 ? ` ×${i.quantity}` : ""}
                              </span>
                            </li>
                          ))}
                          {items.length > 2 ? (
                            <li className="text-xs text-muted-foreground">+{items.length - 2} item lainnya</li>
                          ) : null}
                        </ul>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <StatusPill value={o.status} />
                      <p className="text-base font-bold tabular-nums">{formatRupiah(Number(o.total))}</p>
                    </div>
                  </div>

                  {action ? (
                    <p className="mt-3 flex items-center gap-2 rounded-xl bg-muted/60 px-3 py-2 text-xs font-medium text-muted-foreground">
                      <ArrowRight className="size-3.5 shrink-0 text-accent" aria-hidden="true" />
                      Langkah berikut: <span className="text-foreground">{action}</span>
                    </p>
                  ) : null}

                  <Button
                    asChild
                    size="sm"
                    variant={needsPayment ? "default" : "outline"}
                    className="mt-3 w-full sm:w-auto"
                  >
                    <Link to="/dashboard/pesanan/$id" params={{ id: o.id }}>
                      {needsPayment ? "Bayar sekarang" : "Lihat detail"}
                      <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                    </Link>
                  </Button>
                  <span className="sr-only">{ORDER_STATUS_LABEL[o.status] ?? o.status}</span>
                </li>
              );
            })}
          </ul>
          <Pager page={page} pageSize={10} total={data.total} onChange={setPage} />
        </>
      )}
    </div>
  );
}