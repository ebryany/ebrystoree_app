import { Link, createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowRight, MessagesSquare } from "lucide-react";

import { AdminLoading } from "@/components/admin/admin-ui";
import { EmptyState, ErrorState } from "@/components/ebry/states";
import { StatusPill } from "@/components/ebry/status";
import { Button } from "@/components/ui/button";
import { INQUIRY_STATUS_LABEL } from "@/components/inquiry/inquiry-thread";
import { useRealtimeRefresh } from "@/hooks/use-realtime-refresh";
import { listMyInquiries } from "@/lib/inquiries.functions";

export const Route = createFileRoute("/_authenticated/dashboard/chat/")({
  head: () => ({
    meta: [
      { title: "Chat Produk — Ebrystore" },
      { name: "description", content: "Tanya ketersediaan produk digital langsung ke tim Ebrystore lewat chat." },
      { property: "og:title", content: "Chat Produk — Ebrystore" },
      { property: "og:description", content: "Riwayat percakapan tanya produk dengan tim Ebrystore." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ChatListPage,
});

function ChatListPage() {
  const fetchList = useServerFn(listMyInquiries);
  const { data, isPending, error, refetch } = useQuery({ queryKey: ["inquiry-list"], queryFn: () => fetchList({}) });

  useRealtimeRefresh({
    channel: "inquiry-list",
    tables: ["product_inquiries"],
    keys: [["inquiry-list"]],
  });

  return (
    <div className="space-y-4">
      <header>
        <h1 className="text-xl font-bold">Chat produk</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Tanyakan ketersediaan atau detail produk. Balasan tim muncul di sini.
        </p>
      </header>

      {isPending ? <AdminLoading /> : null}
      {error || data?.error ? <ErrorState onRetry={() => refetch()} /> : null}

      {data && !data.error && data.items.length === 0 ? (
        <EmptyState
          icon={MessagesSquare}
          title="Belum ada percakapan"
          description="Buka salah satu produk lalu tekan “Tanya ketersediaan” untuk mulai chat."
          action={
            <Button asChild>
              <Link to="/produk">Lihat katalog produk</Link>
            </Button>
          }
        />
      ) : null}

      <ul className="space-y-2">
        {(data?.items ?? []).map((item: any) => (
          <li key={item.id}>
            <Link
              to="/dashboard/chat/$id"
              params={{ id: item.id }}
              className="flex items-center gap-3 rounded-2xl border border-border bg-card p-4 shadow-card transition hover:border-primary/40"
            >
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{item.subject}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Pesan terakhir {new Date(item.last_message_at).toLocaleString("id-ID", { dateStyle: "medium", timeStyle: "short" })}
                </p>
              </div>
              <StatusPill value={item.status} kind="raw" label={INQUIRY_STATUS_LABEL[item.status]} />
              <ArrowRight className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
