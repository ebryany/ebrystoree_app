import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Bell, CheckCheck, Volume2, VolumeX } from "lucide-react";

import { AdminError, AdminLoading } from "@/components/admin/admin-ui";
import { useRealtimeRefresh } from "@/hooks/use-realtime-refresh";
import { useNotificationSound } from "@/hooks/use-notification-sound";
import { Button } from "@/components/ui/button";
import { listMyNotifications, markAllNotificationsRead, markNotificationRead } from "@/lib/orders.functions";
import { dayGroupLabel, notificationTone, relativeTime } from "@/components/ebry/notification-meta";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/dashboard/notifikasi")({
  head: () => ({
    meta: [
      { title: "Notifikasi — Ebrystore" },
      { name: "description", content: "Pemberitahuan pesanan, pembayaran, dan refund akun Ebrystore Anda." },
      { property: "og:title", content: "Notifikasi — Ebrystore" },
      { property: "og:description", content: "Riwayat pemberitahuan akun Anda." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Notifikasi,
});

type Filter = "all" | "unread";

function Notifikasi() {
  const queryClient = useQueryClient();
  const fetchItems = useServerFn(listMyNotifications);
  const markRead = useServerFn(markNotificationRead);
  const markAll = useServerFn(markAllNotificationsRead);
  const sound = useNotificationSound();
  const [filter, setFilter] = useState<Filter>("all");
  const { data, isPending, error } = useQuery({ queryKey: ["my-notifications"], queryFn: () => fetchItems({}) });

  useRealtimeRefresh({
    channel: "my-notifications-page",
    tables: ["notifications"],
    keys: [["my-notifications"], ["customer-summary"]],
  });

  const items: any[] = (data as any)?.items ?? [];
  const unread = items.filter((n) => !n.read_at).length;

  const groups = useMemo(() => {
    const visible = filter === "unread" ? items.filter((n) => !n.read_at) : items;
    const map = new Map<string, any[]>();
    for (const n of visible) {
      const key = dayGroupLabel(n.created_at);
      const list = map.get(key) ?? [];
      list.push(n);
      map.set(key, list);
    }
    return [...map.entries()];
  }, [items, filter]);

  async function handleRead(id: string) {
    await markRead({ data: { id } });
    await queryClient.invalidateQueries({ queryKey: ["my-notifications"] });
    await queryClient.invalidateQueries({ queryKey: ["customer-summary"] });
  }

  async function handleReadAll() {
    await markAll({});
    await queryClient.invalidateQueries({ queryKey: ["my-notifications"] });
    await queryClient.invalidateQueries({ queryKey: ["customer-summary"] });
  }

  return (
    <div className="space-y-5">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Notifikasi</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {unread > 0 ? `${unread} pemberitahuan belum dibaca` : "Semua pemberitahuan sudah dibaca"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5"
            onClick={sound.toggle}
            aria-label={sound.enabled ? "Matikan suara notifikasi" : "Nyalakan suara notifikasi"}
          >
            {sound.enabled ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
            <span className="hidden sm:inline">{sound.enabled ? "Suara aktif" : "Suara mati"}</span>
          </Button>
          {unread > 0 ? (
            <Button size="sm" className="gap-1.5" onClick={handleReadAll}>
              <CheckCheck className="size-4" />
              Tandai semua
            </Button>
          ) : null}
        </div>
      </header>

      <div className="inline-flex rounded-xl border border-border bg-muted/40 p-1">
        {(["all", "unread"] as Filter[]).map((key) => (
          <button
            key={key}
            type="button"
            onClick={() => setFilter(key)}
            className={cn(
              "rounded-lg px-3 py-1.5 text-sm font-medium transition-colors",
              filter === key ? "bg-background text-foreground shadow-sm" : "text-muted-foreground",
            )}
          >
            {key === "all" ? `Semua (${items.length})` : `Belum dibaca (${unread})`}
          </button>
        ))}
      </div>

      {isPending ? (
        <AdminLoading label="Memuat notifikasi…" />
      ) : error ? (
        <AdminError />
      ) : (data as any).error ? (
        <AdminError message={(data as any).error} />
      ) : groups.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border px-6 py-14 text-center">
          <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-muted text-muted-foreground">
            <Bell className="size-6" aria-hidden="true" />
          </div>
          <p className="mt-4 font-medium">
            {filter === "unread" ? "Tidak ada yang belum dibaca" : "Belum ada notifikasi"}
          </p>
          <p className="mt-1 text-sm text-muted-foreground">
            Kabar pesanan, pembayaran, dan refund akan muncul di sini.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {groups.map(([label, list]) => (
            <section key={label} className="space-y-2">
              <h2 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</h2>
              <ul className="space-y-2">
                {list.map((n: any) => {
                  const tone = notificationTone(n.type);
                  const Icon = tone.icon;
                  return (
                    <li
                      key={n.id}
                      className={cn(
                        "relative overflow-hidden rounded-2xl border p-4 transition-colors",
                        n.read_at ? "border-border bg-card" : "border-accent/40 bg-accent/[0.06]",
                      )}
                    >
                      {n.read_at ? null : (
                        <span aria-hidden="true" className="absolute inset-y-3 left-0 w-1 rounded-full bg-accent" />
                      )}
                      <div className="flex items-start gap-3">
                        <span className={cn("grid size-10 shrink-0 place-items-center rounded-xl", tone.wrap)}>
                          <Icon className="size-5" aria-hidden="true" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="rounded-full border border-border px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
                              {tone.label}
                            </span>
                            <span className="text-[11px] text-muted-foreground">{relativeTime(n.created_at)}</span>
                          </div>
                          <p className={cn("mt-1.5 leading-snug", n.read_at ? "font-medium" : "font-semibold")}>
                            {n.title}
                          </p>
                          <p className="mt-1 text-sm text-muted-foreground">{n.message}</p>
                          {n.read_at ? null : (
                            <Button
                              size="sm"
                              variant="outline"
                              className="mt-3 h-8"
                              onClick={() => handleRead(n.id)}
                            >
                              Tandai dibaca
                            </Button>
                          )}
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
