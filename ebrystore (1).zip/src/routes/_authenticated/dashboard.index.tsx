import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  ArrowRight,
  Bell,
  CheckCircle2,
  Compass,
  Download,
  LifeBuoy,
  MessageSquarePlus,
  MessagesSquare,
  Package,
  ReceiptText,
  RotateCcw,
  Upload,
  Wallet,
  Wrench,
} from "lucide-react";

import { ActionRequiredCard, OrderCard, ServiceShortcut } from "@/components/ebry/cards";
import { CardSkeleton, EmptyState, ErrorState } from "@/components/ebry/states";
import { Button } from "@/components/ui/button";
import { useSession } from "@/hooks/use-session";
import { useRealtimeRefresh } from "@/hooks/use-realtime-refresh";
import { useAvatarUrl } from "@/hooks/use-avatar-url";
import { getCustomerSummary, getMyProfile } from "@/lib/orders.functions";

export const Route = createFileRoute("/_authenticated/dashboard/")({
  head: () => ({
    meta: [
      { title: "Dashboard Akun — Ebrystore" },
      { name: "description", content: "Ringkasan pesanan, pembayaran, dan produk digital Anda di Ebrystore." },
      { property: "og:title", content: "Dashboard Akun — Ebrystore" },
      { property: "og:description", content: "Pantau pesanan dan akses produk digital Anda." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: DashboardRingkasan,
});

function DashboardRingkasan() {
  const fetchSummary = useServerFn(getCustomerSummary);
  const fetchProfile = useServerFn(getMyProfile);
  const { user } = useSession();
  const { data, isPending, error, refetch } = useQuery({
    queryKey: ["customer-summary"],
    queryFn: () => fetchSummary({}),
  });
  const { data: profileData } = useQuery({
    queryKey: ["my-profile"],
    queryFn: () => fetchProfile({}),
  });
  const profile = (profileData as any)?.profile;
  const avatarUrl = useAvatarUrl(profile?.avatar_url ?? null);

  useRealtimeRefresh({
    channel: "dashboard-summary",
    tables: ["orders", "payments", "operator_assignments", "job_results", "notifications"],
    keys: [["customer-summary"], ["my-orders"]],
  });

  const fullName =
    (profile?.full_name as string | undefined) ??
    (user?.user_metadata?.full_name as string | undefined) ??
    user?.email?.split("@")[0] ??
    "teman";
  const firstName = fullName.split(" ")[0];
  const initials =
    fullName
      .split(" ")
      .filter(Boolean)
      .slice(0, 2)
      .map((w: string) => w[0]?.toUpperCase())
      .join("") || "E";

  const shortcuts: Array<{
    to: string;
    icon: typeof Package;
    label: string;
    hint: string;
    featured?: boolean;
    search?: Record<string, unknown>;
  }> = [
    { to: "/produk", icon: Package, label: "Produk Digital", hint: "Katalog siap unduh" },
    { to: "/layanan", icon: Wrench, label: "Pesan Jasa", hint: "Joki & jasa akademik" },
    { to: "/dashboard/pesanan", icon: ReceiptText, label: "Pesanan Saya", hint: "Riwayat & status" },
    { to: "/dashboard/produk-saya", icon: Download, label: "Produk Saya", hint: "Akses unduhan" },
    { to: "/dashboard/chat", icon: MessagesSquare, label: "Chat Produk", hint: "Tanya ketersediaan" },
    { to: "/dashboard/notifikasi", icon: Bell, label: "Notifikasi", hint: "Update terbaru" },
    { to: "/bantuan", icon: LifeBuoy, label: "Bantuan", hint: "Pusat bantuan" },
  ];

  const needsAction = data ? data.awaitingPayment + data.underReview + data.activeRefunds : 0;

  return (
    <div className="space-y-7 md:space-y-9">
      <header className="border-b border-border pb-6">
        <div className="flex items-center gap-3.5">
          <Link
            to="/dashboard/pengaturan"
            aria-label="Buka pengaturan akun dan ubah foto profil"
            className="grid size-12 shrink-0 place-items-center overflow-hidden rounded-full border border-border bg-primary text-sm font-semibold text-primary-foreground shadow-card transition-transform hover:scale-105 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:size-14"
          >
            {avatarUrl ? (
              <img src={avatarUrl} alt={`Foto profil ${fullName}`} className="size-full object-cover" />
            ) : (
              <span>{initials}</span>
            )}
          </Link>
          <div className="min-w-0">
            <p className="text-sm font-medium text-accent">Halo, {firstName}</p>
            <h1 className="mt-0.5 text-xl font-bold sm:text-2xl">Ringkasan akunmu</h1>
            <p className="mt-1 text-sm text-muted-foreground">Pantau pesanan dan akses produk dari satu tempat.</p>
          </div>
        </div>
        {data ? (
          <dl className="mt-5 grid grid-cols-3 divide-x divide-border rounded-xl border border-border bg-card shadow-card">
            {[
              { label: "Pesanan aktif", value: data.activeOrders ?? data.recentOrders.length, icon: ReceiptText },
              { label: "Perlu dibayar", value: data.awaitingPayment, icon: Wallet },
              { label: "Produk saya", value: data.entitlements ?? 0, icon: Download },
            ].map((s) => (
              <div key={s.label} className="min-w-0 px-3 py-3.5 sm:flex sm:items-center sm:gap-3 sm:px-5">
                <span className="grid size-8 place-items-center rounded-lg bg-surface-selected text-accent">
                  <s.icon className="size-4" aria-hidden="true" />
                </span>
                <div className="mt-2 min-w-0 sm:mt-0">
                  <dd className="text-xl font-bold leading-none tabular-nums sm:text-2xl">{s.value}</dd>
                  <dt className="mt-1 text-[10px] leading-tight text-muted-foreground sm:text-xs">{s.label}</dt>
                </div>
              </div>
            ))}
          </dl>
        ) : null}
      </header>

      <section aria-labelledby="po-cta-heading">
        <Link
          to="/dashboard/po"
          className="group flex items-center gap-4 overflow-hidden rounded-2xl border border-accent/30 bg-gradient-to-r from-accent/15 via-card to-card p-4 shadow-card transition-all hover:border-accent/60 hover:shadow-lifted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:p-5"
        >
          <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-accent text-accent-foreground shadow-sm transition-transform group-hover:scale-110 sm:size-14">
            <MessageSquarePlus className="size-6 sm:size-7" aria-hidden="true" />
          </span>
          <div className="min-w-0 flex-1">
            <h2 id="po-cta-heading" className="text-base font-bold sm:text-lg">Pesan produk custom (PO)</h2>
            <p className="mt-0.5 text-sm text-muted-foreground">
              Punya kebutuhan khusus? Ajukan PO dan diskusikan langsung dengan tim kami.
            </p>
          </div>
          <ArrowRight className="size-5 shrink-0 text-accent transition-transform group-hover:translate-x-1" aria-hidden="true" />
        </Link>
      </section>

      <section aria-labelledby="shortcut-heading">
        <div className="mb-3 flex items-end justify-between gap-3">
          <div>
            <h2 id="shortcut-heading" className="text-base font-semibold">Mau ke mana?</h2>
            <p className="mt-0.5 text-sm text-muted-foreground">Akses cepat layanan Ebrystore.</p>
          </div>
        </div>
        <div className="grid grid-cols-3 gap-1 rounded-2xl border border-border bg-card p-2 shadow-card sm:grid-cols-6 sm:p-3">
          {shortcuts.map((s) => (
            <ServiceShortcut key={s.label} to={s.to} search={s.search} icon={s.icon} label={s.label} hint={s.hint} featured={s.featured} />
          ))}
        </div>
      </section>

      {isPending ? <CardSkeleton rows={3} /> : null}
      {error ? <ErrorState onRetry={() => refetch()} /> : null}

      {data ? (
        <>
          <section aria-labelledby="action-heading" className="space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h2 id="action-heading" className="text-base font-semibold">Perlu tindakanmu</h2>
                <p className="mt-0.5 text-sm text-muted-foreground">
                  {needsAction > 0 ? `${needsAction} aktivitas menunggu responsmu.` : "Semua sudah terkendali."}
                </p>
              </div>
              {needsAction > 0 ? (
                <span className="grid size-8 shrink-0 place-items-center rounded-full bg-warning text-sm font-bold text-warning-foreground" aria-label={`${needsAction} tindakan`}>
                  {needsAction > 9 ? "9+" : needsAction}
                </span>
              ) : null}
            </div>
            {data.awaitingPayment === 0 && data.underReview === 0 && data.activeRefunds === 0 ? (
              <div className="flex items-center gap-3 rounded-xl border border-success/30 bg-success/10 p-4">
                <span className="grid size-10 shrink-0 place-items-center rounded-full bg-success/15 text-success">
                  <CheckCircle2 className="size-5" aria-hidden="true" />
                </span>
                <div>
                  <p className="text-sm font-semibold">Tidak ada yang perlu kamu lakukan</p>
                  <p className="mt-0.5 text-sm text-muted-foreground">Semua pesananmu sedang berjalan normal.</p>
                </div>
              </div>
            ) : (
              <div className="grid gap-3 md:grid-cols-2">
                {data.awaitingPayment > 0 ? (
                  <ActionRequiredCard
                    icon={Wallet}
                    title={`${data.awaitingPayment} pesanan menunggu pembayaran`}
                    description="Selesaikan pembayaran sebelum batas waktu agar pesanan tidak kedaluwarsa."
                    actionLabel="Bayar sekarang"
                    to="/dashboard/pesanan"
                    search={{ filter: "unpaid" }}
                  />
                ) : null}
                {data.underReview > 0 ? (
                  <ActionRequiredCard
                    icon={Upload}
                    title="Bukti pembayaranmu sedang kami periksa"
                    description={`${data.underReview} pesanan menunggu verifikasi. Kami kabari begitu selesai.`}
                    actionLabel="Lihat pesanan"
                    to="/dashboard/pesanan"
                    search={{ filter: "unpaid" }}
                  />
                ) : null}
                {data.activeRefunds > 0 ? (
                  <ActionRequiredCard
                    icon={RotateCcw}
                    title={`${data.activeRefunds} pengajuan refund berjalan`}
                    description="Pantau perkembangan pengajuan refundmu di daftar pesanan."
                    actionLabel="Lihat refund"
                    to="/dashboard/pesanan"
                    search={{ filter: "all" }}
                  />
                ) : null}
              </div>
            )}
          </section>

          <div className="grid items-start gap-8 lg:grid-cols-[minmax(0,1.6fr)_minmax(18rem,0.8fr)]">
          <section aria-labelledby="order-heading" className="space-y-3">
            <div className="flex items-center justify-between gap-3">
              <h2 id="order-heading" className="text-base font-semibold">
                Pesanan aktif
              </h2>
              <Button asChild variant="ghost" size="sm">
                <Link to="/dashboard/pesanan" search={{ filter: "all" }}>
                  Lihat semua <ArrowRight className="size-4" aria-hidden="true" />
                </Link>
              </Button>
            </div>
            {data.recentOrders.length === 0 ? (
              <EmptyState
                icon={Compass}
                title="Belum ada pesanan"
                description="Temukan produk digital atau layanan yang kamu butuhkan."
                action={
                  <Button asChild size="sm">
                    <Link to="/produk">Jelajahi Ebrystore</Link>
                  </Button>
                }
              />
            ) : (
              <div className="grid gap-3 md:grid-cols-2">
                {data.recentOrders.map((o: any) => (
                  <OrderCard
                    key={o.id}
                    id={o.id}
                    orderNumber={o.order_number}
                    title={o.order_items?.[0]?.name_snapshot ?? "Pesanan Ebrystore"}
                    status={o.status}
                    total={o.total}
                    createdAt={o.created_at}
                  />
                ))}
              </div>
            )}
          </section>

          <section aria-labelledby="notif-heading" className="space-y-3 lg:border-l lg:border-border lg:pl-6">
            <div className="flex items-center justify-between gap-3">
              <h2 id="notif-heading" className="text-base font-semibold">Kabar terbaru</h2>
              <Button asChild variant="ghost" size="sm">
                <Link to="/dashboard/notifikasi" aria-label="Lihat semua notifikasi">
                  <ArrowRight className="size-4" aria-hidden="true" />
                </Link>
              </Button>
            </div>
            {data.notifications.length === 0 ? (
              <EmptyState
                icon={Bell}
                title="Belum ada kabar"
                description="Pemberitahuan pembayaran dan progres pesanan akan muncul di sini."
              />
            ) : (
              <div className="divide-y divide-border border-y border-border">
                {data.notifications.map((n: any) => (
                  <article
                    key={n.id}
                    className="relative flex items-start gap-3 py-4"
                  >
                    <span className="mt-0.5 grid size-8 shrink-0 place-items-center rounded-lg bg-surface-selected text-accent">
                      <Bell className="size-4" aria-hidden="true" />
                    </span>
                    <div className="min-w-0">
                      <p className="pr-3 text-sm font-semibold">{n.title}</p>
                      <p className="mt-1 line-clamp-2 text-sm leading-relaxed text-muted-foreground">{n.message}</p>
                      <time className="mt-2 block text-xs text-muted-foreground" dateTime={n.created_at}>
                        {new Date(n.created_at).toLocaleString("id-ID", { dateStyle: "medium", timeStyle: "short" })}
                      </time>
                      {!n.read_at ? <span className="absolute right-0 top-5 size-2 rounded-full bg-accent" aria-label="Belum dibaca" /> : null}
                    </div>
                  </article>
                ))}
              </div>
            )}
          </section>
          </div>
        </>
      ) : null}
    </div>
  );
}