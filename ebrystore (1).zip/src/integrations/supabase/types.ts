export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      academic_order_attachments: {
        Row: {
          attachment_type: string
          created_at: string
          deleted_at: string | null
          draft_key: string | null
          file_size: number
          id: string
          mime_type: string | null
          order_id: string | null
          original_name: string
          storage_path: string
          updated_at: string
          uploaded_by: string
        }
        Insert: {
          attachment_type: string
          created_at?: string
          deleted_at?: string | null
          draft_key?: string | null
          file_size: number
          id?: string
          mime_type?: string | null
          order_id?: string | null
          original_name: string
          storage_path: string
          updated_at?: string
          uploaded_by: string
        }
        Update: {
          attachment_type?: string
          created_at?: string
          deleted_at?: string | null
          draft_key?: string | null
          file_size?: number
          id?: string
          mime_type?: string | null
          order_id?: string | null
          original_name?: string
          storage_path?: string
          updated_at?: string
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "academic_order_attachments_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_tasks: {
        Row: {
          assignee_id: string | null
          completed_at: string | null
          created_at: string
          created_by: string | null
          description: string | null
          due_at: string | null
          id: string
          note: string | null
          priority: string
          source_id: string | null
          source_type: string
          status: string
          task_number: string
          task_type: string
          title: string
          updated_at: string
        }
        Insert: {
          assignee_id?: string | null
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          due_at?: string | null
          id?: string
          note?: string | null
          priority?: string
          source_id?: string | null
          source_type: string
          status?: string
          task_number?: string
          task_type: string
          title: string
          updated_at?: string
        }
        Update: {
          assignee_id?: string | null
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          description?: string | null
          due_at?: string | null
          id?: string
          note?: string | null
          priority?: string
          source_id?: string | null
          source_type?: string
          status?: string
          task_number?: string
          task_type?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      articles: {
        Row: {
          author_id: string | null
          author_name: string | null
          content: string
          cover_url: string | null
          created_at: string
          deleted_at: string | null
          excerpt: string | null
          id: string
          published_at: string | null
          reading_minutes: number
          slug: string
          status: string
          tags: string[]
          title: string
          updated_at: string
          view_count: number
        }
        Insert: {
          author_id?: string | null
          author_name?: string | null
          content?: string
          cover_url?: string | null
          created_at?: string
          deleted_at?: string | null
          excerpt?: string | null
          id?: string
          published_at?: string | null
          reading_minutes?: number
          slug: string
          status?: string
          tags?: string[]
          title: string
          updated_at?: string
          view_count?: number
        }
        Update: {
          author_id?: string | null
          author_name?: string | null
          content?: string
          cover_url?: string | null
          created_at?: string
          deleted_at?: string | null
          excerpt?: string | null
          id?: string
          published_at?: string | null
          reading_minutes?: number
          slug?: string
          status?: string
          tags?: string[]
          title?: string
          updated_at?: string
          view_count?: number
        }
        Relationships: []
      }
      audit_logs: {
        Row: {
          action: string
          actor_id: string | null
          actor_role: string | null
          after_json: Json | null
          before_json: Json | null
          created_at: string
          entity_id: string | null
          entity_type: string
          id: string
          ip: string | null
          reason: string | null
          trace_id: string | null
        }
        Insert: {
          action: string
          actor_id?: string | null
          actor_role?: string | null
          after_json?: Json | null
          before_json?: Json | null
          created_at?: string
          entity_id?: string | null
          entity_type: string
          id?: string
          ip?: string | null
          reason?: string | null
          trace_id?: string | null
        }
        Update: {
          action?: string
          actor_id?: string | null
          actor_role?: string | null
          after_json?: Json | null
          before_json?: Json | null
          created_at?: string
          entity_id?: string | null
          entity_type?: string
          id?: string
          ip?: string | null
          reason?: string | null
          trace_id?: string | null
        }
        Relationships: []
      }
      categories: {
        Row: {
          created_at: string
          deleted_at: string | null
          description: string | null
          id: string
          is_active: boolean
          kind: string
          name: string
          slug: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          deleted_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          kind: string
          name: string
          slug: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          deleted_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          kind?: string
          name?: string
          slug?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      custom_orders: {
        Row: {
          budget_estimate: number | null
          cancel_reason: string | null
          cancelled_at: string | null
          category_id: string | null
          completed_at: string | null
          created_at: string
          deadline_at: string | null
          delivered_at: string | null
          description: string
          dp_amount: number | null
          dp_percent: number
          id: string
          last_message_at: string
          quote_note: string | null
          quoted_at: string | null
          quoted_by: string | null
          quoted_total: number | null
          reference_url: string | null
          request_number: string
          result_note: string | null
          result_url: string | null
          status: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          budget_estimate?: number | null
          cancel_reason?: string | null
          cancelled_at?: string | null
          category_id?: string | null
          completed_at?: string | null
          created_at?: string
          deadline_at?: string | null
          delivered_at?: string | null
          description: string
          dp_amount?: number | null
          dp_percent?: number
          id?: string
          last_message_at?: string
          quote_note?: string | null
          quoted_at?: string | null
          quoted_by?: string | null
          quoted_total?: number | null
          reference_url?: string | null
          request_number?: string
          result_note?: string | null
          result_url?: string | null
          status?: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          budget_estimate?: number | null
          cancel_reason?: string | null
          cancelled_at?: string | null
          category_id?: string | null
          completed_at?: string | null
          created_at?: string
          deadline_at?: string | null
          delivered_at?: string | null
          description?: string
          dp_amount?: number | null
          dp_percent?: number
          id?: string
          last_message_at?: string
          quote_note?: string | null
          quoted_at?: string | null
          quoted_by?: string | null
          quoted_total?: number | null
          reference_url?: string | null
          request_number?: string
          result_note?: string | null
          result_url?: string | null
          status?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "custom_orders_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      digital_entitlements: {
        Row: {
          created_at: string
          download_count: number
          download_limit: number
          file_version: string | null
          id: string
          order_id: string
          order_item_id: string
          product_id: string
          revoked_at: string | null
          updated_at: string
          user_id: string
          valid_from: string
          valid_until: string
        }
        Insert: {
          created_at?: string
          download_count?: number
          download_limit?: number
          file_version?: string | null
          id?: string
          order_id: string
          order_item_id: string
          product_id: string
          revoked_at?: string | null
          updated_at?: string
          user_id: string
          valid_from?: string
          valid_until: string
        }
        Update: {
          created_at?: string
          download_count?: number
          download_limit?: number
          file_version?: string | null
          id?: string
          order_id?: string
          order_item_id?: string
          product_id?: string
          revoked_at?: string | null
          updated_at?: string
          user_id?: string
          valid_from?: string
          valid_until?: string
        }
        Relationships: [
          {
            foreignKeyName: "digital_entitlements_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "digital_entitlements_order_item_id_fkey"
            columns: ["order_item_id"]
            isOneToOne: true
            referencedRelation: "order_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "digital_entitlements_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "digital_products"
            referencedColumns: ["id"]
          },
        ]
      }
      digital_product_files: {
        Row: {
          assigned_at: string | null
          assigned_entitlement_id: string | null
          created_at: string
          id: string
          is_active: boolean
          mime_type: string | null
          original_name: string
          product_id: string
          size_bytes: number | null
          storage_path: string
          version: string | null
        }
        Insert: {
          assigned_at?: string | null
          assigned_entitlement_id?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          mime_type?: string | null
          original_name: string
          product_id: string
          size_bytes?: number | null
          storage_path: string
          version?: string | null
        }
        Update: {
          assigned_at?: string | null
          assigned_entitlement_id?: string | null
          created_at?: string
          id?: string
          is_active?: boolean
          mime_type?: string | null
          original_name?: string
          product_id?: string
          size_bytes?: number | null
          storage_path?: string
          version?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "digital_product_files_assigned_entitlement_id_fkey"
            columns: ["assigned_entitlement_id"]
            isOneToOne: false
            referencedRelation: "digital_entitlements"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "digital_product_files_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "digital_products"
            referencedColumns: ["id"]
          },
        ]
      }
      digital_products: {
        Row: {
          available_stock: number
          category_id: string | null
          created_at: string
          currency: string
          deleted_at: string | null
          delivery_mode: string
          description: string | null
          discount_price: number | null
          download_limit: number
          id: string
          is_test_data: boolean
          name: string
          price: number
          short_description: string | null
          slug: string
          sold_count: number
          status: string
          thumbnail_url: string | null
          updated_at: string
          usage_notes: string | null
          validity_days: number
          version: string | null
        }
        Insert: {
          available_stock?: number
          category_id?: string | null
          created_at?: string
          currency?: string
          deleted_at?: string | null
          delivery_mode?: string
          description?: string | null
          discount_price?: number | null
          download_limit?: number
          id?: string
          is_test_data?: boolean
          name: string
          price: number
          short_description?: string | null
          slug: string
          sold_count?: number
          status?: string
          thumbnail_url?: string | null
          updated_at?: string
          usage_notes?: string | null
          validity_days?: number
          version?: string | null
        }
        Update: {
          available_stock?: number
          category_id?: string | null
          created_at?: string
          currency?: string
          deleted_at?: string | null
          delivery_mode?: string
          description?: string | null
          discount_price?: number | null
          download_limit?: number
          id?: string
          is_test_data?: boolean
          name?: string
          price?: number
          short_description?: string | null
          slug?: string
          sold_count?: number
          status?: string
          thumbnail_url?: string | null
          updated_at?: string
          usage_notes?: string | null
          validity_days?: number
          version?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "digital_products_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      download_logs: {
        Row: {
          downloaded_at: string
          entitlement_id: string
          file_id: string | null
          id: string
          ip: string | null
          user_agent: string | null
          user_id: string
        }
        Insert: {
          downloaded_at?: string
          entitlement_id: string
          file_id?: string | null
          id?: string
          ip?: string | null
          user_agent?: string | null
          user_id: string
        }
        Update: {
          downloaded_at?: string
          entitlement_id?: string
          file_id?: string | null
          id?: string
          ip?: string | null
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "download_logs_entitlement_id_fkey"
            columns: ["entitlement_id"]
            isOneToOne: false
            referencedRelation: "digital_entitlements"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "download_logs_file_id_fkey"
            columns: ["file_id"]
            isOneToOne: false
            referencedRelation: "digital_product_files"
            referencedColumns: ["id"]
          },
        ]
      }
      invoices: {
        Row: {
          admin_fee: number
          billing_info: Json
          created_at: string
          currency: string
          customer_snapshot: Json
          discount: number
          due_at: string | null
          id: string
          invoice_number: string
          issued_at: string
          order_id: string
          paid_at: string | null
          status: string
          subtotal: number
          total: number
          updated_at: string
        }
        Insert: {
          admin_fee?: number
          billing_info?: Json
          created_at?: string
          currency?: string
          customer_snapshot?: Json
          discount?: number
          due_at?: string | null
          id?: string
          invoice_number?: string
          issued_at?: string
          order_id: string
          paid_at?: string | null
          status?: string
          subtotal?: number
          total?: number
          updated_at?: string
        }
        Update: {
          admin_fee?: number
          billing_info?: Json
          created_at?: string
          currency?: string
          customer_snapshot?: Json
          discount?: number
          due_at?: string | null
          id?: string
          invoice_number?: string
          issued_at?: string
          order_id?: string
          paid_at?: string | null
          status?: string
          subtotal?: number
          total?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoices_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: true
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      job_progress: {
        Row: {
          assignment_id: string | null
          created_at: string
          id: string
          is_public: boolean
          note: string
          operator_id: string
          order_id: string
          percent: number
          updated_at: string
        }
        Insert: {
          assignment_id?: string | null
          created_at?: string
          id?: string
          is_public?: boolean
          note: string
          operator_id: string
          order_id: string
          percent?: number
          updated_at?: string
        }
        Update: {
          assignment_id?: string | null
          created_at?: string
          id?: string
          is_public?: boolean
          note?: string
          operator_id?: string
          order_id?: string
          percent?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_progress_assignment_id_fkey"
            columns: ["assignment_id"]
            isOneToOne: false
            referencedRelation: "operator_assignments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_progress_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      job_results: {
        Row: {
          assignment_id: string | null
          attachments: Json
          created_at: string
          delivery_note: string | null
          id: string
          operator_id: string
          order_id: string
          result_url: string | null
          reviewed_at: string | null
          status: string
          submitted_at: string
          summary: string
          updated_at: string
          version: number
        }
        Insert: {
          assignment_id?: string | null
          attachments?: Json
          created_at?: string
          delivery_note?: string | null
          id?: string
          operator_id: string
          order_id: string
          result_url?: string | null
          reviewed_at?: string | null
          status?: string
          submitted_at?: string
          summary: string
          updated_at?: string
          version?: number
        }
        Update: {
          assignment_id?: string | null
          attachments?: Json
          created_at?: string
          delivery_note?: string | null
          id?: string
          operator_id?: string
          order_id?: string
          result_url?: string | null
          reviewed_at?: string | null
          status?: string
          submitted_at?: string
          summary?: string
          updated_at?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "job_results_assignment_id_fkey"
            columns: ["assignment_id"]
            isOneToOne: false
            referencedRelation: "operator_assignments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_results_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      job_revisions: {
        Row: {
          created_at: string
          customer_id: string
          id: string
          is_chargeable: boolean
          order_id: string
          reason: string
          resolved_at: string | null
          result_id: string | null
          sequence: number
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_id: string
          id?: string
          is_chargeable?: boolean
          order_id: string
          reason: string
          resolved_at?: string | null
          result_id?: string | null
          sequence?: number
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_id?: string
          id?: string
          is_chargeable?: boolean
          order_id?: string
          reason?: string
          resolved_at?: string | null
          result_id?: string | null
          sequence?: number
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_revisions_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_revisions_result_id_fkey"
            columns: ["result_id"]
            isOneToOne: false
            referencedRelation: "job_results"
            referencedColumns: ["id"]
          },
        ]
      }
      manual_payment_proofs: {
        Row: {
          amount_claimed: number | null
          created_at: string
          customer_id: string
          customer_note: string | null
          file_path: string
          id: string
          mime_type: string | null
          original_filename: string
          payment_id: string
          sender_name: string | null
          size_bytes: number | null
          status: string
          submitted_at: string
          updated_at: string
        }
        Insert: {
          amount_claimed?: number | null
          created_at?: string
          customer_id: string
          customer_note?: string | null
          file_path: string
          id?: string
          mime_type?: string | null
          original_filename: string
          payment_id: string
          sender_name?: string | null
          size_bytes?: number | null
          status?: string
          submitted_at?: string
          updated_at?: string
        }
        Update: {
          amount_claimed?: number | null
          created_at?: string
          customer_id?: string
          customer_note?: string | null
          file_path?: string
          id?: string
          mime_type?: string | null
          original_filename?: string
          payment_id?: string
          sender_name?: string | null
          size_bytes?: number | null
          status?: string
          submitted_at?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "manual_payment_proofs_payment_id_fkey"
            columns: ["payment_id"]
            isOneToOne: false
            referencedRelation: "payments"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          message: string
          read_at: string | null
          recipient_id: string
          related_id: string | null
          related_type: string | null
          title: string
          type: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          read_at?: string | null
          recipient_id: string
          related_id?: string | null
          related_type?: string | null
          title: string
          type: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          read_at?: string | null
          recipient_id?: string
          related_id?: string | null
          related_type?: string | null
          title?: string
          type?: string
        }
        Relationships: []
      }
      operator_assignments: {
        Row: {
          accepted_at: string | null
          assigned_at: string
          assigned_by: string | null
          completed_at: string | null
          created_at: string
          deadline_at: string | null
          id: string
          internal_note: string | null
          operator_id: string
          order_id: string
          started_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          accepted_at?: string | null
          assigned_at?: string
          assigned_by?: string | null
          completed_at?: string | null
          created_at?: string
          deadline_at?: string | null
          id?: string
          internal_note?: string | null
          operator_id: string
          order_id: string
          started_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          accepted_at?: string | null
          assigned_at?: string
          assigned_by?: string | null
          completed_at?: string | null
          created_at?: string
          deadline_at?: string | null
          id?: string
          internal_note?: string | null
          operator_id?: string
          order_id?: string
          started_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "operator_assignments_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      order_items: {
        Row: {
          addon_id: string | null
          created_at: string
          discount: number
          id: string
          item_type: string
          metadata: Json
          name_snapshot: string
          order_id: string
          package_id: string | null
          product_id: string | null
          quantity: number
          service_id: string | null
          sku_snapshot: string | null
          total: number
          unit_price: number
        }
        Insert: {
          addon_id?: string | null
          created_at?: string
          discount?: number
          id?: string
          item_type: string
          metadata?: Json
          name_snapshot: string
          order_id: string
          package_id?: string | null
          product_id?: string | null
          quantity?: number
          service_id?: string | null
          sku_snapshot?: string | null
          total: number
          unit_price: number
        }
        Update: {
          addon_id?: string | null
          created_at?: string
          discount?: number
          id?: string
          item_type?: string
          metadata?: Json
          name_snapshot?: string
          order_id?: string
          package_id?: string | null
          product_id?: string | null
          quantity?: number
          service_id?: string | null
          sku_snapshot?: string | null
          total?: number
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_items_addon_id_fkey"
            columns: ["addon_id"]
            isOneToOne: false
            referencedRelation: "service_addons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_package_id_fkey"
            columns: ["package_id"]
            isOneToOne: false
            referencedRelation: "service_packages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "digital_products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "order_items_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      order_status_histories: {
        Row: {
          actor_id: string | null
          actor_type: string
          created_at: string
          id: string
          internal_note: string | null
          metadata: Json
          new_status: string
          order_id: string
          previous_status: string | null
          public_note: string | null
        }
        Insert: {
          actor_id?: string | null
          actor_type?: string
          created_at?: string
          id?: string
          internal_note?: string | null
          metadata?: Json
          new_status: string
          order_id: string
          previous_status?: string | null
          public_note?: string | null
        }
        Update: {
          actor_id?: string | null
          actor_type?: string
          created_at?: string
          id?: string
          internal_note?: string | null
          metadata?: Json
          new_status?: string
          order_id?: string
          previous_status?: string | null
          public_note?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "order_status_histories_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          admin_fee: number
          cancellation_reason: string | null
          cancelled_at: string | null
          completed_at: string | null
          created_at: string
          currency: string
          customer_note: string | null
          discount_total: number
          expired_at: string | null
          id: string
          internal_note: string | null
          is_test_data: boolean
          order_number: string
          order_type: string
          paid_at: string | null
          status: string
          subtotal: number
          total: number
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_fee?: number
          cancellation_reason?: string | null
          cancelled_at?: string | null
          completed_at?: string | null
          created_at?: string
          currency?: string
          customer_note?: string | null
          discount_total?: number
          expired_at?: string | null
          id?: string
          internal_note?: string | null
          is_test_data?: boolean
          order_number?: string
          order_type: string
          paid_at?: string | null
          status?: string
          subtotal?: number
          total?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_fee?: number
          cancellation_reason?: string | null
          cancelled_at?: string | null
          completed_at?: string | null
          created_at?: string
          currency?: string
          customer_note?: string | null
          discount_total?: number
          expired_at?: string | null
          id?: string
          internal_note?: string | null
          is_test_data?: boolean
          order_number?: string
          order_type?: string
          paid_at?: string | null
          status?: string
          subtotal?: number
          total?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      payment_events: {
        Row: {
          created_at: string
          error: string | null
          event_type: string
          external_event_id: string
          id: string
          payload_hash: string | null
          payment_id: string | null
          processed_at: string | null
          processing_status: string
          provider: string
          signature_valid: boolean
        }
        Insert: {
          created_at?: string
          error?: string | null
          event_type: string
          external_event_id: string
          id?: string
          payload_hash?: string | null
          payment_id?: string | null
          processed_at?: string | null
          processing_status?: string
          provider: string
          signature_valid?: boolean
        }
        Update: {
          created_at?: string
          error?: string | null
          event_type?: string
          external_event_id?: string
          id?: string
          payload_hash?: string | null
          payment_id?: string | null
          processed_at?: string | null
          processing_status?: string
          provider?: string
          signature_valid?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "payment_events_payment_id_fkey"
            columns: ["payment_id"]
            isOneToOne: false
            referencedRelation: "payments"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_verifications: {
        Row: {
          created_at: string
          decision: string
          id: string
          new_status: string
          payment_id: string
          previous_status: string
          proof_id: string | null
          reason: string | null
          verified_at: string
          verifier_id: string
        }
        Insert: {
          created_at?: string
          decision: string
          id?: string
          new_status: string
          payment_id: string
          previous_status: string
          proof_id?: string | null
          reason?: string | null
          verified_at?: string
          verifier_id: string
        }
        Update: {
          created_at?: string
          decision?: string
          id?: string
          new_status?: string
          payment_id?: string
          previous_status?: string
          proof_id?: string | null
          reason?: string | null
          verified_at?: string
          verifier_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_verifications_payment_id_fkey"
            columns: ["payment_id"]
            isOneToOne: false
            referencedRelation: "payments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_verifications_proof_id_fkey"
            columns: ["proof_id"]
            isOneToOne: false
            referencedRelation: "manual_payment_proofs"
            referencedColumns: ["id"]
          },
        ]
      }
      payments: {
        Row: {
          created_at: string
          currency: string
          expected_amount: number
          expired_at: string | null
          external_transaction_id: string | null
          failed_at: string | null
          id: string
          idempotency_key: string
          method: string
          order_id: string
          paid_amount: number | null
          paid_at: string | null
          payment_number: string
          payment_url: string | null
          provider: string
          qr_reference: string | null
          reupload_count: number
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          currency?: string
          expected_amount: number
          expired_at?: string | null
          external_transaction_id?: string | null
          failed_at?: string | null
          id?: string
          idempotency_key: string
          method?: string
          order_id: string
          paid_amount?: number | null
          paid_at?: string | null
          payment_number?: string
          payment_url?: string | null
          provider?: string
          qr_reference?: string | null
          reupload_count?: number
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          currency?: string
          expected_amount?: number
          expired_at?: string | null
          external_transaction_id?: string | null
          failed_at?: string | null
          id?: string
          idempotency_key?: string
          method?: string
          order_id?: string
          paid_amount?: number | null
          paid_at?: string | null
          payment_number?: string
          payment_url?: string | null
          provider?: string
          qr_reference?: string | null
          reupload_count?: number
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payments_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      permissions: {
        Row: {
          created_at: string
          description: string
          group_name: string
          is_transactional: boolean
          key: string
        }
        Insert: {
          created_at?: string
          description: string
          group_name: string
          is_transactional?: boolean
          key: string
        }
        Update: {
          created_at?: string
          description?: string
          group_name?: string
          is_transactional?: boolean
          key?: string
        }
        Relationships: []
      }
      po_messages: {
        Row: {
          attachment_path: string | null
          body: string
          created_at: string
          id: string
          is_system: boolean
          request_id: string
          sender_id: string | null
          sender_role: string
        }
        Insert: {
          attachment_path?: string | null
          body: string
          created_at?: string
          id?: string
          is_system?: boolean
          request_id: string
          sender_id?: string | null
          sender_role?: string
        }
        Update: {
          attachment_path?: string | null
          body?: string
          created_at?: string
          id?: string
          is_system?: boolean
          request_id?: string
          sender_id?: string | null
          sender_role?: string
        }
        Relationships: [
          {
            foreignKeyName: "po_messages_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "custom_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      po_payments: {
        Row: {
          amount: number
          created_at: string
          id: string
          method: string
          note: string | null
          proof_path: string | null
          reject_reason: string | null
          request_id: string
          sender_name: string | null
          stage: string
          status: string
          updated_at: string
          user_id: string
          verified_at: string | null
          verified_by: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          method?: string
          note?: string | null
          proof_path?: string | null
          reject_reason?: string | null
          request_id: string
          sender_name?: string | null
          stage: string
          status?: string
          updated_at?: string
          user_id: string
          verified_at?: string | null
          verified_by?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          method?: string
          note?: string | null
          proof_path?: string | null
          reject_reason?: string | null
          request_id?: string
          sender_name?: string | null
          stage?: string
          status?: string
          updated_at?: string
          user_id?: string
          verified_at?: string | null
          verified_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "po_payments_request_id_fkey"
            columns: ["request_id"]
            isOneToOne: false
            referencedRelation: "custom_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      product_inquiries: {
        Row: {
          created_at: string
          id: string
          last_message_at: string
          product_id: string | null
          status: string
          subject: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          last_message_at?: string
          product_id?: string | null
          status?: string
          subject: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          last_message_at?: string
          product_id?: string | null
          status?: string
          subject?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_inquiries_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "digital_products"
            referencedColumns: ["id"]
          },
        ]
      }
      product_inquiry_messages: {
        Row: {
          body: string
          created_at: string
          id: string
          inquiry_id: string
          is_system: boolean
          sender_id: string | null
          sender_role: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          inquiry_id: string
          is_system?: boolean
          sender_id?: string | null
          sender_role?: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          inquiry_id?: string
          is_system?: boolean
          sender_id?: string | null
          sender_role?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_inquiry_messages_inquiry_id_fkey"
            columns: ["inquiry_id"]
            isOneToOne: false
            referencedRelation: "product_inquiries"
            referencedColumns: ["id"]
          },
        ]
      }
      product_reviews: {
        Row: {
          body: string | null
          created_at: string
          id: string
          is_visible: boolean
          order_id: string | null
          product_id: string
          rating: number
          reviewer_name: string | null
          title: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          is_visible?: boolean
          order_id?: string | null
          product_id: string
          rating: number
          reviewer_name?: string | null
          title?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          is_visible?: boolean
          order_id?: string | null
          product_id?: string
          rating?: number
          reviewer_name?: string | null
          title?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_reviews_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "product_reviews_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "digital_products"
            referencedColumns: ["id"]
          },
        ]
      }
      product_stock_codes: {
        Row: {
          assigned_at: string | null
          assigned_entitlement_id: string | null
          code: string
          created_at: string
          expires_at: string | null
          id: string
          note: string | null
          product_id: string
          source: string
          source_ref: string | null
          status: string
          updated_at: string
        }
        Insert: {
          assigned_at?: string | null
          assigned_entitlement_id?: string | null
          code: string
          created_at?: string
          expires_at?: string | null
          id?: string
          note?: string | null
          product_id: string
          source?: string
          source_ref?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          assigned_at?: string | null
          assigned_entitlement_id?: string | null
          code?: string
          created_at?: string
          expires_at?: string | null
          id?: string
          note?: string | null
          product_id?: string
          source?: string
          source_ref?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_stock_codes_assigned_entitlement_id_fkey"
            columns: ["assigned_entitlement_id"]
            isOneToOne: false
            referencedRelation: "digital_entitlements"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "product_stock_codes_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "digital_products"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          phone: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          phone?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      refunds: {
        Row: {
          amount: number
          created_at: string
          customer_id: string
          decision_note: string | null
          id: string
          order_id: string
          payment_id: string | null
          processed_at: string | null
          processing_reference: string | null
          reason: string
          refund_number: string
          requested_at: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string
        }
        Insert: {
          amount: number
          created_at?: string
          customer_id: string
          decision_note?: string | null
          id?: string
          order_id: string
          payment_id?: string | null
          processed_at?: string | null
          processing_reference?: string | null
          reason: string
          refund_number?: string
          requested_at?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          created_at?: string
          customer_id?: string
          decision_note?: string | null
          id?: string
          order_id?: string
          payment_id?: string | null
          processed_at?: string | null
          processing_reference?: string | null
          reason?: string
          refund_number?: string
          requested_at?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "refunds_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "refunds_payment_id_fkey"
            columns: ["payment_id"]
            isOneToOne: false
            referencedRelation: "payments"
            referencedColumns: ["id"]
          },
        ]
      }
      role_permissions: {
        Row: {
          created_at: string
          granted_by: string | null
          id: string
          permission_key: string
          role: Database["public"]["Enums"]["app_role"]
        }
        Insert: {
          created_at?: string
          granted_by?: string | null
          id?: string
          permission_key: string
          role: Database["public"]["Enums"]["app_role"]
        }
        Update: {
          created_at?: string
          granted_by?: string | null
          id?: string
          permission_key?: string
          role?: Database["public"]["Enums"]["app_role"]
        }
        Relationships: [
          {
            foreignKeyName: "role_permissions_permission_key_fkey"
            columns: ["permission_key"]
            isOneToOne: false
            referencedRelation: "permissions"
            referencedColumns: ["key"]
          },
        ]
      }
      scheduled_job_runs: {
        Row: {
          affected_count: number
          detail: Json
          error_message: string | null
          finished_at: string
          id: string
          job_name: string
          started_at: string
          status: string
        }
        Insert: {
          affected_count?: number
          detail?: Json
          error_message?: string | null
          finished_at?: string
          id?: string
          job_name: string
          started_at?: string
          status?: string
        }
        Update: {
          affected_count?: number
          detail?: Json
          error_message?: string | null
          finished_at?: string
          id?: string
          job_name?: string
          started_at?: string
          status?: string
        }
        Relationships: []
      }
      service_addons: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
          price: number
          service_id: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          price: number
          service_id: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          price?: number
          service_id?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_addons_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      service_order_details: {
        Row: {
          academic_category_id: string | null
          addon_total_snapshot: number | null
          addons_snapshot: Json
          assignment_description: string | null
          assignment_title: string | null
          citation_style: string | null
          course_name: string | null
          created_at: string
          customer_deadline: string | null
          customer_timezone: string | null
          dataset_description: string | null
          discount_snapshot: number | null
          education_level: string | null
          estimated_days: number
          estimated_pages: number | null
          extra_fields: Json
          file_format: string | null
          id: string
          institution_name: string | null
          integrity_accepted_at: string | null
          integrity_policy_version: string | null
          internal_deadline: string | null
          language: string | null
          lecturer_instructions: string | null
          no_credential_accepted_at: string | null
          official_deadline_at: string | null
          order_id: string
          output_type: string | null
          package_price_snapshot: number | null
          package_snapshot: Json
          presentation_duration: number | null
          pricing_breakdown: Json
          pricing_version: string | null
          requirements: Json
          requirements_complete: boolean
          requirements_note: string | null
          reviewer_fee_snapshot: number | null
          revision_allowance: number
          revision_limit_snapshot: number | null
          scope_flags: string[]
          scope_review_note: string | null
          scope_review_status: string
          scope_reviewed_at: string | null
          scope_reviewed_by: string | null
          software_required: string | null
          special_notes: string | null
          study_program: string | null
          subtotal_snapshot: number | null
          total_snapshot: number | null
          updated_at: string
          urgency_fee_snapshot: number | null
          urgency_level: string | null
        }
        Insert: {
          academic_category_id?: string | null
          addon_total_snapshot?: number | null
          addons_snapshot?: Json
          assignment_description?: string | null
          assignment_title?: string | null
          citation_style?: string | null
          course_name?: string | null
          created_at?: string
          customer_deadline?: string | null
          customer_timezone?: string | null
          dataset_description?: string | null
          discount_snapshot?: number | null
          education_level?: string | null
          estimated_days?: number
          estimated_pages?: number | null
          extra_fields?: Json
          file_format?: string | null
          id?: string
          institution_name?: string | null
          integrity_accepted_at?: string | null
          integrity_policy_version?: string | null
          internal_deadline?: string | null
          language?: string | null
          lecturer_instructions?: string | null
          no_credential_accepted_at?: string | null
          official_deadline_at?: string | null
          order_id: string
          output_type?: string | null
          package_price_snapshot?: number | null
          package_snapshot?: Json
          presentation_duration?: number | null
          pricing_breakdown?: Json
          pricing_version?: string | null
          requirements?: Json
          requirements_complete?: boolean
          requirements_note?: string | null
          reviewer_fee_snapshot?: number | null
          revision_allowance?: number
          revision_limit_snapshot?: number | null
          scope_flags?: string[]
          scope_review_note?: string | null
          scope_review_status?: string
          scope_reviewed_at?: string | null
          scope_reviewed_by?: string | null
          software_required?: string | null
          special_notes?: string | null
          study_program?: string | null
          subtotal_snapshot?: number | null
          total_snapshot?: number | null
          updated_at?: string
          urgency_fee_snapshot?: number | null
          urgency_level?: string | null
        }
        Update: {
          academic_category_id?: string | null
          addon_total_snapshot?: number | null
          addons_snapshot?: Json
          assignment_description?: string | null
          assignment_title?: string | null
          citation_style?: string | null
          course_name?: string | null
          created_at?: string
          customer_deadline?: string | null
          customer_timezone?: string | null
          dataset_description?: string | null
          discount_snapshot?: number | null
          education_level?: string | null
          estimated_days?: number
          estimated_pages?: number | null
          extra_fields?: Json
          file_format?: string | null
          id?: string
          institution_name?: string | null
          integrity_accepted_at?: string | null
          integrity_policy_version?: string | null
          internal_deadline?: string | null
          language?: string | null
          lecturer_instructions?: string | null
          no_credential_accepted_at?: string | null
          official_deadline_at?: string | null
          order_id?: string
          output_type?: string | null
          package_price_snapshot?: number | null
          package_snapshot?: Json
          presentation_duration?: number | null
          pricing_breakdown?: Json
          pricing_version?: string | null
          requirements?: Json
          requirements_complete?: boolean
          requirements_note?: string | null
          reviewer_fee_snapshot?: number | null
          revision_allowance?: number
          revision_limit_snapshot?: number | null
          scope_flags?: string[]
          scope_review_note?: string | null
          scope_review_status?: string
          scope_reviewed_at?: string | null
          scope_reviewed_by?: string | null
          software_required?: string | null
          special_notes?: string | null
          study_program?: string | null
          subtotal_snapshot?: number | null
          total_snapshot?: number | null
          updated_at?: string
          urgency_fee_snapshot?: number | null
          urgency_level?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "service_order_details_academic_category_id_fkey"
            columns: ["academic_category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "service_order_details_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: true
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      service_packages: {
        Row: {
          created_at: string
          description: string | null
          estimated_days: number
          free_revisions: number
          id: string
          included_outputs: string[]
          is_active: boolean
          is_test_data: boolean
          maximum_pages: number | null
          name: string
          price: number
          priority: string
          quality_review_included: boolean
          service_id: string
          sla_hours: number | null
          sort_order: number
          updated_at: string
          urgency_supported: boolean
        }
        Insert: {
          created_at?: string
          description?: string | null
          estimated_days?: number
          free_revisions?: number
          id?: string
          included_outputs?: string[]
          is_active?: boolean
          is_test_data?: boolean
          maximum_pages?: number | null
          name: string
          price: number
          priority?: string
          quality_review_included?: boolean
          service_id: string
          sla_hours?: number | null
          sort_order?: number
          updated_at?: string
          urgency_supported?: boolean
        }
        Update: {
          created_at?: string
          description?: string | null
          estimated_days?: number
          free_revisions?: number
          id?: string
          included_outputs?: string[]
          is_active?: boolean
          is_test_data?: boolean
          maximum_pages?: number | null
          name?: string
          price?: number
          priority?: string
          quality_review_included?: boolean
          service_id?: string
          sla_hours?: number | null
          sort_order?: number
          updated_at?: string
          urgency_supported?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "service_packages_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
        ]
      }
      services: {
        Row: {
          academic_category_id: string | null
          allows_attachments: boolean
          category_id: string | null
          created_at: string
          default_revision_limit: number
          default_sla_hours: number
          deleted_at: string | null
          description: string | null
          id: string
          integrity_policy_version: string
          is_test_data: boolean
          name: string
          order_capacity: number | null
          requirements_note: string | null
          requires_dataset: boolean
          requires_quality_review: boolean
          requires_rubric: boolean
          short_description: string | null
          slug: string
          status: string
          supported_citation_styles: string[]
          supported_education_levels: string[]
          supported_fields: string[]
          supported_outputs: string[]
          thumbnail_url: string | null
          updated_at: string
        }
        Insert: {
          academic_category_id?: string | null
          allows_attachments?: boolean
          category_id?: string | null
          created_at?: string
          default_revision_limit?: number
          default_sla_hours?: number
          deleted_at?: string | null
          description?: string | null
          id?: string
          integrity_policy_version?: string
          is_test_data?: boolean
          name: string
          order_capacity?: number | null
          requirements_note?: string | null
          requires_dataset?: boolean
          requires_quality_review?: boolean
          requires_rubric?: boolean
          short_description?: string | null
          slug: string
          status?: string
          supported_citation_styles?: string[]
          supported_education_levels?: string[]
          supported_fields?: string[]
          supported_outputs?: string[]
          thumbnail_url?: string | null
          updated_at?: string
        }
        Update: {
          academic_category_id?: string | null
          allows_attachments?: boolean
          category_id?: string | null
          created_at?: string
          default_revision_limit?: number
          default_sla_hours?: number
          deleted_at?: string | null
          description?: string | null
          id?: string
          integrity_policy_version?: string
          is_test_data?: boolean
          name?: string
          order_capacity?: number | null
          requirements_note?: string | null
          requires_dataset?: boolean
          requires_quality_review?: boolean
          requires_rubric?: boolean
          short_description?: string | null
          slug?: string
          status?: string
          supported_citation_styles?: string[]
          supported_education_levels?: string[]
          supported_fields?: string[]
          supported_outputs?: string[]
          thumbnail_url?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "services_academic_category_id_fkey"
            columns: ["academic_category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "services_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      system_settings: {
        Row: {
          description: string | null
          is_public: boolean
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          description?: string | null
          is_public?: boolean
          key: string
          updated_at?: string
          value: Json
        }
        Update: {
          description?: string | null
          is_public?: boolean
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      telegram_dispatch_log: {
        Row: {
          event: string
          id: string
          order_id: string
          sent_at: string
        }
        Insert: {
          event: string
          id?: string
          order_id: string
          sent_at?: string
        }
        Update: {
          event?: string
          id?: string
          order_id?: string
          sent_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "telegram_dispatch_log_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          granted_by: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          granted_by?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          granted_by?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_broadcast_notification: {
        Args: {
          _audience?: string
          _link?: string
          _message: string
          _role?: string
          _title: string
          _type?: string
          _user_ids?: string[]
        }
        Returns: Json
      }
      assign_operator: {
        Args: {
          _deadline?: string
          _note?: string
          _operator_id: string
          _order_id: string
        }
        Returns: Json
      }
      assign_stock_codes_for_order: {
        Args: { _order_id: string }
        Returns: number
      }
      assign_unique_file: { Args: { _entitlement_id: string }; Returns: string }
      assign_unique_files_for_order: {
        Args: { _order_id: string }
        Returns: number
      }
      cancel_own_order: {
        Args: { _order_id: string; _reason: string }
        Returns: Json
      }
      claim_stock_code: { Args: { _entitlement_id: string }; Returns: string }
      consume_download: {
        Args: { _entitlement_id: string; _ip?: string; _ua?: string }
        Returns: Json
      }
      create_academic_order: {
        Args: {
          _academic: Json
          _addon_ids: string[]
          _customer_note?: string
          _draft_key: string
          _idempotency_key: string
          _integrity_accepted: boolean
          _no_credential_accepted: boolean
          _package_id: string
          _reviewer_requested: boolean
          _scope_flags: string[]
          _service_id: string
        }
        Returns: Json
      }
      create_digital_order: {
        Args: {
          _customer_note?: string
          _idempotency_key: string
          _product_id: string
          _quantity: number
        }
        Returns: Json
      }
      create_service_order: {
        Args: {
          _addon_ids: string[]
          _customer_note?: string
          _idempotency_key: string
          _package_id: string
          _requirements: Json
          _requirements_note: string
          _service_id: string
        }
        Returns: Json
      }
      fulfill_waiting_stock_orders: {
        Args: { _product_id?: string }
        Returns: number
      }
      get_my_permissions: {
        Args: never
        Returns: {
          permission_key: string
        }[]
      }
      has_permission: {
        Args: { _permission: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      ingest_stock_codes: {
        Args: {
          _codes: string[]
          _expires_at?: string
          _product_id: string
          _source?: string
          _source_ref?: string
        }
        Returns: Json
      }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
      is_order_operator: {
        Args: { _order_id: string; _user_id: string }
        Returns: boolean
      }
      is_order_owner: {
        Args: { _order_id: string; _user_id: string }
        Returns: boolean
      }
      is_staff: { Args: { _user_id: string }; Returns: boolean }
      is_super_admin: { Args: { _user_id: string }; Returns: boolean }
      job_check_sla_breach: { Args: never; Returns: Json }
      job_expire_orders: { Args: never; Returns: Json }
      job_flag_overdue_tasks: { Args: never; Returns: Json }
      next_invoice_number: { Args: never; Returns: string }
      next_order_number: { Args: never; Returns: string }
      next_payment_number: { Args: never; Returns: string }
      next_po_number: { Args: never; Returns: string }
      next_refund_number: { Args: never; Returns: string }
      next_task_number: { Args: never; Returns: string }
      notify_payment_staff: {
        Args: {
          _msg: string
          _related_id: string
          _title: string
          _type: string
        }
        Returns: undefined
      }
      operator_update_assignment: {
        Args: {
          _action: string
          _is_public?: boolean
          _note?: string
          _order_id: string
          _percent?: number
        }
        Returns: Json
      }
      po_cancel_request: {
        Args: { _reason?: string; _request_id: string }
        Returns: Json
      }
      po_deliver: {
        Args: { _note?: string; _request_id: string; _result_url?: string }
        Returns: Json
      }
      po_respond_quote: {
        Args: { _accept: boolean; _note?: string; _request_id: string }
        Returns: Json
      }
      po_submit_payment_proof: {
        Args: {
          _file_path: string
          _note?: string
          _payment_id: string
          _sender_name?: string
        }
        Returns: Json
      }
      po_submit_quote: {
        Args: {
          _dp_percent: number
          _note?: string
          _request_id: string
          _total: number
        }
        Returns: Json
      }
      po_verify_payment: {
        Args: { _decision: string; _payment_id: string; _reason?: string }
        Returns: Json
      }
      process_refund: {
        Args: { _reference: string; _refund_id: string }
        Returns: Json
      }
      product_rating_summary: {
        Args: never
        Returns: {
          average_rating: number
          product_id: string
          review_count: number
        }[]
      }
      quote_academic_order: {
        Args: {
          _addon_ids: string[]
          _deadline: string
          _package_id: string
          _reviewer_requested: boolean
          _service_id: string
        }
        Returns: Json
      }
      recalc_code_stock: { Args: { _product_id: string }; Returns: undefined }
      recalc_product_stock: {
        Args: { _product_id: string }
        Returns: undefined
      }
      request_refund: {
        Args: { _order_id: string; _reason: string }
        Returns: Json
      }
      review_academic_scope: {
        Args: { _decision: string; _note?: string; _order_id: string }
        Returns: Json
      }
      review_job_result: {
        Args: { _decision: string; _order_id: string; _reason?: string }
        Returns: Json
      }
      review_refund: {
        Args: { _decision: string; _reason: string; _refund_id: string }
        Returns: Json
      }
      setting_int: { Args: { _default: number; _key: string }; Returns: number }
      settle_gateway_payment: {
        Args: {
          _method?: string
          _paid_amount: number
          _payment_id: string
          _provider: string
          _provider_ref: string
        }
        Returns: Json
      }
      stock_code_demand: { Args: never; Returns: Json }
      submit_job_result: {
        Args: {
          _delivery_note?: string
          _order_id: string
          _result_url?: string
          _summary: string
        }
        Returns: Json
      }
      submit_payment_proof: {
        Args: {
          _amount_claimed: number
          _file_path: string
          _mime_type: string
          _note?: string
          _original_filename: string
          _payment_id: string
          _sender_name: string
          _size_bytes: number
        }
        Returns: Json
      }
      submit_product_review: {
        Args: {
          _body?: string
          _product_id: string
          _rating: number
          _title?: string
        }
        Returns: Json
      }
      sync_my_profile_email: { Args: never; Returns: undefined }
      update_admin_task: {
        Args: {
          _action: string
          _assignee?: string
          _note?: string
          _task_id: string
        }
        Returns: Json
      }
      verify_manual_payment: {
        Args: { _decision: string; _payment_id: string; _reason?: string }
        Returns: Json
      }
      write_audit_log: {
        Args: {
          _action: string
          _after?: Json
          _before?: Json
          _entity_id?: string
          _entity_type: string
          _ip?: string
          _reason?: string
          _trace_id?: string
        }
        Returns: string
      }
    }
    Enums: {
      app_role:
        | "customer"
        | "operator"
        | "support"
        | "finance"
        | "admin"
        | "super_admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "customer",
        "operator",
        "support",
        "finance",
        "admin",
        "super_admin",
      ],
    },
  },
} as const
