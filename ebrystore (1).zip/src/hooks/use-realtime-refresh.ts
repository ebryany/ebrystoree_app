import { useEffect, useId, useRef } from "react";
import { useQueryClient, type QueryKey } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";

type Options = {
  /** Nama channel unik per layar. */
  channel: string;
  /** Tabel yang dipantau perubahannya. */
  tables: string[];
  /** Query key yang di-invalidate ketika ada perubahan. */
  keys: QueryKey[];
  /** Filter postgres opsional, mis. `order_id=eq.<uuid>`. */
  filter?: string;
  enabled?: boolean;
  /** Jeda penggabungan event beruntun (ms). */
  debounceMs?: number;
};

/**
 * Berlangganan perubahan realtime lalu menyegarkan cache query terkait.
 * Channel dibersihkan saat unmount agar tidak ada kebocoran koneksi.
 */
export function useRealtimeRefresh({
  channel,
  tables,
  keys,
  filter,
  enabled = true,
  debounceMs = 300,
}: Options) {
  const queryClient = useQueryClient();
  const instanceId = useId();
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const tableSig = tables.join(",");
  const keySig = JSON.stringify(keys);

  useEffect(() => {
    if (!enabled) return;
    // Nama channel unik per instance komponen agar dua layar tidak saling menimpa.
    const ch = supabase.channel(`${channel}:${instanceId}`);

    const flush = () => {
      timerRef.current = null;
      for (const key of JSON.parse(keySig) as QueryKey[]) {
        queryClient.invalidateQueries({ queryKey: key });
      }
    };

    const schedule = () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(flush, debounceMs);
    };

    for (const table of tableSig.split(",")) {
      ch.on(
        "postgres_changes" as any,
        { event: "*", schema: "public", table, ...(filter ? { filter } : {}) } as any,
        schedule,
      );
    }

    ch.subscribe((status) => {
      // Setelah (re)koneksi berhasil, samakan data yang mungkin tertinggal saat offline.
      if (status === "SUBSCRIBED") schedule();
    });

    // Segarkan saat tab kembali aktif — event yang terlewat tidak dikirim ulang.
    const onVisible = () => {
      if (document.visibilityState === "visible") schedule();
    };
    document.addEventListener("visibilitychange", onVisible);

    return () => {
      document.removeEventListener("visibilitychange", onVisible);
      if (timerRef.current) clearTimeout(timerRef.current);
      supabase.removeChannel(ch);
    };
  }, [channel, instanceId, tableSig, keySig, filter, enabled, debounceMs, queryClient]);
}
