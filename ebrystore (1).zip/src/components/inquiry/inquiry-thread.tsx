import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { CheckCheck, Loader2, MessagesSquare, Send } from "lucide-react";

import { AdminLoading } from "@/components/admin/admin-ui";
import { ErrorState } from "@/components/ebry/states";
import { StatusPill } from "@/components/ebry/status";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useSession } from "@/hooks/use-session";
import { useRealtimeRefresh } from "@/hooks/use-realtime-refresh";
import { getInquiry, sendInquiryMessage, setInquiryStatus } from "@/lib/inquiries.functions";

export const INQUIRY_STATUS_LABEL: Record<string, string> = {
  open: "Menunggu jawaban",
  answered: "Sudah dijawab",
  closed: "Ditutup",
};

function formatTime(value: string) {
  return new Date(value).toLocaleString("id-ID", { dateStyle: "medium", timeStyle: "short" });
}

export function InquiryThread({ id, mode }: { id: string; mode: "customer" | "staff" }) {
  const queryClient = useQueryClient();
  const { user } = useSession();
  const fetchInquiry = useServerFn(getInquiry);
  const postMessage = useServerFn(sendInquiryMessage);
  const updateStatus = useServerFn(setInquiryStatus);

  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  const queryKey = ["inquiry", id];
  const { data, isPending, error, refetch } = useQuery({ queryKey, queryFn: () => fetchInquiry({ data: { id } }) });

  useRealtimeRefresh({
    channel: `inquiry-${id}`,
    tables: ["product_inquiry_messages", "product_inquiries"],
    keys: [queryKey],
  });

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end", behavior: "smooth" });
  }, [data?.messages?.length]);

  if (isPending) return <AdminLoading />;
  if (error) return <ErrorState onRetry={() => refetch()} />;
  if (!data?.inquiry)
    return <ErrorState title="Percakapan tidak ditemukan" description="Percakapan mungkin sudah dihapus." />;

  const inquiry = data.inquiry as any;
  const product = data.product as { name: string; slug: string } | null;
  const closed = inquiry.status === "closed";

  async function send() {
    const text = body.trim();
    if (!text) return;
    setBusy(true);
    const result = await postMessage({ data: { inquiryId: id, body: text } });
    setBusy(false);
    if (!result.ok) {
      toast.error(result.error);
      return;
    }
    setBody("");
    queryClient.invalidateQueries({ queryKey });
  }

  async function close() {
    const result = await updateStatus({ data: { inquiryId: id, status: closed ? "open" : "closed" } });
    if (!result.ok) {
      toast.error(result.error);
      return;
    }
    toast.success(closed ? "Percakapan dibuka kembali." : "Percakapan ditutup.");
    queryClient.invalidateQueries({ queryKey });
  }

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-border bg-card p-4 shadow-card">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-sm font-semibold">{inquiry.subject}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              {mode === "staff" ? `Dari ${data.customerName} · ` : ""}
              Dibuat {formatTime(inquiry.created_at)}
            </p>
            {product ? (
              <Link
                to="/produk/$slug"
                params={{ slug: product.slug }}
                className="mt-2 inline-flex text-xs font-semibold text-primary hover:underline"
              >
                Lihat produk: {product.name}
              </Link>
            ) : null}
          </div>
          <div className="flex items-center gap-2">
            <StatusPill value={inquiry.status} kind="raw" label={INQUIRY_STATUS_LABEL[inquiry.status]} />
            {mode === "staff" ? (
              <Button variant="outline" size="sm" onClick={close}>
                <CheckCheck className="size-4" aria-hidden="true" />
                {closed ? "Buka lagi" : "Tutup"}
              </Button>
            ) : null}
          </div>
        </div>
      </div>

      <div className="max-h-[60vh] space-y-3 overflow-y-auto rounded-2xl border border-border bg-surface p-4">
        {data.messages.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">Belum ada pesan.</p>
        ) : null}
        {data.messages.map((m: any) => {
          const mine = m.sender_id === user?.id;
          return (
            <div key={m.id} className={mine ? "flex justify-end" : "flex justify-start"}>
              <div
                className={
                  mine
                    ? "max-w-[85%] rounded-2xl rounded-br-sm bg-primary px-3.5 py-2.5 text-sm text-primary-foreground"
                    : "max-w-[85%] rounded-2xl rounded-bl-sm border border-border bg-card px-3.5 py-2.5 text-sm"
                }
              >
                <p className="whitespace-pre-line">{m.body}</p>
                <p className={mine ? "mt-1 text-[11px] opacity-80" : "mt-1 text-[11px] text-muted-foreground"}>
                  {m.sender_role === "staff" ? "Tim Ebrystore · " : ""}
                  {formatTime(m.created_at)}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {closed ? (
        <p className="flex items-center gap-2 rounded-2xl border border-dashed border-border px-4 py-3 text-sm text-muted-foreground">
          <MessagesSquare className="size-4" aria-hidden="true" /> Percakapan ini sudah ditutup.
        </p>
      ) : (
        <div className="flex items-end gap-2">
          <Textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={2}
            maxLength={2000}
            placeholder="Tulis pesan…"
            aria-label="Tulis pesan"
            className="min-h-11 flex-1"
          />
          <Button onClick={send} disabled={busy || !body.trim()} className="min-h-11">
            {busy ? (
              <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            ) : (
              <Send className="size-4" aria-hidden="true" />
            )}
            Kirim
          </Button>
        </div>
      )}
    </div>
  );
}
