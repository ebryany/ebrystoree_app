import { Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  BookOpen,
  ChevronRight,
  ClipboardList,
  HelpCircle,
  LayoutDashboard,
  LogOut,
  Menu,
  Package,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  UserRound,
} from "lucide-react";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { NotificationBell } from "@/components/ebry/notification-bell";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { useSession } from "@/hooks/use-session";
import { useSiteNav, useWebsiteSettings } from "@/hooks/use-website-settings";
import { supabase } from "@/integrations/supabase/client";
import { getMyRoles } from "@/lib/admin.functions";

const NAV_META: Record<string, { description: string; icon: typeof Package }> = {
  "/produk": { description: "File siap pakai, langsung diunduh", icon: Package },
  "/layanan": { description: "Pendampingan akademik, progres tercatat", icon: Sparkles },
  "/bantuan": { description: "Cara pesan, bayar, dan pantau", icon: HelpCircle },
  "/artikel": { description: "Panduan singkat dari tim kami", icon: BookOpen },
};

export function SiteHeader({ variant = "default" }: { variant?: "default" | "dark" }) {
  const { user, loading } = useSession();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const settings = useWebsiteSettings();
  const navItems = useSiteNav("header", Boolean(user)).map((item) => ({
    to: item.url,
    label: item.label,
    newTab: item.open_in_new_tab,
    description: NAV_META[item.url]?.description ?? "",
    icon: NAV_META[item.url]?.icon ?? ChevronRight,
  }));
  const brandName = String(settings.store_name ?? "Ebrystore");
  const logoUrl = String(settings.site_logo_url ?? "");
  const fetchRoles = useServerFn(getMyRoles);
  const { data: access } = useQuery({
    queryKey: ["my-roles"],
    queryFn: () => fetchRoles({}),
    enabled: Boolean(user),
  });
  const isAdmin = Boolean(access?.isAdmin);
  const isOperator = Boolean(access?.roles?.includes("operator"));

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  // Satu gaya navbar untuk semua halaman: pill gelap ink-teal mengambang.
  void variant;
  const dark = true;

  return (
    <header className="sticky top-3 z-40">
      <div className="mx-auto flex h-16 w-[calc(100%-2rem)] max-w-6xl items-center gap-4 rounded-2xl border border-glass-border bg-primary/95 px-4 text-primary-foreground shadow-lifted backdrop-blur-xl sm:px-5">
        <Link to="/" className={dark ? "flex items-center gap-2.5 text-lg font-bold text-primary-foreground" : "flex items-center gap-2.5 text-lg font-bold text-foreground"}>
          {logoUrl ? (
            <img src={logoUrl} alt="" className="size-8 rounded-lg object-contain" />
          ) : (
            <span className="flex size-8 items-center justify-center rounded-lg bg-accent-gradient text-accent-foreground shadow-sm">
              <ShoppingBag className="size-4" aria-hidden="true" />
            </span>
          )}
          {brandName}
        </Link>

        <nav aria-label="Navigasi utama" className="ml-5 hidden items-center gap-1 md:flex">
          {navItems.map((item) => (
            <Link
              key={`${item.to}-${item.label}`}
              to={item.to as string}
              target={item.newTab ? "_blank" : undefined}
              className={dark ? "rounded-lg px-3 py-2 text-sm font-medium text-primary-foreground/70 transition-colors hover:bg-glass-strong hover:text-primary-foreground" : "rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"}
              activeProps={{ className: dark ? "bg-glass-strong text-primary-foreground" : "bg-muted text-foreground" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto hidden items-center gap-2 md:flex">
          {loading ? (
            <div className="h-9 w-32 animate-pulse rounded-md bg-muted" aria-hidden="true" />
          ) : user ? (
            <>
              <NotificationBell className={dark ? "text-primary-foreground hover:bg-glass-strong hover:text-primary-foreground" : undefined} />
              {isAdmin ? (
                <Button asChild variant="ghost" size="sm" className={dark ? "text-primary-foreground hover:bg-glass-strong hover:text-primary-foreground" : undefined}>
                  <Link to="/admin">Dashboard admin</Link>
                </Button>
              ) : null}
              {isOperator ? (
                <Button asChild variant="ghost" size="sm" className={dark ? "text-primary-foreground hover:bg-glass-strong hover:text-primary-foreground" : undefined}>
                  <Link to="/operator">Tugas saya</Link>
                </Button>
              ) : null}
              <Button asChild variant="ghost" size="sm" className={dark ? "text-primary-foreground hover:bg-glass-strong hover:text-primary-foreground" : undefined}>
                <Link to="/dashboard">Akun saya</Link>
              </Button>
              <Button variant="outline" size="sm" className={dark ? "border-glass-border bg-glass text-primary-foreground hover:bg-glass-strong hover:text-primary-foreground" : undefined} onClick={handleSignOut}>
                Keluar
              </Button>
            </>
          ) : (
            <>
              <Button asChild variant="ghost" size="sm" className={dark ? "text-primary-foreground hover:bg-glass-strong hover:text-primary-foreground" : undefined}>
                <Link to="/auth">Masuk</Link>
              </Button>
              <Button asChild size="sm" className={dark ? "bg-accent-gradient text-accent-foreground shadow-lg hover:opacity-90" : undefined}>
                <Link to="/auth" search={{ mode: "daftar" }}>Daftar</Link>
              </Button>
            </>
          )}
        </div>

        <div className="ml-auto flex items-center gap-1 md:hidden">
          {user ? <NotificationBell className={dark ? "text-primary-foreground hover:bg-glass-strong hover:text-primary-foreground" : undefined} /> : null}
          <Button
            variant="ghost"
            size="icon"
            className={dark ? "min-h-11 min-w-11 text-primary-foreground hover:bg-glass-strong hover:text-primary-foreground" : "min-h-11 min-w-11"}
            aria-label="Buka menu"
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            <Menu className="size-5" />
          </Button>
        </div>
      </div>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent
          side="right"
          className="flex w-[90vw] max-w-sm flex-col gap-0 overflow-y-auto p-0 [&>button]:top-6 [&>button]:right-5 [&>button]:text-primary-foreground md:hidden"
        >
          <div className="bg-primary px-5 pt-6 pb-5 text-primary-foreground">
            <SheetTitle className="flex items-center gap-2 pr-10 text-primary-foreground">
              {logoUrl ? (
                 <img src={logoUrl} alt="" className="size-9 rounded-xl bg-glass object-contain" />
              ) : (
                 <span className="flex size-9 items-center justify-center rounded-xl bg-accent-gradient text-accent-foreground">
                  <ShoppingBag className="size-4" aria-hidden="true" />
                </span>
              )}
              {brandName}
            </SheetTitle>
            <p className="mt-3 text-sm text-primary-foreground/75">
              {user
                ? user.email ?? "Akun kamu aktif"
                : "Masuk untuk memesan dan memantau pesananmu."}
            </p>
          </div>

          <nav aria-label="Navigasi seluler" className="flex flex-col gap-2 px-4 py-5">
            <p className="px-1 text-xs font-semibold tracking-widest text-muted-foreground uppercase">
              Jelajahi
            </p>
            {navItems.map((item) => (
              <Link
                key={`${item.to}-${item.label}`}
                to={item.to as string}
                target={item.newTab ? "_blank" : undefined}
                onClick={() => setOpen(false)}
                className="flex min-h-14 items-center gap-3 rounded-xl border border-border/70 bg-card px-3 py-3 transition-colors hover:bg-muted"
                activeProps={{ className: "border-primary/40 bg-muted" }}
              >
                <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-muted text-primary">
                  <item.icon className="size-5" aria-hidden="true" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-base font-semibold text-foreground">
                    {item.label}
                  </span>
                  <span className="block text-xs text-muted-foreground">{item.description}</span>
                </span>
                <ChevronRight className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
              </Link>
            ))}
          </nav>

          <div className="mt-auto border-t border-border/70 bg-muted/40 px-4 py-5">
            {user ? (
              <div className="flex flex-col gap-2">
                <p className="px-1 text-xs font-semibold tracking-widest text-muted-foreground uppercase">
                  Akun
                </p>
                {isAdmin ? (
                  <Button asChild variant="outline" size="lg" className="h-12 w-full justify-start">
                    <Link to="/admin" onClick={() => setOpen(false)}>
                      <ShieldCheck className="size-5" aria-hidden="true" />
                      Dashboard admin
                    </Link>
                  </Button>
                ) : null}
                {isOperator ? (
                  <Button asChild variant="outline" size="lg" className="h-12 w-full justify-start">
                    <Link to="/operator" onClick={() => setOpen(false)}>
                      <ClipboardList className="size-5" aria-hidden="true" />
                      Tugas saya
                    </Link>
                  </Button>
                ) : null}
                <Button asChild size="lg" className="h-12 w-full justify-start">
                  <Link to="/dashboard" onClick={() => setOpen(false)}>
                    <LayoutDashboard className="size-5" aria-hidden="true" />
                    Akun saya
                  </Link>
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="h-12 w-full justify-start text-destructive hover:bg-destructive/10 hover:text-destructive"
                  onClick={handleSignOut}
                >
                  <LogOut className="size-5" aria-hidden="true" />
                  Keluar
                </Button>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <Button asChild size="lg" className="h-12 w-full">
                    <Link to="/auth" search={{ mode: "daftar" }} onClick={() => setOpen(false)}>
                    <UserRound className="size-5" aria-hidden="true" />
                    Daftar gratis
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="h-12 w-full">
                  <Link to="/auth" onClick={() => setOpen(false)}>
                    Masuk
                  </Link>
                </Button>
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </header>
  );
}