import { Link } from "@tanstack/react-router";

import { useSession } from "@/hooks/use-session";
import { useSiteNav, useWebsiteSettings } from "@/hooks/use-website-settings";
import type { NavLocation } from "@/lib/website-settings";

function FooterNav({ label, location }: { label: string; location: NavLocation }) {
  const { user } = useSession();
  const items = useSiteNav(location, Boolean(user));
  if (!items.length) return null;
  return (
    <nav aria-label={label} className="text-sm">
      <p className="font-semibold">{label}</p>
      <ul className="mt-3 space-y-2 text-muted-foreground">
        {items.map((item) => (
          <li key={`${item.url}-${item.label}`}>
            <Link
              to={item.url as string}
              target={item.open_in_new_tab ? "_blank" : undefined}
              className="hover:text-foreground"
            >
              {item.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}

export function SiteFooter() {
  const settings = useWebsiteSettings();
  return (
    <footer className="mt-20 border-t border-border bg-surface">
      <div className="mx-auto grid w-full max-w-6xl gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="text-base font-bold">{String(settings.store_name ?? "Ebrystore")}</p>
          <p className="mt-2 text-sm text-muted-foreground">{String(settings.site_description ?? "")}</p>
          {settings.site_support_email ? (
            <p className="mt-3 text-sm text-muted-foreground">
              <a className="hover:text-foreground" href={`mailto:${settings.site_support_email}`}>
                {String(settings.site_support_email)}
              </a>
            </p>
          ) : null}
          {settings.site_whatsapp ? (
            <p className="text-sm text-muted-foreground">WhatsApp {String(settings.site_whatsapp)}</p>
          ) : null}
          {settings.site_operating_hours ? (
            <p className="mt-1 text-xs text-muted-foreground">{String(settings.site_operating_hours)}</p>
          ) : null}
        </div>
        <FooterNav label="Katalog" location="footer_product" />
        <FooterNav label="Layanan" location="footer_service" />
        <FooterNav label="Akun & bantuan" location="footer_help" />
        <FooterNav label="Kebijakan" location="footer_legal" />
      </div>
      <div className="border-t border-border px-4 py-5 text-center text-xs text-muted-foreground">
        <p>
          Pembayaran memakai QRIS dan transfer manual. Status pembayaran diverifikasi dari sisi
          server sebelum pesanan diproses.
        </p>
        <p className="mt-2">
          © {new Date().getFullYear()} {String(settings.site_business_name ?? "Ebrystore")}.
        </p>
      </div>
    </footer>
  );
}