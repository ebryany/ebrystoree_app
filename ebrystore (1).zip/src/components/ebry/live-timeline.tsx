import { useEffect, useMemo, useRef, useState } from "react";
import {
  CheckCircle2,
  ClipboardCheck,
  CreditCard,
  FileCheck2,
  MessageSquareWarning,
  PackageCheck,
  Radio,
  Rocket,
  UserCheck,
  Wallet,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { cn } from "@/lib/utils";
import { ORDER_STATUS_LABEL } from "@/lib/transaction-labels";

export type LiveEvent = {
  id: string;
  at: string;
  title: string;
  description?: string | null;
  icon: LucideIcon;
  tone: "accent" | "muted" | "danger";
};

const DIGITAL_STAGES = ["awaiting_payment", "payment_under_review", "paid", "completed"] as const;
const SERVICE_STAGES = [
  "awaiting_payment",
  "payment_under_review",
  "paid",
  "waiting_assignment",
  "in_progress",
  "waiting_customer_review",
  "completed",
] as const;

const STAGE_ORDER: Record<string, number> = {
  draft: 0,
  awaiting_payment: 0,
  payment_under_review: 1,
  paid: 2,
  waiting_assignment: 3,
  assigned: 3,
  waiting_customer_data: 3,
  queued: 3,
  academic_review: 3,
  in_progress: 4,
  waiting_customer_review: 5,
  completed: 6,
};

/** Jarak waktu relatif dalam Bahasa Indonesia. */
function relative(from: string, now: number): string {
  const diff = Math.max(0, now - new Date(from).getTime());
  const s = Math.floor(diff / 1000);
  if (s < 45) return "baru saja";
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} menit lalu`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} jam lalu`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d} hari lalu`;
  return new Date(from).toLocaleDateString("id-ID", { dateStyle: "medium" });
}

/** Jam berjalan supaya label waktu relatif tetap hidup tanpa refetch. */
function useNow(intervalMs = 20000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(t);
  }, [intervalMs]);
  return now;
}

export function buildOrderEvents(input: {
  order: any;
  histories: any[];
  payments?: any[];
  fulfillment?: any;
}): LiveEvent[] {
  const events: LiveEvent[] = [];
  const { order, histories, payments = [], fulfillment } = input;

  if (order?.created_at) {
    events.push({
      id: `order-${order.id}`,
      at: order.created_at,
      title: "Pesanan dibuat",
      description: order.order_number,
      icon: Rocket,
      tone: "muted",
    });
  }

  for (const h of histories ?? []) {
    events.push({
      id: `hist-${h.created_at}-${h.new_status}`,
      at: h.created_at,
      title: ORDER_STATUS_LABEL[h.new_status] ?? h.new_status,
      description: h.public_note ?? null,
      icon: h.new_status === "completed" ? PackageCheck : ClipboardCheck,
      tone: ["cancelled", "disputed", "refund_requested"].includes(h.new_status) ? "danger" : "accent",
    });
  }

  for (const p of payments) {
    if (p.paid_at) {
      events.push({
        id: `pay-${p.id}`,
        at: p.paid_at,
        title: "Pembayaran terverifikasi",
        description: p.payment_number,
        icon: Wallet,
        tone: "accent",
      });
    }
  }

  for (const item of fulfillment?.progress ?? []) {
    events.push({
      id: `prog-${item.id}`,
      at: item.created_at,
      title: item.title ?? "Update pengerjaan",
      description: item.note ?? item.description ?? null,
      icon: Radio,
      tone: "accent",
    });
  }

  for (const item of fulfillment?.results ?? []) {
    events.push({
      id: `res-${item.id}`,
      at: item.created_at,
      title: "Hasil pekerjaan dikirim",
      description: item.summary ?? item.note ?? null,
      icon: FileCheck2,
      tone: "accent",
    });
  }

  for (const item of fulfillment?.revisions ?? []) {
    events.push({
      id: `rev-${item.id}`,
      at: item.created_at,
      title: "Permintaan revisi",
      description: item.reason ?? null,
      icon: MessageSquareWarning,
      tone: "danger",
    });
  }

  if (fulfillment?.assignment?.assigned_at) {
    events.push({
      id: `asg-${fulfillment.assignment.id}`,
      at: fulfillment.assignment.assigned_at,
      title: "Pendamping ditugaskan",
      description: fulfillment.operatorName ?? null,
      icon: UserCheck,
      tone: "accent",
    });
  }

  const seen = new Set<string>();
  return events
    .filter((e) => e.at && (seen.has(e.id) ? false : (seen.add(e.id), true)))
    .sort((a, b) => new Date(b.at).getTime() - new Date(a.at).getTime());
}

const STAGE_ICON: Record<string, LucideIcon> = {
  awaiting_payment: CreditCard,
  payment_under_review: Wallet,
  paid: CheckCircle2,
  waiting_assignment: UserCheck,
  in_progress: Radio,
  waiting_customer_review: FileCheck2,
  completed: PackageCheck,
};

/** Timeline pesanan realtime: rel tahapan + feed aktivitas langsung. */
export function LiveOrderTimeline({
  order,
  histories,
  payments,
  fulfillment,
  className,
}: {
  order: any;
  histories: any[];
  payments?: any[];
  fulfillment?: any;
  className?: string;
}) {
  const now = useNow();
  const events = useMemo(
    () => buildOrderEvents({ order, histories, payments, fulfillment }),
    [order, histories, payments, fulfillment],
  );

  const stages = order?.order_type === "service" ? SERVICE_STAGES : DIGITAL_STAGES;
  const currentIndex = STAGE_ORDER[order?.status] ?? 0;
  const terminal = ["cancelled", "refunded", "refund_processing", "refund_requested", "disputed"].includes(
    order?.status,
  );

  // Sorot event baru yang masuk lewat realtime.
  const knownRef = useRef<Set<string> | null>(null);
  const [fresh, setFresh] = useState<string[]>([]);
  useEffect(() => {
    const ids = events.map((e) => e.id);
    if (knownRef.current === null) {
      knownRef.current = new Set(ids);
      return;
    }
    const added = ids.filter((id) => !knownRef.current!.has(id));
    if (added.length) {
      added.forEach((id) => knownRef.current!.add(id));
      setFresh(added);
      const t = setTimeout(() => setFresh([]), 6000);
      return () => clearTimeout(t);
    }
  }, [events]);

  const latest = events[0];

  return (
    <section className={cn("min-w-0 rounded-2xl border border-border bg-card p-5", className)} aria-live="polite">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-semibold">Lini masa pesanan</h2>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-success/30 bg-success/10 px-2.5 py-1 text-xs font-semibold text-success">
          <span className="relative flex size-2">
            <span className="absolute inline-flex size-full animate-ping rounded-full bg-success opacity-70" />
            <span className="relative inline-flex size-2 rounded-full bg-success" />
          </span>
          Pantauan langsung
        </span>
      </div>
      <p className="mt-1 text-xs text-muted-foreground">
        {latest ? `Pembaruan terakhir ${relative(latest.at, now)}` : "Belum ada aktivitas."}
      </p>

      {/* Rel tahapan */}
      <ol className="-mx-1 mt-4 flex min-w-0 max-w-full gap-1.5 overflow-x-auto px-1 pb-1" aria-label="Tahapan pesanan">
        {stages.map((stage) => {
          const idx = STAGE_ORDER[stage] ?? 0;
          const done = !terminal && idx < currentIndex;
          const active = !terminal && idx === currentIndex;
          const Icon = STAGE_ICON[stage] ?? ClipboardCheck;
          return (
            <li
              key={stage}
              className={cn(
                "flex w-[7rem] shrink-0 flex-col gap-1.5 rounded-xl border p-2.5 transition-colors sm:w-auto sm:min-w-[7.5rem] sm:flex-1",
                done
                  ? "border-accent/40 bg-accent/10"
                  : active
                    ? "border-accent bg-surface-selected/60 shadow-card"
                    : "border-border bg-background",
              )}
              aria-current={active ? "step" : undefined}
            >
              <span className="flex items-center gap-1.5">
                <Icon
                  className={cn(
                    "size-4 shrink-0",
                    done || active ? "text-accent" : "text-muted-foreground",
                    active && "animate-pulse",
                  )}
                  aria-hidden="true"
                />
                <span
                  className={cn(
                    "h-1 flex-1 rounded-full",
                    done ? "bg-accent" : active ? "bg-accent/40" : "bg-border",
                  )}
                />
              </span>
              <span
                className={cn(
                  "text-[11px] font-semibold leading-tight",
                  done || active ? "text-foreground" : "text-muted-foreground",
                )}
              >
                {ORDER_STATUS_LABEL[stage] ?? stage}
              </span>
            </li>
          );
        })}
      </ol>

      {terminal ? (
        <p className="mt-3 rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-xs text-destructive">
          Status pesanan saat ini: {ORDER_STATUS_LABEL[order.status] ?? order.status}.
        </p>
      ) : null}

      {/* Feed aktivitas */}
      <ol className="mt-5 space-y-0">
        {events.length === 0 ? (
          <li className="text-sm text-muted-foreground">Belum ada perubahan status.</li>
        ) : (
          events.map((event, i) => {
            const isNew = fresh.includes(event.id);
            const Icon = event.icon;
            return (
              <li
                key={event.id}
                className={cn(
                  "relative flex gap-3 pb-5 last:pb-0",
                  isNew && "animate-in fade-in slide-in-from-top-2 duration-500",
                )}
              >
                {i !== events.length - 1 ? (
                  <span
                    className="absolute left-[15px] top-8 h-[calc(100%-1.5rem)] w-0.5 rounded-full bg-border"
                    aria-hidden="true"
                  />
                ) : null}
                <span
                  className={cn(
                    "z-10 grid size-8 shrink-0 place-items-center rounded-full border",
                    event.tone === "danger"
                      ? "border-destructive/30 bg-destructive/10 text-destructive"
                      : event.tone === "accent"
                        ? "border-accent/40 bg-accent/10 text-accent"
                        : "border-border bg-background text-muted-foreground",
                    isNew && "ring-2 ring-accent/40",
                  )}
                >
                  <Icon className="size-4" aria-hidden="true" />
                </span>
                <div className="min-w-0 flex-1 pt-1">
                  <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                    <p className="text-sm font-semibold">{event.title}</p>
                    <p className="text-[11px] text-muted-foreground">{relative(event.at, now)}</p>
                  </div>
                  {event.description ? (
                    <p className="mt-0.5 text-sm text-muted-foreground">{event.description}</p>
                  ) : null}
                  <p className="mt-0.5 font-mono text-[11px] text-muted-foreground">
                    {new Date(event.at).toLocaleString("id-ID", { dateStyle: "medium", timeStyle: "short" })}
                  </p>
                  {isNew ? (
                    <span className="mt-1 inline-flex rounded-full bg-accent/15 px-2 py-0.5 text-[10px] font-semibold text-accent">
                      Baru
                    </span>
                  ) : null}
                </div>
              </li>
            );
          })
        )}
      </ol>
    </section>
  );
}
