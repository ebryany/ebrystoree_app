import { Link } from "@tanstack/react-router";
import type { LucideIcon } from "lucide-react";
import { ChevronRight } from "lucide-react";
import type { ReactNode } from "react";

import { StatusPill } from "@/components/ebry/status";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function formatIDR(value: number | null | undefined): string {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(
    value ?? 0,
  );
}

/** Pintasan layanan bergaya quick-action aplikasi perbankan. */
export function ServiceShortcut({
  to,
  search,
  icon: Icon,
  label,
  hint,
  featured,
}: {
  to: string;
  search?: Record<string, unknown>;
  icon: LucideIcon;
  label: string;
  hint?: string;
  featured?: boolean;
}) {
  return (
    <Link
      to={to}
      search={search as never}
      title={hint}
      className={cn(
        "press-scale group flex min-h-[92px] flex-col items-center justify-start gap-2 rounded-xl px-1.5 py-3 text-center transition-colors duration-200 hover:bg-surface-selected/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
      )}
    >
      <span
        className={cn(
          "grid size-12 shrink-0 place-items-center rounded-2xl bg-surface-selected text-accent shadow-[inset_0_1px_0_rgba(255,255,255,0.06)] transition-all duration-200 group-hover:-translate-y-0.5 group-hover:bg-accent group-hover:text-accent-foreground group-hover:shadow-lifted",
          featured && "bg-accent text-accent-foreground",
        )}
      >
        <Icon className="size-5" aria-hidden="true" strokeWidth={1.75} />
      </span>
      <span className="w-full px-0.5 text-[11px] font-medium leading-tight text-foreground sm:text-xs">{label}</span>
    </Link>
  );
}



/** Kartu "perlu tindakan" — selalu tampil sebelum promosi. */
export function ActionRequiredCard({
  icon: Icon,
  title,
  description,
  actionLabel,
  to,
  search,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
  actionLabel: string;
  to: string;
  search?: Record<string, unknown>;
}) {
  return (
    <article className="relative flex items-start gap-3 overflow-hidden rounded-xl border border-warning/50 bg-warning/10 p-4 shadow-card">
      <span className="absolute inset-y-0 left-0 w-1 bg-warning" aria-hidden="true" />
      <span className="ml-1 grid size-10 shrink-0 place-items-center rounded-lg bg-warning/20 text-warning-foreground">
        <Icon className="size-5" aria-hidden="true" />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold">{title}</p>
        <p className="mt-0.5 text-sm text-muted-foreground">{description}</p>
        <Button asChild size="sm" className="mt-3 min-h-10">
          <Link to={to} search={search as never}>
            {actionLabel}
          </Link>
        </Button>
      </div>
    </article>
  );
}

/** Kartu pesanan (dipakai di beranda dan daftar pesanan). */
export function OrderCard({
  id,
  orderNumber,
  title,
  status,
  total,
  createdAt,
  footer,
}: {
  id: string;
  orderNumber: string;
  title: string;
  status: string;
  total: number;
  createdAt?: string;
  footer?: ReactNode;
}) {
  return (
    <article className="press-scale rounded-xl border border-border bg-card p-4 shadow-card transition-[border-color,box-shadow] hover:border-accent/40 hover:shadow-lifted">
      <Link
        to="/dashboard/pesanan/$id"
        params={{ id }}
        className="flex min-h-20 items-start gap-3 rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <StatusPill value={status} />
            <span className="font-mono text-[11px] text-muted-foreground">{orderNumber}</span>
          </div>
          <p className="mt-3 line-clamp-2 text-sm font-semibold leading-snug">{title}</p>
          <p className="mt-1 text-sm text-muted-foreground">
            {formatIDR(total)}
            {createdAt ? ` · ${new Date(createdAt).toLocaleDateString("id-ID", { dateStyle: "medium" })}` : ""}
          </p>
        </div>
        <ChevronRight className="mt-1 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
      </Link>
      {footer ? <div className="mt-3 border-t border-border pt-3">{footer}</div> : null}
    </article>
  );
}

/** Bar aksi lengket untuk mobile (checkout, detail, operator). */
export function StickyActionBar({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        "pb-safe sticky bottom-0 z-30 -mx-4 mt-6 border-t border-border bg-background/95 px-4 py-3 backdrop-blur",
        className,
      )}
    >
      {children}
    </div>
  );
}