import { useEffect, useRef, useState } from "react";
import { Search, SlidersHorizontal, X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

export type CatalogCategory = { id: string; name: string; slug: string };

type Props = {
  q: string;
  category: string;
  categories: CatalogCategory[];
  placeholder: string;
  onChange: (next: { q?: string; category?: string }) => void;
};

export function CatalogFilters({ q, category, categories, placeholder, onChange }: Props) {
  const [term, setTerm] = useState(q);
  const latest = useRef(q);

  useEffect(() => {
    latest.current = q;
    setTerm(q);
  }, [q]);

  useEffect(() => {
    if (term === latest.current) return;
    const id = setTimeout(() => onChange({ q: term }), 350);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [term]);

  const hasFilter = q.length > 0 || category.length > 0;

  return (
    <section aria-label="Pencarian dan kategori produk">
      <div className="relative rounded-lg border border-border bg-card shadow-card transition-shadow focus-within:shadow-lifted">
        <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
        <Input
          type="search"
          value={term}
          onChange={(e) => setTerm(e.target.value)}
          placeholder={placeholder}
          aria-label={placeholder}
          className="min-h-12 border-0 bg-transparent pl-12 pr-12 shadow-none focus-visible:ring-0 [&::-webkit-search-cancel-button]:appearance-none"
        />
        {term ? (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => {
              setTerm("");
              onChange({ q: "" });
            }}
            aria-label="Hapus pencarian"
            className="absolute right-1.5 top-1/2 size-9 -translate-y-1/2"
          >
            <X className="size-4" aria-hidden="true" />
          </Button>
        ) : null}
      </div>

      {categories.length ? (
        <div className="mt-4 flex items-center gap-2 overflow-x-auto pb-1" role="group" aria-label="Filter kategori">
          <SlidersHorizontal className="mr-1 size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
          <CategoryChip active={!category} onClick={() => onChange({ category: "" })}>
            Semua
          </CategoryChip>
          {categories.map((c) => (
            <CategoryChip
              key={c.id}
              active={category === c.slug}
              onClick={() => onChange({ category: category === c.slug ? "" : c.slug })}
            >
              {c.name}
            </CategoryChip>
          ))}
        </div>
      ) : null}

      {hasFilter ? (
        <div className="mt-3 flex justify-end">
          <Button
            variant="ghost"
            size="sm"
            className="min-h-9"
            onClick={() => onChange({ q: "", category: "" })}
          >
            Reset filter
          </Button>
        </div>
      ) : null}
    </section>
  );
}

function CategoryChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <Button
      type="button"
      variant={active ? "default" : "outline"}
      size="sm"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "min-h-9 shrink-0 whitespace-nowrap rounded-full px-4 text-xs font-semibold",
        !active && "bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground",
      )}
    >
      {children}
    </Button>
  );
}