import { Link } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2, Download, PackageCheck, RefreshCcw, Sparkles, Timer } from "lucide-react";

const idr = new Intl.NumberFormat("id-ID", {
  style: "currency",
  currency: "IDR",
  maximumFractionDigits: 0,
});

export type ProductCardItem = {
  id: string;
  name: string;
  slug: string;
  short_description: string | null;
  thumbnail_url: string | null;
  price: number | string;
  discount_price: number | string | null;
};

export type ServiceCardItem = {
  id: string;
  name: string;
  slug: string;
  short_description: string | null;
  thumbnail_url?: string | null;
  service_packages?:
    | Array<{
        id: string;
        price: number | string;
        estimated_days: number | null;
        free_revisions: number | null;
        is_active: boolean | null;
      }>
    | null;
};

export function MarketplaceProductCard({ item }: { item: ProductCardItem }) {
  const hasDiscount = item.discount_price != null && Number(item.discount_price) > 0;
  const price = Number(hasDiscount ? item.discount_price : item.price);
  const discountPct = hasDiscount ? Math.round((1 - price / Number(item.price)) * 100) : 0;

  return (
    <Link
      to="/produk/$slug"
      params={{ slug: item.slug }}
      className="group flex min-w-0 flex-col overflow-hidden border border-border bg-card transition-colors hover:border-primary/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      <div className="relative aspect-square overflow-hidden bg-secondary">
        {item.thumbnail_url ? (
          <img
            src={item.thumbnail_url}
            alt={item.name}
            loading="lazy"
            decoding="async"
            className="size-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
          />
        ) : (
          <span className="flex size-full items-center justify-center text-secondary-foreground">
            <Download className="size-7" aria-hidden="true" />
          </span>
        )}
        {hasDiscount ? (
          <span className="absolute right-0 top-0 bg-warning px-2 py-1 text-[10px] font-bold text-warning-foreground lg:text-xs">
            -{discountPct}%
          </span>
        ) : null}
        <span className="absolute bottom-2 left-2 bg-card/90 px-1.5 py-1 text-[9px] font-bold text-primary backdrop-blur-sm lg:text-[10px]">
          DIGITAL
        </span>
      </div>
      <div className="flex min-h-28 flex-1 flex-col p-2.5 sm:min-h-32 sm:p-3 lg:min-h-40 lg:p-4">
        <h3 className="line-clamp-2 text-xs font-semibold leading-snug sm:text-sm lg:text-base">{item.name}</h3>
        <div className="mt-auto pt-3">
          {hasDiscount ? (
            <p className="truncate text-[10px] text-muted-foreground line-through">{idr.format(Number(item.price))}</p>
          ) : null}
          <p className="truncate text-sm font-bold text-primary sm:text-base lg:text-lg">{idr.format(price)}</p>
          <p className="mt-1 flex items-center gap-1 text-[10px] text-muted-foreground lg:text-xs">
            <CheckCircle2 className="size-3 text-success" aria-hidden="true" />
            Siap dikirim
          </p>
        </div>
      </div>
    </Link>
  );
}

export function MarketplaceServiceCard({ item }: { item: ServiceCardItem }) {
  const packages = (item.service_packages ?? []).filter((p) => p.is_active !== false);
  const cheapest = packages.length
    ? packages.reduce((a, b) => (Number(a.price) <= Number(b.price) ? a : b))
    : null;

  return (
    <Link
      to="/layanan/$slug"
      params={{ slug: item.slug }}
      className="group grid min-w-0 grid-cols-[5.5rem_minmax(0,1fr)] border border-border bg-card transition-colors hover:border-primary/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:grid-cols-1"
    >
      <div className="relative aspect-square overflow-hidden bg-secondary">
        {item.thumbnail_url ? (
          <img src={item.thumbnail_url} alt={item.name} loading="lazy" decoding="async" className="size-full object-cover transition-transform duration-300 group-hover:scale-[1.03]" />
        ) : (
          <span className="flex size-full items-center justify-center text-primary"><Timer className="size-7" aria-hidden="true" /></span>
        )}
        <span className="absolute left-0 top-0 bg-primary px-2 py-1 text-[9px] font-bold text-primary-foreground">LAYANAN</span>
      </div>
      <div className="flex min-w-0 flex-col p-3 lg:p-5">
        <h3 className="line-clamp-2 text-sm font-semibold leading-snug lg:text-lg">{item.name}</h3>
        <p className="mt-1 line-clamp-1 text-[11px] text-muted-foreground lg:text-sm">{item.short_description ?? "Progres tercatat di akun"}</p>
        <div className="mt-auto pt-2">
          <p className="text-[10px] text-muted-foreground lg:text-xs">Mulai dari</p>
          <p className="truncate text-sm font-bold text-primary lg:text-lg">{cheapest ? idr.format(Number(cheapest.price)) : "Lihat paket"}</p>
        </div>
      </div>
    </Link>
  );
}

export function ProductCard({ item }: { item: ProductCardItem }) {
  const hasDiscount = item.discount_price != null && Number(item.discount_price) > 0;
  const price = Number(hasDiscount ? item.discount_price : item.price);
  const discountPct = hasDiscount
    ? Math.round((1 - price / Number(item.price)) * 100)
    : 0;

  return (
    <Link
      to="/produk/$slug"
      params={{ slug: item.slug }}
      className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-lifted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      <div className="relative aspect-[16/10] overflow-hidden bg-secondary">
        {item.thumbnail_url ? (
          <img
            src={item.thumbnail_url}
            alt={`${item.name} — produk digital Ebrystore`}
            loading="lazy" decoding="async"
            className="size-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <span className="flex size-full items-center justify-center text-secondary-foreground">
            <Download className="size-8" aria-hidden="true" />
          </span>
        )}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-gradient-to-t from-foreground/25 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100"
        />
        {hasDiscount ? (
          <span className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full bg-accent px-2.5 py-1 text-[11px] font-bold text-accent-foreground shadow-card">
            <Sparkles className="size-3" aria-hidden="true" />
            Hemat {discountPct}%
          </span>
        ) : null}
        <span className="absolute bottom-3 left-3 inline-flex items-center gap-1.5 rounded-full bg-background/85 px-2.5 py-1 text-[11px] font-semibold text-foreground backdrop-blur-sm">
          <PackageCheck className="size-3 text-primary" aria-hidden="true" />
          Terkirim otomatis
        </span>
      </div>

      <div className="flex flex-1 flex-col p-5">
        <h3 className="line-clamp-2 text-base font-semibold leading-snug transition-colors group-hover:text-primary">
          {item.name}
        </h3>
        {item.short_description ? (
          <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{item.short_description}</p>
        ) : null}

        <div className="mt-auto pt-4">
          <div className="flex items-end justify-between gap-3 border-t border-border/70 pt-4">
            <div className="min-w-0">
              {hasDiscount ? (
                <p className="text-xs text-muted-foreground line-through">
                  {idr.format(Number(item.price))}
                </p>
              ) : (
                <p className="text-xs text-muted-foreground">Harga</p>
              )}
              <p className="truncate text-lg font-bold text-primary">{idr.format(price)}</p>
            </div>
            <span className="inline-flex shrink-0 items-center gap-1.5 rounded-full bg-primary/10 px-3.5 py-2 text-xs font-semibold text-primary transition-colors duration-300 group-hover:bg-primary group-hover:text-primary-foreground">
              Lihat detail
              <ArrowRight className="size-3.5 transition-transform duration-300 group-hover:translate-x-0.5" aria-hidden="true" />
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}

export function ServiceCard({ item }: { item: ServiceCardItem }) {
  const packages = (item.service_packages ?? []).filter((p) => p.is_active !== false);
  const cheapest = packages.length
    ? packages.reduce((a, b) => (Number(a.price) <= Number(b.price) ? a : b))
    : null;

  return (
    <Link
      to="/layanan/$slug"
      params={{ slug: item.slug }}
      className="group flex flex-col rounded-2xl border border-border bg-card p-5 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/40 hover:shadow-lifted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:p-6"
    >
      <div className="flex items-start gap-3.5">
        <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary transition-colors duration-300 group-hover:bg-primary group-hover:text-primary-foreground">
          <Timer className="size-5" aria-hidden="true" />
        </span>
        <div className="min-w-0">
          <h3 className="line-clamp-2 text-base font-semibold leading-snug transition-colors group-hover:text-primary">
            {item.name}
          </h3>
          {item.short_description ? (
            <p className="mt-1.5 line-clamp-2 text-sm text-muted-foreground">{item.short_description}</p>
          ) : null}
        </div>
      </div>

      <div className="mt-4 rounded-xl bg-secondary/60 px-4 py-3.5">
        <p className="text-xs text-muted-foreground">Mulai dari</p>
        <p className="mt-0.5 text-xl font-bold text-primary">
          {cheapest ? idr.format(Number(cheapest.price)) : "Belum ada paket"}
        </p>
      </div>

      {cheapest && (cheapest.estimated_days != null || cheapest.free_revisions != null) ? (
        <ul className="mt-3.5 flex flex-wrap gap-2">
          {cheapest.estimated_days != null ? (
            <li className="inline-flex items-center gap-1.5 rounded-full border border-border/70 px-3 py-1.5 text-xs font-medium text-muted-foreground">
              <Timer className="size-3.5 text-primary" aria-hidden="true" />
              Estimasi {cheapest.estimated_days} hari
            </li>
          ) : null}
          {cheapest.free_revisions != null ? (
            <li className="inline-flex items-center gap-1.5 rounded-full border border-border/70 px-3 py-1.5 text-xs font-medium text-muted-foreground">
              <RefreshCcw className="size-3.5 text-primary" aria-hidden="true" />
              {cheapest.free_revisions}x revisi gratis
            </li>
          ) : null}
        </ul>
      ) : null}

      <div className="mt-auto pt-5">
        <span className="flex min-h-11 w-full items-center justify-center gap-2 rounded-xl bg-primary/10 text-sm font-semibold text-primary transition-colors duration-300 group-hover:bg-primary group-hover:text-primary-foreground">
          Lihat paket layanan
          <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5" aria-hidden="true" />
        </span>
      </div>
    </Link>
  );
}
