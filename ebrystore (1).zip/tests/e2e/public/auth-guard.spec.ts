import { expect, test } from "@playwright/test";

const PROTECTED = ["/dashboard", "/dashboard/pesanan", "/dashboard/produk-saya", "/admin", "/admin/jobs"];

test.describe("Proteksi rute", () => {
  for (const path of PROTECTED) {
    test(`tamu tidak bisa membuka ${path}`, async ({ page }) => {
      await page.goto(path);
      await page.waitForLoadState("networkidle");
      await expect(page).toHaveURL(/\/auth/);
    });
  }

  test("halaman auth menampilkan form masuk", async ({ page }) => {
    await page.goto("/auth");
    await expect(page.getByLabel(/email/i).first()).toBeVisible();
    await expect(page.getByRole("button", { name: /masuk|daftar/i }).first()).toBeVisible();
  });
});